-- CreateTable
CREATE TABLE "ProtoMigrationsTable" (
    "migrationName" TEXT NOT NULL,

    CONSTRAINT "ProtoMigrationsTable_pkey" PRIMARY KEY ("migrationName")
);
