BEGIN;
-- AlterTable
ALTER TABLE "ContractRevisionTable" ADD COLUMN     "dsnpContract" BOOLEAN;
COMMIT;