BEGIN;
-- AlterTable
ALTER TABLE "ContractTable" ADD COLUMN     "mccrsID" TEXT;
COMMIT;