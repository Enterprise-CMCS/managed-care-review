-- AlterTable
ALTER TABLE "StateSubmissionRevision" ADD COLUMN     "submittedBy" TEXT,
ADD COLUMN     "submittedReason" TEXT;
