-- This migration drops all data entered up to now. 
TRUNCATE "HealthPlanRevisionTable", "HealthPlanPackageTable"
