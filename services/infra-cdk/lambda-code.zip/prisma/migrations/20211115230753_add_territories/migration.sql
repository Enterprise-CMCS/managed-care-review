-- Add missing territories into the db

INSERT INTO "State" VALUES ('AS', 'American Samoa');
INSERT INTO "State" VALUES ('GU', 'Guam');
INSERT INTO "State" VALUES ('MP', 'Northern Mariana Islands');
