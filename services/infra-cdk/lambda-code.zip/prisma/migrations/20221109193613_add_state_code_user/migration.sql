-- AlterTable
ALTER TABLE "User" ADD COLUMN     "stateCode" TEXT;
