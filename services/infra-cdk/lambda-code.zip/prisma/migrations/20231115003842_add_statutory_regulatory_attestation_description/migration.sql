BEGIN;

-- AlterTable
ALTER TABLE "ContractRevisionTable" ADD COLUMN     "statutoryRegulatoryAttestationDescription" TEXT;

COMMIT;
