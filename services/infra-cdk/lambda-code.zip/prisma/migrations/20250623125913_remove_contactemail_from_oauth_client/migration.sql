BEGIN;


-- AlterTable
ALTER TABLE "OAuthClient" DROP COLUMN "contactEmail";

COMMIT;