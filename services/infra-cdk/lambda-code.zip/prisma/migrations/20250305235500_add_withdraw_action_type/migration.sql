BEGIN;

-- AlterEnum
ALTER TYPE "ContractActionType" ADD VALUE 'WITHDRAW';

COMMIT;
