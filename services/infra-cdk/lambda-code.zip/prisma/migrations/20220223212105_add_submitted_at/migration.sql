-- AlterTable
ALTER TABLE "StateSubmissionRevision" ADD COLUMN     "submittedAt" TIMESTAMP(3);
