export {
    generateDocumentZip,
    localGenerateDocumentZip,
    documentZipService,
} from './generateZip'
export type { GenerateDocumentZipFunctionType } from './generateZip'
