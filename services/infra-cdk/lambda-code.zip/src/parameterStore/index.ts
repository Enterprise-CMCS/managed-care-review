export {
    newAWSEmailParameterStore,
    newLocalEmailParameterStore,
} from './emailParameterStore/emailParameterStore'

export type { EmailParameterStore } from './emailParameterStore/emailParameterStore'
