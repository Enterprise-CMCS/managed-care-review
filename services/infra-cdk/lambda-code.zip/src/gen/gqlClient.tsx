import { gql } from '@apollo/client';
import * as Apollo from '@apollo/client';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
const defaultOptions = {} as const;
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
  /** Date is a CalendarDate representing a day without time information */
  Date: { input: any; output: any; }
  /** DateTime is a moment in time with date and time information */
  DateTime: { input: any; output: any; }
};

/** The firm that the certifying actuary works for */
export type ActuarialFirm =
  | 'DELOITTE'
  | 'GUIDEHOUSE'
  | 'MERCER'
  | 'MILLIMAN'
  | 'OPTUMAS'
  | 'OTHER'
  | 'STATE_IN_HOUSE';

/**
 * State's communication preference for contacting their actuaries. Either:
 * - wants CMS to reach out to their actuaries directly or
 * - go through them
 */
export type ActuaryCommunication =
  | 'OACT_TO_ACTUARY'
  | 'OACT_TO_STATE';

/** Contact information for the certifying or additional state actuary */
export type ActuaryContact = {
  __typename?: 'ActuaryContact';
  actuarialFirm?: Maybe<ActuarialFirm>;
  actuarialFirmOther?: Maybe<Scalars['String']['output']>;
  email?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  titleRole?: Maybe<Scalars['String']['output']>;
};

/** Contact information input for the certifying or additional state actuary */
export type ActuaryContactInput = {
  actuarialFirm?: InputMaybe<ActuarialFirm>;
  actuarialFirmOther?: InputMaybe<Scalars['String']['input']>;
  email?: InputMaybe<Scalars['String']['input']>;
  id?: InputMaybe<Scalars['ID']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  titleRole?: InputMaybe<Scalars['String']['input']>;
};

/** AdminUser is a user that works on the MC Review app itself */
export type AdminUser = {
  __typename?: 'AdminUser';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'ADMIN_USER' */
  role: Scalars['String']['output'];
};

export type ApproveContractInput = {
  /** The ID of the contract to approve */
  contractID: Scalars['ID']['input'];
  /** Manually entered date for when the approval was released to the state */
  dateApprovalReleasedToState: Scalars['Date']['input'];
};

export type ApproveContractPayload = {
  __typename?: 'ApproveContractPayload';
  contract: Contract;
};

/** The Business Owner is the root of our role hierarchy with the power to approve new admin accounts */
export type BusinessOwnerUser = {
  __typename?: 'BusinessOwnerUser';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'BUSINESSOWNER_USER' */
  role: Scalars['String']['output'];
};

/** CMSApproverUser is a user that works for CMS, approving CMS approver request and able to do everything a CMSUser can do */
export type CmsApproverUser = {
  __typename?: 'CMSApproverUser';
  divisionAssignment?: Maybe<Division>;
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'CMS_APPROVER_USER' */
  role: Scalars['String']['output'];
  stateAssignments: Array<State>;
};

/** CMSUser is a user that works for CMS, reviewing packages submitted by StateUsers */
export type CmsUser = {
  __typename?: 'CMSUser';
  divisionAssignment?: Maybe<Division>;
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'CMS_USER' */
  role: Scalars['String']['output'];
  stateAssignments: Array<State>;
};

export type CmsUsersUnion = CmsApproverUser | CmsUser;

/**
 * This status has been synthesized to reflect if the status or review status
 * should be used
 */
export type ConsolidatedContractStatus =
  | 'APPROVED'
  | 'DRAFT'
  | 'RESUBMITTED'
  | 'SUBMITTED'
  | 'UNLOCKED'
  | 'WITHDRAWN';

/**
 * This status has been synthesized to reflect if the status or review status
 * should be used
 */
export type ConsolidatedRateStatus =
  | 'DRAFT'
  | 'RESUBMITTED'
  | 'SUBMITTED'
  | 'UNLOCKED'
  | 'WITHDRAWN';

/**
 * Contract is a single contract submission, holding all the form data for a single contract
 * and associated with zero or more Rates
 */
export type Contract = {
  __typename?: 'Contract';
  /**
   * Synthesized field that represents if a contract's status or
   * reviewStatus should take precedence
   * Options are DRAFT, SUBMITTED, RESUBMITTED UNLOCKED, UNDER_REVIEW, APPROVED, WITHDRAWN
   */
  consolidatedStatus: ConsolidatedContractStatus;
  createdAt: Scalars['DateTime']['output'];
  /** dateContractDocsExecuted is the first date, if any in which the revisions were submitted with all contract docs executed. Null otherwise. */
  dateContractDocsExecuted?: Maybe<Scalars['DateTime']['output']>;
  /**
   * draftRates are the Rates that this editable submission are related to.
   * On submission they are cemented into a new ContractPackageSubmission
   */
  draftRates?: Maybe<Array<Rate>>;
  /** draftRevision is the currently modifiable revision if the rate is DRAFT or UNLOCKED */
  draftRevision?: Maybe<ContractRevision>;
  id: Scalars['ID']['output'];
  /** initiallySubmittedAt is the initial date this contract was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['DateTime']['output']>;
  /** lastUpdatedForDisplay is the last time this contract was officially updated. When it's a draft it will be the last updatedAt date. Afterwards it will be the most recent submit or unlock or review action date. */
  lastUpdatedForDisplay: Scalars['DateTime']['output'];
  /** mccrsID is the four digit id in MC-CRS that corresponds to this Contract, if set */
  mccrsID?: Maybe<Scalars['String']['output']>;
  /**
   * packageSubmissions are a snapshot of the contract and its related rates through time
   * each packageSubmission was created by a submission of this contract and/or its related rates
   * a DRAFT Contract will have no packageSubmissions. Returned in _ascending_ order. Most recent
   * submission is in the first position in the array.
   */
  packageSubmissions: Array<ContractPackageSubmission>;
  /**
   * questions field is an array of questions asked about the contract by CMS. Each questions also contains responses
   * to the question submitted by the State. DRAFT contracts will not have questions, only contracts that have been submitted
   * , unlocked, or resubmitted. The array is in descending order by createdAt.
   */
  questions?: Maybe<IndexContractQuestionsPayload>;
  /**
   * Where the contract is in the review submission flow
   * Options are UNDER_REVIEW, APPROVED, WITHDRAWN
   */
  reviewStatus: ContractReviewStatus;
  /** reviewStatusActions are the who/when/why for review status changes on this contract */
  reviewStatusActions?: Maybe<Array<ContractReviewStatusActions>>;
  /** state is fuller state data for the submitting state */
  state: State;
  /** stateCode is the state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * stateNumber is a unique auto-incrementing number identifying this contract
   * This value is used to generate the contractName
   */
  stateNumber: Scalars['Int']['output'];
  /**
   * Where the contract is in the submission flow.
   * Options are DRAFT, SUBMITTED, RESUBMITTED and UNLOCKED
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: HealthPlanPackageStatus;
  updatedAt: Scalars['DateTime']['output'];
  /** webURL is a url that will open the MC Review web app to this Contract */
  webURL: Scalars['String']['output'];
  /** Rates withdrawn from this contract submission */
  withdrawnRates?: Maybe<Array<Rate>>;
};

export type ContractActionType =
  | 'MARK_AS_APPROVED'
  | 'UNDER_REVIEW'
  | 'WITHDRAW';

export type ContractDraftRevisionFormDataInput = {
  /** End date of the contract */
  contractDateEnd?: InputMaybe<Scalars['Date']['input']>;
  /** Start date of the contract */
  contractDateStart?: InputMaybe<Scalars['Date']['input']>;
  /** State upload of the submitted contract */
  contractDocuments: Array<GenericDocumentInput>;
  /**
   * Execution status for a contract.
   * Contracts are fully executed or unexecuted by some or all parties
   * Status can be either EXECUTED or UNEXECUTED
   */
  contractExecutionStatus?: InputMaybe<ContractExecutionStatus>;
  /**
   * Type of contract the state is submitting
   * Options are: BASE, AMENDMENT
   */
  contractType?: InputMaybe<ContractType>;
  /**
   * The state plan and/or waiver authorities that allow the state
   * to run its managed care programs
   */
  federalAuthorities: Array<FederalAuthority>;
  /**
   * If contract is in Lieu-of Services and Settings (ILOSs)
   * in accordance with 42 CFR § 438.3(e)(2)
   */
  inLieuServicesAndSettings?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * The type of organization the state is contracting with
   * in order to deliver managed care services
   * Options are MCO, PIHP, PAHP, and PCCM
   */
  managedCareEntities: Array<ManagedCareEntity>;
  /** If contract includes modifications to benefits provided by the managed care plans */
  modifiedBenefitsProvided?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the enrollment/disenrollment process */
  modifiedEnrollmentProcess?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the geographic areas served by the managed care plans */
  modifiedGeoAreaServed?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the grevience and appeal system */
  modifiedGrevienceAndAppeal?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to incentive arrangements */
  modifiedIncentiveArrangements?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the length of the contract period */
  modifiedLengthOfContract?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * If contract includes modifications to the Medicaid beneficiaries served by the managed care
   * plans (e.g. eligibility or enrollment criteria)
   */
  modifiedMedicaidBeneficiaries?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the medical loss ratio standards */
  modifiedMedicalLossRatioStandards?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the network adequacy standards */
  modifiedNetworkAdequacyStandards?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the non-risk payment arrangements */
  modifiedNonRiskPaymentArrangements?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * If contract includes modifications to
   * other financial, payment, incentive or related contractual provisions
   */
  modifiedOtherFinancialPaymentIncentive?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the pass-through payments */
  modifiedPassThroughPayments?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * If contract includes modifications to payments to MCOs and PIHPs for enrollees that
   * are a patient in an institution for mental disease
   */
  modifiedPaymentsForMentalDiseaseInstitutions?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the risk sharing strategy */
  modifiedRiskSharingStrategy?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the state directed payments */
  modifiedStateDirectedPayments?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the withold agreements */
  modifiedWitholdAgreements?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * The large overarching population of people that the program covers.
   * Options are MEDICAID, CHIP, MEDICAID_AND_CHIP
   */
  populationCovered?: InputMaybe<PopulationCovered>;
  /** An array of IDs representing state programs that the contract covers */
  programIDs: Array<Scalars['String']['input']>;
  /**
   * Whether or not this contract is risk based
   * Risk-based contracts have specific requirements that
   * non-risk based contracts do not have
   */
  riskBasedContract?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * Array of state contacts of state representatives who should be
   * contacted about updates to the contract
   * Each state contact contains string fields for: name, title, and email
   */
  stateContacts: Array<StateContactInput>;
  /** If contract has statutory regulatory attestation */
  statutoryRegulatoryAttestation?: InputMaybe<Scalars['Boolean']['input']>;
  /** Description provided for if contract has statutory regulatory attestation */
  statutoryRegulatoryAttestationDescription?: InputMaybe<Scalars['String']['input']>;
  /** State provided summary of the contract being submitted */
  submissionDescription?: InputMaybe<Scalars['String']['input']>;
  /**
   * The submission type of this package
   * Options are CONTRACT_ONLY and CONTRACT_AND_RATES
   */
  submissionType?: InputMaybe<SubmissionType>;
  /**
   * Additional documents the state uploads to support a contract
   * Files can be PDF, DOC, DOCX, XLSX, CSV format
   */
  supportingDocuments: Array<GenericDocumentInput>;
};

export type ContractEdge = {
  __typename?: 'ContractEdge';
  node: Contract;
};

/** Whether contract has been fully executed by all parties or not */
export type ContractExecutionStatus =
  | 'EXECUTED'
  | 'UNEXECUTED';

/**
 * ContractFormData represents the form data that was inputted by the state
 * This type is used for the form data field found on a contract revision
 */
export type ContractFormData = {
  __typename?: 'ContractFormData';
  /** End date of the contract */
  contractDateEnd?: Maybe<Scalars['Date']['output']>;
  /** Start date of the contract */
  contractDateStart?: Maybe<Scalars['Date']['output']>;
  /** State upload of the submitted contract */
  contractDocuments: Array<GenericDocument>;
  /**
   * Execution status for a contract.
   * Contracts are fully executed or unexecuted by some or all parties
   * Status can be either EXECUTED or UNEXECUTED
   */
  contractExecutionStatus?: Maybe<ContractExecutionStatus>;
  /**
   * Type of contract the state is submitting
   * Options are: BASE, AMENDMENT
   */
  contractType?: Maybe<ContractType>;
  /**
   * The state plan and/or waiver authorities that allow the state
   * to run its managed care programs
   */
  federalAuthorities: Array<FederalAuthority>;
  /**
   * If contract is in Lieu-of Services and Settings (ILOSs)
   * in accordance with 42 CFR § 438.3(e)(2)
   */
  inLieuServicesAndSettings?: Maybe<Scalars['Boolean']['output']>;
  /**
   * The type of organization the state is contracting with
   * in order to deliver managed care services
   * Options are MCO, PIHP, PAHP, and PCCM
   */
  managedCareEntities: Array<ManagedCareEntity>;
  /** If contract includes modifications to benefits provided by the managed care plans */
  modifiedBenefitsProvided?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the enrollment/disenrollment process */
  modifiedEnrollmentProcess?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the geographic areas served by the managed care plans */
  modifiedGeoAreaServed?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the grevience and appeal system */
  modifiedGrevienceAndAppeal?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to incentive arrangements */
  modifiedIncentiveArrangements?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the length of the contract period */
  modifiedLengthOfContract?: Maybe<Scalars['Boolean']['output']>;
  /**
   * If contract includes modifications to the Medicaid beneficiaries served by the managed care
   * plans (e.g. eligibility or enrollment criteria)
   */
  modifiedMedicaidBeneficiaries?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the medical loss ratio standards */
  modifiedMedicalLossRatioStandards?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the network adequacy standards */
  modifiedNetworkAdequacyStandards?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the non-risk payment arrangements */
  modifiedNonRiskPaymentArrangements?: Maybe<Scalars['Boolean']['output']>;
  /**
   * If contract includes modifications to
   * other financial, payment, incentive or related contractual provisions
   */
  modifiedOtherFinancialPaymentIncentive?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the pass-through payments */
  modifiedPassThroughPayments?: Maybe<Scalars['Boolean']['output']>;
  /**
   * If contract includes modifications to payments to MCOs and PIHPs for enrollees that
   * are a patient in an institution for mental disease
   */
  modifiedPaymentsForMentalDiseaseInstitutions?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the risk sharing strategy */
  modifiedRiskSharingStrategy?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the state directed payments */
  modifiedStateDirectedPayments?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the withold agreements */
  modifiedWitholdAgreements?: Maybe<Scalars['Boolean']['output']>;
  /**
   * The large overarching population of people that the program covers.
   * Options are MEDICAID, CHIP, MEDICAID_AND_CHIP
   */
  populationCovered?: Maybe<PopulationCovered>;
  /** An array of IDs representing state programs that the contract covers */
  programIDs: Array<Scalars['String']['output']>;
  /**
   * Whether or not this contract is risk based
   * Risk-based contracts have specific requirements that
   * non-risk based contracts do not have
   */
  riskBasedContract?: Maybe<Scalars['Boolean']['output']>;
  /**
   * Array of state contacts of state representatives who should be
   * contacted about updates to the contract
   * Each state contact contains string fields for: name, title, and email
   */
  stateContacts: Array<StateContact>;
  /** If contract has statutory regulatory attestation */
  statutoryRegulatoryAttestation?: Maybe<Scalars['Boolean']['output']>;
  /** Description provided for if contract has statutory regulatory attestation */
  statutoryRegulatoryAttestationDescription?: Maybe<Scalars['String']['output']>;
  /** State provided summary of the contract being submitted */
  submissionDescription: Scalars['String']['output'];
  /**
   * The submission type of this package
   * Options are CONTRACT_ONLY and CONTRACT_AND_RATES
   */
  submissionType: SubmissionType;
  /**
   * Additional documents the state uploads to support a contract
   * Files can be PDF, DOC, DOCX, XLSX, CSV format
   */
  supportingDocuments: Array<GenericDocument>;
};

/**
 * ContractPackageSubmission is a snapshot of a contract and all its related rates in time
 * a ContractPackageSubmission can be created by the user submitting a contract or a related rate
 */
export type ContractPackageSubmission = {
  __typename?: 'ContractPackageSubmission';
  /** cause is a hint as to why this submission was created */
  cause: SubmissionReason;
  /** contractRevision is the contract revision current at the time of this package submission */
  contractRevision: ContractRevision;
  /** rateRevisions are the linked rate revisions current at the time of this package submission */
  rateRevisions: Array<RateRevision>;
  /** submitInfo provides the submission reason/date/by for this package submission */
  submitInfo: UpdateInformation;
  /** submittedRevisions is a list of contract and/or rate revisions that were submitted to create this package submission */
  submittedRevisions: Array<SubmittableRevision>;
};

/**
 * ContractQuestion is a question sent by CMS to the States for a response, associated with a single contract.
 * CMS may upload one or more documents full of questions to a single ContractQuestion. States submit a
 * QuestionResponse with documents that answer the questions posed by CMS.
 */
export type ContractQuestion = {
  __typename?: 'ContractQuestion';
  addedBy: CmsUsersUnion;
  contractID: Scalars['ID']['output'];
  createdAt: Scalars['DateTime']['output'];
  division: Division;
  documents: Array<Document>;
  id: Scalars['ID']['output'];
  responses: Array<QuestionResponse>;
  round: Scalars['Int']['output'];
};

export type ContractQuestionEdge = {
  __typename?: 'ContractQuestionEdge';
  node: ContractQuestion;
};

export type ContractQuestionList = {
  __typename?: 'ContractQuestionList';
  edges: Array<ContractQuestionEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

/**
 * This status is used to determine whether the package is currently being edited by a state user
 * or if it has been submitted and is being reviewed by CMS users.
 */
export type ContractReviewStatus =
  | 'APPROVED'
  | 'UNDER_REVIEW'
  | 'WITHDRAWN';

/** ContractReviewStatusActions is used for the review status actions on the contract */
export type ContractReviewStatusActions = {
  __typename?: 'ContractReviewStatusActions';
  /** the type of review action performed on the contract: APPROVED, WITHDRAWN */
  actionType: ContractActionType;
  contractID: Scalars['ID']['output'];
  /** Manual time entered by CMS to represent when an approval released to state */
  dateApprovalReleasedToState?: Maybe<Scalars['DateTime']['output']>;
  /** the datetime when the update occurred */
  updatedAt: Scalars['DateTime']['output'];
  /** the user who performed the update */
  updatedBy: UpdatedBy;
  /** the reason provided by the user when performing the update */
  updatedReason?: Maybe<Scalars['String']['output']>;
};

/**
 * ContractRevision is a single instance of all the contract specific data in a submission
 * it contains the unlock and submit info.
 */
export type ContractRevision = {
  __typename?: 'ContractRevision';
  contractID: Scalars['String']['output'];
  /**
   * Represents the name of the contract pacakge.
   * This value is auto generated based on contract state number, contract type, dates, and state program details"\
   */
  contractName: Scalars['String']['output'];
  createdAt: Scalars['DateTime']['output'];
  /** formData is all the contract specific info part of this submission */
  formData: ContractFormData;
  id: Scalars['ID']['output'];
  /** submitInfo is the who/when/why for this revision being submitted. An Unlocked revision has no submitInfo */
  submitInfo?: Maybe<UpdateInformation>;
  /** unlockInfo is the who/when/why for this revision being unlocked. A DRAFT or SUBMITTED revision will not have one */
  unlockInfo?: Maybe<UpdateInformation>;
  updatedAt: Scalars['DateTime']['output'];
};

export type ContractType =
  | 'AMENDMENT'
  | 'BASE';

export type CreateApiKeyPayload = {
  __typename?: 'CreateAPIKeyPayload';
  expiresAt: Scalars['DateTime']['output'];
  key: Scalars['String']['output'];
};

export type CreateContractInput = {
  /**
   * Type of contract the state is submitting
   * Options are: BASE, AMENDMENT
   */
  contractType: ContractType;
  /**
   * The large overarching population of people that the program covers.
   * Options are MEDICAID, CHIP, MEDICAID_AND_CHIP
   */
  populationCovered: PopulationCovered;
  /** An array of managed care program IDs this package covers */
  programIDs: Array<Scalars['String']['input']>;
  /** Whether or not this contract is risk based */
  riskBasedContract?: InputMaybe<Scalars['Boolean']['input']>;
  /** User description of the reason for the submission */
  submissionDescription: Scalars['String']['input'];
  /**
   * The submission type of this package
   * Options are CONTRACT_ONLY and CONTRACT_AND_RATES
   */
  submissionType: SubmissionType;
};

export type CreateContractPayload = {
  __typename?: 'CreateContractPayload';
  contract: Contract;
};

export type CreateContractQuestionInput = {
  /** The ID of the package for which to create a question */
  contractID: Scalars['ID']['input'];
  /** A list of documents to attach to the question */
  documents: Array<DocumentInput>;
  /** The date the answer to the question is due */
  dueDate?: InputMaybe<Scalars['Date']['input']>;
  /** A note to attach to the question */
  noteText?: InputMaybe<Scalars['String']['input']>;
  /** The rate IDs associated with the question */
  rateIDs?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type CreateContractQuestionPayload = {
  __typename?: 'CreateContractQuestionPayload';
  /** The newly created Question */
  question: ContractQuestion;
};

export type CreateContractQuestionResponsePayload = {
  __typename?: 'CreateContractQuestionResponsePayload';
  /** Contract Question with newly created response */
  question: ContractQuestion;
};

export type CreateHealthPlanPackageInput = {
  /**
   * Type of contract the state is submitting
   * Options are: BASE, AMENDMENT
   */
  contractType: ContractType;
  /**
   * The large overarching population of people that the program covers.
   * Options are MEDICAID, CHIP, MEDICAID_AND_CHIP
   */
  populationCovered: PopulationCoveredType;
  /** An array of managed care program IDs this package covers */
  programIDs: Array<Scalars['ID']['input']>;
  /** Whether or not this contract is risk based */
  riskBasedContract?: InputMaybe<Scalars['Boolean']['input']>;
  /** User description of the reason for the submission */
  submissionDescription: Scalars['String']['input'];
  /**
   * The submission type of this package
   * Options are CONTRACT_ONLY and CONTRACT_AND_RATES
   */
  submissionType: SubmissionType;
};

export type CreateHealthPlanPackagePayload = {
  __typename?: 'CreateHealthPlanPackagePayload';
  /** The newly created HealthPlanPackage */
  pkg: HealthPlanPackage;
};

export type CreateOauthClientInput = {
  contactEmail: Scalars['String']['input'];
  description?: InputMaybe<Scalars['String']['input']>;
  grants?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type CreateOauthClientPayload = {
  __typename?: 'CreateOauthClientPayload';
  oauthClient: OauthClient;
};

/** Generic input type for both Contract and Rate Question. */
export type CreateQuestionResponseInput = {
  /** A list of documents to attach to the response */
  documents: Array<DocumentInput>;
  /** A note to attach to the response */
  noteText?: InputMaybe<Scalars['String']['input']>;
  /** The ID of the question for which to create a response */
  questionID: Scalars['ID']['input'];
};

export type CreateRateQuestionInput = {
  /** A list of documents to attach to the question */
  documents: Array<DocumentInput>;
  /** The date the answer to the question is due */
  dueDate?: InputMaybe<Scalars['Date']['input']>;
  /** A note to attach to the question */
  noteText?: InputMaybe<Scalars['String']['input']>;
  /** The ID of the rate for which to create a question */
  rateID: Scalars['ID']['input'];
};

export type CreateRateQuestionPayload = {
  __typename?: 'CreateRateQuestionPayload';
  /** The newly created rate question */
  question: RateQuestion;
};

export type CreateRateQuestionResponsePayload = {
  __typename?: 'CreateRateQuestionResponsePayload';
  /** Rate Question with newly created response */
  question: RateQuestion;
};

export type DeleteOauthClientInput = {
  clientId: Scalars['String']['input'];
};

export type DeleteOauthClientPayload = {
  __typename?: 'DeleteOauthClientPayload';
  oauthClient: OauthClient;
};

export type Division =
  | 'DMCO'
  | 'DMCP'
  | 'OACT';

/**
 * Document represents a document that has been uploaded to S3. It can be retrieved at the s3URL
 * by an authenticated user.
 */
export type Document = {
  __typename?: 'Document';
  downloadURL?: Maybe<Scalars['String']['output']>;
  name: Scalars['String']['output'];
  s3URL: Scalars['String']['output'];
};

export type DocumentInput = {
  /** The url used for downloading a file from S3 */
  downloadURL?: InputMaybe<Scalars['String']['input']>;
  /** The name of the document */
  name: Scalars['String']['input'];
  /** The S3 URL of the document */
  s3URL: Scalars['String']['input'];
};

/** Email configurations for the application used in automated emails */
export type EmailConfiguration = {
  __typename?: 'EmailConfiguration';
  cmsRateHelpEmailAddress: Scalars['String']['output'];
  cmsReviewHelpEmailAddress: Scalars['String']['output'];
  devReviewTeamEmails: Array<Scalars['String']['output']>;
  dmcoEmails: Array<Scalars['String']['output']>;
  dmcpReviewEmails: Array<Scalars['String']['output']>;
  dmcpSubmissionEmails: Array<Scalars['String']['output']>;
  emailSource: Scalars['String']['output'];
  helpDeskEmail: Scalars['String']['output'];
  oactEmails: Array<Scalars['String']['output']>;
};

export type EmailConfigurationInput = {
  cmsRateHelpEmailAddress: Scalars['String']['input'];
  cmsReviewHelpEmailAddress: Scalars['String']['input'];
  devReviewTeamEmails: Array<Scalars['String']['input']>;
  dmcoEmails: Array<Scalars['String']['input']>;
  dmcpReviewEmails: Array<Scalars['String']['input']>;
  dmcpSubmissionEmails: Array<Scalars['String']['input']>;
  emailSource: Scalars['String']['input'];
  helpDeskEmail: Scalars['String']['input'];
  oactEmails: Array<Scalars['String']['input']>;
};

/**
 * The state plan and/or waiver authorities that allow the
 * state to run its managed care programs
 */
export type FederalAuthority =
  | 'BENCHMARK'
  | 'STATE_PLAN'
  | 'TITLE_XXI'
  | 'VOLUNTARY'
  | 'WAIVER_1115'
  | 'WAIVER_1915B';

export type FetchContractInput = {
  contractID: Scalars['ID']['input'];
};

export type FetchContractPayload = {
  __typename?: 'FetchContractPayload';
  /** A contract that include contract and rate revisions */
  contract: Contract;
};

export type FetchHealthPlanPackageInput = {
  /** The ID of the package to fetch */
  pkgID: Scalars['ID']['input'];
};

export type FetchHealthPlanPackagePayload = {
  __typename?: 'FetchHealthPlanPackagePayload';
  /** A single HealthPlanPackage */
  pkg: HealthPlanPackage;
};

export type FetchMcReviewSettingsPayload = {
  __typename?: 'FetchMcReviewSettingsPayload';
  emailConfiguration?: Maybe<EmailConfiguration>;
  stateAssignments: Array<StateAssignment>;
};

export type FetchOauthClientsInput = {
  clientIds?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type FetchOauthClientsPayload = {
  __typename?: 'FetchOauthClientsPayload';
  oauthClients: Array<OauthClient>;
};

export type FetchRateInput = {
  rateID: Scalars['ID']['input'];
};

export type FetchRatePayload = {
  __typename?: 'FetchRatePayload';
  /** A rate that include contract and rate revisions */
  rate: Rate;
};

/**
 * GenericDocument
 *
 * This document type should be used (or extended) everywhere we pass documents through GraphQL regardless of domain
 */
export type GenericDocument = {
  __typename?: 'GenericDocument';
  /** The first date this document was added to submitted package - if still an initial draft, this date is last updated, otherwise it is the submitInfo lastUpdated */
  dateAdded?: Maybe<Scalars['DateTime']['output']>;
  /** URL received from S3 for downloading the document */
  downloadURL?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  /** The user created name of the document */
  name: Scalars['String']['output'];
  /** The S3 URL of the document, generated on the FE currently in the FileUpload component */
  s3URL: Scalars['String']['output'];
  /** The sha256 is a unique string representing the file, generated on the FE currently in the FileUpload component */
  sha256: Scalars['String']['output'];
};

/**
 * GenericDocument
 *
 * This document input should be used (or extended) everywhere we pass documents through GraphQL regardless of domain
 */
export type GenericDocumentInput = {
  /** The first date this document was added to submitted package - this is ignored on input and regenerated on return */
  dateAdded?: InputMaybe<Scalars['DateTime']['input']>;
  /** The url used for downloading a file from S3 */
  downloadURL?: InputMaybe<Scalars['String']['input']>;
  /** The user created name of the document */
  name: Scalars['String']['input'];
  /** The S3 URL of the document, generated on the FE currently in the FileUpload component */
  s3URL: Scalars['String']['input'];
  /** The sha256 is a unique string representing the file, generated on the FE currently in the FileUpload component */
  sha256: Scalars['String']['input'];
};

/**
 * HealthPlanPackage is the core type for a single package submission. All the
 * submission data is contained in the HealthPlanRevision type, allowing us to store
 * the full history of packages previously submitted.
 *
 * HealthPlanPackages are submitted by state users and reviewed by CMS users.
 * Initally created in DRAFT state, they are submitted using the submitHealthPlanPackage mutation.
 * CMS users are able to use the unlockHealthPlanPackage mutation to return it to the state user in
 * the UNLOCKED state for corrections. State users can then resubmit.
 */
export type HealthPlanPackage = {
  __typename?: 'HealthPlanPackage';
  /** uuid */
  id: Scalars['ID']['output'];
  /** The initial date this package was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['Date']['output']>;
  /** MC-CRS record number provided by CMS user (e.g. 1234) */
  mccrsID?: Maybe<Scalars['String']['output']>;
  questions?: Maybe<IndexContractQuestionsPayload>;
  /**
   * Array of revisions for this package. Each revision represents a single submission
   * for the package and contains the full data from when it was submitted
   */
  revisions: Array<HealthPlanRevisionEdge>;
  /** Fuller state data for the submitting state */
  state: State;
  /** The state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * Where the package is in the submission flow.
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: HealthPlanPackageStatus;
};

export type HealthPlanPackageEdge = {
  __typename?: 'HealthPlanPackageEdge';
  node: HealthPlanPackage;
};

/**
 * HealthPlanPackageStatus tracks the editing vs. submitted status of the package.
 * It is not intended to track the overall status of the package through the review process
 * as that is fleshed out.
 *
 * State Machine:
 * ```
 * DRAFT -> SUBMITTED -> UNLOCKED -> RESUBMITTED
 *                          ^               |
 *                          |---------------|
 * ```
 *
 * This status is used to determine whether the package is currently being edited by a state user
 * or if it has been submitted and is being reviewed by CMS users.
 */
export type HealthPlanPackageStatus =
  | 'DRAFT'
  | 'RESUBMITTED'
  | 'SUBMITTED'
  | 'UNLOCKED';

/**
 * HealthPlanRevision is a single revision of the package. It contains all the
 * data from the form filled out by a state user about their package. When a
 * HealthPlanPackage is initially created, a single revision is created as well. That
 * revision has its submitInfo filled out when it is submitted, which is what marks
 * the HealthPlanPackage as SUBMITTED.
 *
 * When a HealthPlanPackage is unlocked with the unlockHealthPlanPackage mutation
 * a new revision is created with a copy of the previous revision's formDataProto and its
 * unlockInfo filled out. This can then be modified by the state user and resubmitted.
 */
export type HealthPlanRevision = {
  __typename?: 'HealthPlanRevision';
  createdAt: Scalars['DateTime']['output'];
  /**
   * base64 encoded HealthPlanFormData protobuf. This contains all the data
   * from the health plan pacakge form that the state user fills out and submits.
   * Its schema can be found in health_plan_form_data.proto
   */
  formDataProto: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** Information on who, when, and why this revision was submitted. */
  submitInfo?: Maybe<UpdateInformation>;
  /**
   * Information about who, when, and why this revision was unlocked.
   * Will be blank on the initial revision.
   */
  unlockInfo?: Maybe<UpdateInformation>;
};

export type HealthPlanRevisionEdge = {
  __typename?: 'HealthPlanRevisionEdge';
  node: HealthPlanRevision;
};

/** HelpdeskUser is a user that supports state and cms users */
export type HelpdeskUser = {
  __typename?: 'HelpdeskUser';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'HELPDESK_USER' */
  role: Scalars['String']['output'];
};

export type IndexContractQuestionsPayload = {
  __typename?: 'IndexContractQuestionsPayload';
  /** Questions for a given submission that were asked by DMCO within CMS */
  DMCOQuestions: ContractQuestionList;
  /** Questions for a given submission that were asked by DMCP within CMS */
  DMCPQuestions: ContractQuestionList;
  /** Questions for a given submission that were asked by OACT within CMS */
  OACTQuestions: ContractQuestionList;
};

export type IndexContractsPayload = {
  __typename?: 'IndexContractsPayload';
  edges: Array<ContractEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type IndexHealthPlanPackagesPayload = {
  __typename?: 'IndexHealthPlanPackagesPayload';
  edges: Array<HealthPlanPackageEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type IndexRateQuestionsPayload = {
  __typename?: 'IndexRateQuestionsPayload';
  /** Questions for a given rate that were asked by DMCO within CMS */
  DMCOQuestions: RateQuestionList;
  /** Questions for a given rate that were asked by DMCP within CMS */
  DMCPQuestions: RateQuestionList;
  /** Questions for a given rate that were asked by OACT within CMS */
  OACTQuestions: RateQuestionList;
};

export type IndexRatesInput = {
  rateIDs?: InputMaybe<Array<Scalars['String']['input']>>;
  stateCode?: InputMaybe<Scalars['String']['input']>;
};

export type IndexRatesPayload = {
  __typename?: 'IndexRatesPayload';
  /** Rates that include rate and contract revisions */
  edges: Array<RateEdge>;
  /** Total number of submitted rates returned on request */
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type IndexRatesStrippedPayload = {
  __typename?: 'IndexRatesStrippedPayload';
  edges: Array<RateStrippedEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type IndexUsersPayload = {
  __typename?: 'IndexUsersPayload';
  edges: Array<UserEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

/**
 * The type of organization the state is contracting with in order to deliver
 * managed care services
 */
export type ManagedCareEntity =
  | 'MCO'
  | 'PAHP'
  | 'PCCM'
  | 'PIHP';

export type Mutation = {
  __typename?: 'Mutation';
  /**
   * approveContract is a CMS user only action
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMS/CMS Approver user called this
   * - UserInputError:
   *     - A contract is not in the correct submission status: SUBMITTED or RESUBMITTED
   *     - A contract is not in the correct review status: UNDER_REVIEW
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - A contract cannot be found by id
   */
  approveContract?: Maybe<ApproveContractPayload>;
  /** createAPIKey creates a valid API key for the logged in user, valid for 90 days */
  createAPIKey: CreateApiKeyPayload;
  /**
   * createContract creates a new Contract.
   *
   * The new Contract is created with a single contractRevision with
   * the information specified in the input parameters. The created contract will have
   * the DRAFT status. The stateCode of the contract will be set to the state the
   * user that calls this mutation is from.
   *
   * This can only be called by StateUsers
   *
   * Errors:
   * - ForbiddenError: A CMSUser calls this mutation
   * - UserInputError: ProgramID not found in this state's programs
   */
  createContract: CreateContractPayload;
  /**
   * createContractQuestion creates a new question for the given Contract
   * A CMS User can add text to a note field and append a document to their question
   * They can also specify a due date, and specify rate IDs that are associated with the question
   *
   * This can only be called by a CMSUser
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMSUser called this
   *     - A CMS user with unassigned division
   * - UserInputError
   *     - A package cannot be found with the given `contractID`
   *     - The contract is in the DRAFT state
   *     - The due date is in the past
   *     - The rateIDs are not associated with the package
   */
  createContractQuestion: CreateContractQuestionPayload;
  /**
   * createContractQuestionResponse creates a new response for the given question
   * A State User can add text to a note field and append a document to their response
   *
   * This can only be called by a StateUser
   *
   * Errors:
   * - ForbiddenError:
   *     - A non StateUser called this
   * - UserInputError
   *     - A Question cannot be found given `questionID`
   */
  createContractQuestionResponse: CreateContractQuestionResponsePayload;
  /**
   * createHealthPlanPackage creates a new HealthPlanPackage.
   *
   * The new HealthPlanPackage is created with a single HealthPlanRevision with
   * the information specified in the input parameters. The created package will have
   * the DRAFT status. The stateCode of the package will be set to the state the
   * user that calls this mutation is from.
   *
   * This can only be called by StateUsers
   *
   * Errors:
   * - ForbiddenError: A CMSUser calls this mutation
   * - UserInputError: ProgramID not found in this state's programs
   */
  createHealthPlanPackage: CreateHealthPlanPackagePayload;
  createOauthClient: CreateOauthClientPayload;
  /**
   * createRateQuestion creates a new Question for the given rate
   * A CMS User can add text to a note field and append a document to their question
   * They can also specify a due date, and specify rate IDs that are associated with the question
   *
   * This can only be called by a CMSUser
   *
   * Errors:
   * - ForbiddenError:
   * - A non CMSUser called this
   * - A CMS user with unassigned division
   * - UserInputError
   * - A rate cannot be found with the given `rateID`
   * - The rate is in the DRAFT state
   * - The due date is in the past
   */
  createRateQuestion: CreateRateQuestionPayload;
  createRateQuestionResponse: CreateRateQuestionResponsePayload;
  deleteOauthClient: DeleteOauthClientPayload;
  /**
   * submitContract submits the given package for review by CMS.
   *
   * This can only be called by a StateUser from the state the package is for.
   * The package must be either in DRAFT or UNLOCKED state to be submitted
   * On resubmit the `submittedReason` field must be filled out.
   * The submission must be complete for this mutation to succeed. All required fields
   * in the ContractFormData and RateFormData must be filled out correctly.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A CMSUser called this
   *     - A state user from a different state called this.
   * - UserInputError
   *     - A package cannot be found with the given `pkgID`
   *     - The contract and or rates do not have all required fields filled out
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to submit a package in the SUBMITTED or RESUBMITTED state
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to find a package
   *         - Postgres returns error when attempting to update a package
   *         - Attempt to find state programs from json file returns an error
   *     - EMAIL_ERROR
   *
   *         - Sending state or CMS email failed.
   */
  submitContract: SubmitContractPayload;
  /**
   * submitHealthPlanPackage submits the given package for review by CMS.
   *
   * This can only be called by a StateUser from the state the package is for.
   * The package must be either in DRAFT or UNLOCKED state to be submitted
   * On resubmit the `submittedReason` field must be filled out.
   * The submission must be complete for this mutation to succeed. All required fields
   * in the healthPlanFormData must be filled out correctly.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A CMSUser called this
   *     - A state user from a different state called this.
   * - UserInputError
   *     - A package cannot be found with the given `pkgID`
   *     - The healthPlanFormData does not have all required field filled out
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to find a package
   *         - Postgres returns error when attempting to update a package
   *         - Attempt to find state programs from json file returns an error
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to submit a package in the SUBMITTED or RESUBMITTED state
   *     - PROTO_DECODE_ERROR
   *         - Failed to decode draft proto
   *     - EMAIL_ERROR
   *         - Sending state or CMS email failed.
   */
  submitHealthPlanPackage: SubmitHealthPlanPackagePayload;
  /**
   * submitRate will submit an unlocked rate and return the submitted rate data.
   *
   * This can only be called by a StateUser.
   * The rate must be in the DRAFT or UNLOCKED state to be submitted.
   *
   * Errors:
   * - ForbiddenError:
   *     - A non State user called this
   * - UserInputError
   *     - A rate cannot be found with the given `rateID`
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to finding rate
   *         - Postgres returns error when attempting to update rate
   *         - Postgres returns error when attempting to submit rate
   *         - Postgres returns error when both rateID or rateRevisionID are blank.
   *         - Postgres returns error when current rate revision to submit cannot be found
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to unlock a rate in the DRAFT or UNLOCKED state
   */
  submitRate: SubmitRatePayload;
  /** unoWithdrawSubmission is a CMS user only action to undo a submission widthdrawal, which includes contract and and child rates withdrawn together. */
  undoWithdrawContract: UndoWithdrawContractPayload;
  /**
   * undoWithdrawRate is CMS user only action to undo a rate withdraw
   *
   * Errors:
   * - ForbiddenError:
   * - A non CMS/CMS Approver user called this
   * - UserInputError:
   * - Rate is not in the correct consolidated status: WITHDRAWN
   * - A associated contract is not in the correct consolidated status: SUBMITTED or RESUBMITTED
   * - INTERNAL_SERVER_ERROR
   * - DB_ERROR
   * - A rate cannot be found
   * - Contracts that rate was withdrawn from cannot be found
   * - Issues restoring relationships between rate and contracts
   */
  undoWithdrawRate?: Maybe<UndoWithdrawRatePayload>;
  /**
   * unlockHealthPlanPackage returns a submitted package to the state for additional
   * edits.
   *
   * This can only be called by a CMSUser.
   * The package must be in the SUBMITTED or RESUBMITTED state to be unlocked.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMSuser called this
   * - UserInputError
   *     - A package cannot be found with the given `pkgID`
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to finding a package
   *         - Postgres returns error when attempting to update a package
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to unlock a package in the DRAFT or UNLOCKED state
   *     - PROTO_DECODE_ERROR
   *         - Failed to decode draft proto
   *     - EMAIL_ERROR
   *         - Sending state or CMS email failed.
   */
  unlockContract: UnlockContractPayload;
  /**
   * unlockHealthPlanPackage returns a submitted package to the state for additional
   * edits.
   *
   * This can only be called by a CMSUser.
   * The package must be in the SUBMITTED or RESUBMITTED state to be unlocked.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMSuser called this
   * - UserInputError
   *     - A package cannot be found with the given `pkgID`
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to finding a package
   *         - Postgres returns error when attempting to update a package
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to unlock a package in the DRAFT or UNLOCKED state
   *     - PROTO_DECODE_ERROR
   *         - Failed to decode draft proto
   *     - EMAIL_ERROR
   *         - Sending state or CMS email failed.
   */
  unlockHealthPlanPackage: UnlockHealthPlanPackagePayload;
  /**
   * unlockRate returns a submitted package to the state for additional edits.
   *
   * This can only be called by a CMSUser.
   * The rate must be in the SUBMITTED or RESUBMITTED state to be unlocked.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMSuser called this
   * - UserInputError
   *     - A rate cannot be found with the given `rateID`
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to finding rate
   *         - Postgres returns error when attempting to update rate
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to unlock a rate in the DRAFT or UNLOCKED state
   *     - EMAIL_ERROR
   *         - Sending state or CMS email failed.
   */
  unlockRate: UnlockRatePayload;
  /**
   * updateContract can be used to update fields on the contract
   * as opposed to an individual revision
   */
  updateContract: UpdateContractPayload;
  /**
   * updateContractDraftRevision updates a contract's draft revision with the current
   * state of the form.
   *
   * The contract must be either in the DRAFT or UNLOCKED state.
   * Only a state user from the state this package is attached to can call this mutation
   *
   * Errors:
   * - ForbiddenError:
   * - A CMSUser called this
   * - A state user from a different state called this.
   * UserInputError:
   * - The package is in the LOCKED or RESUBMITTED status
   * - A package cannot be found with the given `contractID`
   */
  updateContractDraftRevision: UpdateContractDraftRevisionPayload;
  /**
   * updateDivisionAssignment updates CMS user division assignment.
   *
   * This can only be called by an AdminUser.
   * The cmsUserID must be a CMSUser's id, not a state user
   *
   * Errors:
   * - ForbiddenError:
   *     - A non AdminUser called this
   * - UserInputError
   *     - cmsUserID was not a CMSUser's ID
   *     - stateCodes included an invalid state code
   */
  updateDivisionAssignment: UpdateCmsUserPayload;
  /**
   * updateDraftContractRates updates the rates associated with a DRAFT contract revision.
   * It takes in an array of rate inputs, which can be new rates, updated rates, or linked rates.
   * The API will make the necessary data changes to make the data match the update, including
   * unlinking removed rates
   *
   * Errors:
   * - ForbiddenError:
   *     - A CMSUser called this
   *     - A state user from a different state called this.
   * - UserInputError:
   *     - any of the linked or update rates' ids don't exist
   *     - attempts to update the data of a nibling rate
   *     - attempts to simply link a child rate
   *     - The package is in the LOCKED or RESUBMITTED status
   *     - A package cannot be found with the given `pkgID`
   */
  updateDraftContractRates: UpdateDraftContractRatesPayload;
  /** updateEmailSettings updates the email settings the MC Review app */
  updateEmailSettings: UpdateEmailSettingsPayload;
  /**
   * updateHealthPlanFormData updates a single package with the current
   * state of the form encoded as a protobuf.
   *
   * The package must be either in the DRAFT or UNLOCKED state.
   * Only a state user from the state this package is attached to can call this mutation
   *
   * There are some fields in the healthPlanFormData type that must not be modified
   * by this mutation. They are set on the initial submission and are only changed by the server:
   * - id
   * - stateCode
   * - stateNumber
   * - createdAt
   * - updatedAt
   *
   * Errors:
   * - ForbiddenError:
   *     - A CMSUser called this
   *     - A state user from a different state called this.
   * - UserInputError:
   *     - The healthPlanFormData proto did not decode correctly
   *     - The healthPlanFormData decodes to a LockedHealthPlanFormData
   *     - The package is in the LOCKED or RESUBMITTED status
   *     - A package cannot be found with the given `pkgID`
   *     - The healthPlanFormData includes changes to any of the fields that are fixed on submission
   */
  updateHealthPlanFormData: UpdateHealthPlanFormDataPayload;
  updateOauthClient: UpdateOauthClientPayload;
  /**
   * updateStateAssignment updates an individual CMSUser state assignments.
   *
   * This can only be called by an AdminUser or a DMCO CMS user.
   * The cmsUserID must be a CMSUser's id, not a state user
   *
   * Errors:
   * - ForbiddenError:
   * - A non AdminUser called this
   * - A non DMCO CMS user called this
   * - UserInputError
   * - cmsUserID was not a CMSUser's ID
   * - stateCodes included an invalid state code
   */
  updateStateAssignment: UpdateCmsUserPayload;
  /**
   * updateStateAssignmentByState updates a group of CMSUsers to be assigned to a given state.
   *
   * This can only be called by an AdminUser or a DMCO CMS user.
   * The cmsUserID must be a CMSUser's id, not a state user
   *
   * Errors:
   * - ForbiddenError:
   * - A non AdminUser called this
   * - A non DMCO CMS user called this
   * - UserInputError
   * - cmsUserID was not a CMSUser's ID
   * - stateCodes included an invalid state code
   */
  updateStateAssignmentsByState: UpdateStateAssignmentsByStatePayload;
  /**
   * withdrawSubmission is a CMS user only action to withdraw an entire submission package, which includes contract and child rates
   *
   * Errors:
   * - ForbiddenError:
   * - A non CMS/CMS Approver user called this
   * - UserInputError:
   * - A contract is not in the correct submission status: SUBMITTED or RESUBMITTED
   * - A contract is not in the correct review status: UNDER_REVIEW
   * - INTERNAL_SERVER_ERROR
   * - DB_ERROR
   * - A contract cannot be found by id
   */
  withdrawContract: WithdrawContractPayload;
  /**
   * withdrawRate is CMS user only action to withdraw a rate from review
   *
   * Errors:
   * - ForbiddenError:
   * - A non CMS/CMS Approver user called this
   * - UserInputError:
   * - A contract is not in the correct submission status: SUBMITTED or RESUBMITTED
   * - A contract is not in the correct review status: UNDER_REVIEW
   * - INTERNAL_SERVER_ERROR
   * - DB_ERROR
   * - A contract cannot be found by id
   */
  withdrawRate?: Maybe<WithdrawRatePayload>;
};


export type MutationApproveContractArgs = {
  input: ApproveContractInput;
};


export type MutationCreateContractArgs = {
  input: CreateContractInput;
};


export type MutationCreateContractQuestionArgs = {
  input: CreateContractQuestionInput;
};


export type MutationCreateContractQuestionResponseArgs = {
  input: CreateQuestionResponseInput;
};


export type MutationCreateHealthPlanPackageArgs = {
  input: CreateHealthPlanPackageInput;
};


export type MutationCreateOauthClientArgs = {
  input: CreateOauthClientInput;
};


export type MutationCreateRateQuestionArgs = {
  input: CreateRateQuestionInput;
};


export type MutationCreateRateQuestionResponseArgs = {
  input: CreateQuestionResponseInput;
};


export type MutationDeleteOauthClientArgs = {
  input: DeleteOauthClientInput;
};


export type MutationSubmitContractArgs = {
  input: SubmitContractInput;
};


export type MutationSubmitHealthPlanPackageArgs = {
  input: SubmitHealthPlanPackageInput;
};


export type MutationSubmitRateArgs = {
  input: SubmitRateInput;
};


export type MutationUndoWithdrawContractArgs = {
  input: UndoWithdrawContractInput;
};


export type MutationUndoWithdrawRateArgs = {
  input: UndoWithdrawRateInput;
};


export type MutationUnlockContractArgs = {
  input: UnlockContractInput;
};


export type MutationUnlockHealthPlanPackageArgs = {
  input: UnlockHealthPlanPackageInput;
};


export type MutationUnlockRateArgs = {
  input: UnlockRateInput;
};


export type MutationUpdateContractArgs = {
  input: UpdateContractInput;
};


export type MutationUpdateContractDraftRevisionArgs = {
  input: UpdateContractDraftRevisionInput;
};


export type MutationUpdateDivisionAssignmentArgs = {
  input: UpdateDivisionAssignmentInput;
};


export type MutationUpdateDraftContractRatesArgs = {
  input: UpdateDraftContractRatesInput;
};


export type MutationUpdateEmailSettingsArgs = {
  input: UpdateEmailSettingsInput;
};


export type MutationUpdateHealthPlanFormDataArgs = {
  input: UpdateHealthPlanFormDataInput;
};


export type MutationUpdateOauthClientArgs = {
  input: UpdateOauthClientInput;
};


export type MutationUpdateStateAssignmentArgs = {
  input: UpdateStateAssignmentInput;
};


export type MutationUpdateStateAssignmentsByStateArgs = {
  input: UpdateStateAssignmentsByStateInput;
};


export type MutationWithdrawContractArgs = {
  input: WithdrawContractInput;
};


export type MutationWithdrawRateArgs = {
  input: WithdrawRateInput;
};

export type OauthClient = {
  __typename?: 'OauthClient';
  clientId: Scalars['String']['output'];
  clientSecret: Scalars['String']['output'];
  contactEmail?: Maybe<Scalars['String']['output']>;
  createdAt: Scalars['DateTime']['output'];
  description?: Maybe<Scalars['String']['output']>;
  grants: Array<Scalars['String']['output']>;
  id: Scalars['ID']['output'];
  updatedAt: Scalars['DateTime']['output'];
};

/**
 * A package in the system
 * that shares a rate with another package.
 * It's used as a part of RateFormData
 */
export type PackageWithSameRate = {
  __typename?: 'PackageWithSameRate';
  packageId: Scalars['String']['output'];
  packageName: Scalars['String']['output'];
  packageStatus?: Maybe<HealthPlanPackageStatus>;
};

/** The large overarching population of people that the program covers. */
export type PopulationCovered =
  | 'CHIP'
  | 'MEDICAID'
  | 'MEDICAID_AND_CHIP';

export type PopulationCoveredType =
  | 'CHIP'
  | 'MEDICAID'
  | 'MEDICAID_AND_CHIP';

/** Program represents a Managed Care program for the given state */
export type Program = {
  __typename?: 'Program';
  /** The full name for the program */
  fullName: Scalars['String']['output'];
  /** uuid */
  id: Scalars['ID']['output'];
  /** Specifies if a program relates to a rate rather than a contract */
  isRateProgram: Scalars['Boolean']['output'];
  /** A nickname for the program */
  name: Scalars['String']['output'];
};

export type Query = {
  __typename?: 'Query';
  /**
   * fetchContract returns a single contract, linked to revisions and related rates
   * given a contractID
   *
   * It can be called by CMS or State users
   *
   * Errors:
   * - ForbiddenError: A State user requests a contract that belongs to another state
   * - NotFoundError: contract for contractID not found in database
   */
  fetchContract: FetchContractPayload;
  /**
   * fetchCurrentUser returns user information for the currently logged in User
   *
   * If no user is currently logged in, the http request will return a 403 error, no graphQL body will be returned.
   */
  fetchCurrentUser: User;
  /**
   * fetchHealthPlanPackage returns a specific HealthPlanPackage by id
   *
   * If a package with the given ID cannot be found, this query returns undefined
   * CMS users cannot fetch a DRAFT HealthPlanPackage
   *
   * Errors:
   * - ForbiddenError:
   *     - A state user from a different state called this.
   *     - A CMSUser attempted to fetch a DRAFT HealthPlanPackage
   */
  fetchHealthPlanPackage: FetchHealthPlanPackagePayload;
  /**
   * fetchMcReviewSettings returns settings for the MC review app
   *
   * stateAssignments: List of all States in the system with their assigned CMS users.
   *
   * Errors:
   * - ForbiddenError: A State user requests a contract that belongs to another state
   */
  fetchMcReviewSettings: FetchMcReviewSettingsPayload;
  fetchOauthClients: FetchOauthClientsPayload;
  /**
   * fetchRate returns a rate with its revisions, including contract revisions
   * for a given rate's ID
   *
   * It can be called by CMS or State users
   *
   * Errors:
   * - ForbiddenError: This API is not available due to feature flags
   * - NotFoundError: rate for rate.ID not found in database
   */
  fetchRate: FetchRatePayload;
  /**
   * indexContracts returns all of the contracts the current user can see.
   *
   * StateUsers can find all the contracts for their state
   * CMSUsers can find all the contracts that do not have the DRAFT status
   */
  indexContracts: IndexContractsPayload;
  /**
   * indexHealthPlanPackages returns all of the HealthPlanPackages the current user can see.
   *
   * StateUsers can find all the packages for their state
   * CMSUsers can find all the packages that do not have the DRAFT status
   */
  indexHealthPlanPackages: IndexHealthPlanPackagesPayload;
  /**
   * indexRates returns full submitted rates
   * indexRates can be called by CMS and admin users, also used in link rate dropdown
   *
   * Errors:
   * - ForbiddenError: User must be a CMS or Admin type user
   * - NotFoundError:  No submitted rates found
   */
  indexRates: IndexRatesPayload;
  /**
   * indexRatesStripped returns abbreviated rate data
   * Intended for use with CMS dashboards, initially minimal rate query
   *
   *   Errors:
   * - ForbiddenError: User must be a CMS or Admin type user
   * - NotFoundError: No submitted rates found
   */
  indexRatesStripped: IndexRatesStrippedPayload;
  /**
   * indexUsers returns all of the Users in the system.
   *
   * It can only be called by an AdminUser
   *
   * Errors: ForbiddenError: A non-AdminUser called this
   */
  indexUsers: IndexUsersPayload;
};


export type QueryFetchContractArgs = {
  input: FetchContractInput;
};


export type QueryFetchHealthPlanPackageArgs = {
  input: FetchHealthPlanPackageInput;
};


export type QueryFetchOauthClientsArgs = {
  input?: InputMaybe<FetchOauthClientsInput>;
};


export type QueryFetchRateArgs = {
  input: FetchRateInput;
};


export type QueryIndexRatesArgs = {
  input?: InputMaybe<IndexRatesInput>;
};


export type QueryIndexRatesStrippedArgs = {
  input?: InputMaybe<IndexRatesInput>;
};

/**
 * QuestionResponse are responses to Rate or Contract questions, the graphql type has no differentiation between responses
 * for both questions types.
 */
export type QuestionResponse = {
  __typename?: 'QuestionResponse';
  addedBy: StateUser;
  createdAt: Scalars['DateTime']['output'];
  documents: Array<Document>;
  id: Scalars['ID']['output'];
  questionID: Scalars['ID']['output'];
};

/**
 * Rates are rate certifications and their associated actuary contacts and documents
 * State users may create, update, and submit several rates at a time
 */
export type Rate = {
  __typename?: 'Rate';
  /**
   * Synthesized field that represents if a rate's status or
   * reviewStatus should take precedence
   * Options are DRAFT, SUBMITTED, RESUBMITTED, UNLOCKED, WITHDRAWN
   */
  consolidatedStatus: ConsolidatedRateStatus;
  createdAt: Scalars['DateTime']['output'];
  /** The currently modifiable revision of the rate. Only present when rate has a status of DRAFT or UNLOCKED */
  draftRevision?: Maybe<RateRevision>;
  id: Scalars['ID']['output'];
  /** The initial date this rate was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['DateTime']['output']>;
  /**
   * packageSubmissions are a list of all the submissions of this rate and any contracts it
   * was associated with.
   */
  packageSubmissions?: Maybe<Array<RatePackageSubmission>>;
  /** parentContractID is the ID of the contract that last submitted this rate */
  parentContractID: Scalars['ID']['output'];
  /**
   * questions field is an array of questions asked about the rate by CMS. Each questions also contains responses
   * to the question submitted by the State. DRAFT rates will not have questions, only rates that have been submitted
   * , unlocked, or resubmitted. The array is in descending order by createdAt.
   */
  questions?: Maybe<IndexRateQuestionsPayload>;
  /**
   * Where the rate is in the review submission flow
   * Options are UNDER_REVIEW, WITHDRAWN
   */
  reviewStatus: RateReviewStatus;
  /** reviewStatusActions are the who/when/why for review status changes on this contract */
  reviewStatusActions?: Maybe<Array<RateReviewStatusActions>>;
  /**
   * Array of revisions for this rate. Each revision represents a single submission
   * for the rate and contains the full data from when the rate cert was submitted
   */
  revisions: Array<RateRevision>;
  /** Fuller state data for the submitting state */
  state: State;
  /** The state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * A unique auto-incrementing number generated for this rate
   * This value is used to generate the rateName
   */
  stateNumber: Scalars['Int']['output'];
  /**
   * Where the package is in the submission flow.
   * Options are DRAFT, SUBMITTED, RESUBMITTED and UNLOCKED
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: HealthPlanPackageStatus;
  updatedAt: Scalars['DateTime']['output'];
  /** webURL is a URL that will open the MC Review web app to this Rate */
  webURL: Scalars['String']['output'];
  /** Contracts this withdrawn rates was the child or linked to */
  withdrawnFromContracts?: Maybe<Array<Contract>>;
};

export type RateActionType =
  | 'UNDER_REVIEW'
  | 'WITHDRAW';

/** Either new capitation rates (NEW) or updates to previously certified capitation rates (AMENDMENT) */
export type RateAmendmentType =
  | 'AMENDMENT'
  | 'NEW';

/**
 * Determines on what basis the capitation rate is actuarially sound.
 * With RATE_RANGE the state certifies a range of rates
 * from the low to high end of the range as actuarially sound
 */
export type RateCapitationType =
  | 'RATE_CELL'
  | 'RATE_RANGE';

export type RateEdge = {
  __typename?: 'RateEdge';
  node: Rate;
};

/**
 * RateFormData represents the form data that was inputted by the state
 * This type is used for the form data field found on a rate revision
 */
export type RateFormData = {
  __typename?: 'RateFormData';
  /**
   * Is either OACT_TO_ACTUARY or OACT_TO_STATE
   * It specifies whether the state wants CMS to reach out to their actuaries
   * directly or go through them
   */
  actuaryCommunicationPreference?: Maybe<ActuaryCommunication>;
  /**
   * An array of additional ActuaryContacts
   * Each element includes the the name, title/role and email
   */
  addtlActuaryContacts: Array<ActuaryContact>;
  /**
   * The end date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateEnd?: Maybe<Scalars['Date']['output']>;
  /**
   * The start date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateStart?: Maybe<Scalars['Date']['output']>;
  /**
   * An array of ActuaryContacts
   * Each element includes the the name, title/role and email
   * of the actuaries who certified the rate
   */
  certifyingActuaryContacts: Array<ActuaryContact>;
  /** consolidatedRateProgramIDs An array of IDs representing state programs. Deprecated if that's all that exists, or the current ones if they exist. */
  consolidatedRateProgramIDs: Array<Scalars['String']['output']>;
  /** Deprecated an array of IDs representing historic state programs that the rate covers */
  deprecatedRateProgramIDs: Array<Scalars['String']['output']>;
  /**
   * An array of PackageWithSameRate elements
   * which contain the packageName, packageId, and packageStatus
   * These elements represent other packages in the system
   * that are using this rate
   */
  packagesWithSharedRateCerts: Array<PackageWithSameRate>;
  /**
   * Can be 'RATE_CELL' or 'RATE_RANGE'
   * These values represent on what basis the capitation rate is actuarially sound
   */
  rateCapitationType?: Maybe<RateCapitationType>;
  /**
   * Represents the name of the rate.
   * This value is auto generated based on rate, package and state program details
   */
  rateCertificationName?: Maybe<Scalars['String']['output']>;
  /**
   * The date the rate certification was
   * certified/signed by the state's actuary
   */
  rateDateCertified?: Maybe<Scalars['Date']['output']>;
  /**
   * If the rateType is NEW this is the end date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the end date of the
   * rating period for the original rate certification
   */
  rateDateEnd?: Maybe<Scalars['Date']['output']>;
  /**
   * If the rateType is NEW this is the start date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the start date of the
   * rating period for the original rate certification
   */
  rateDateStart?: Maybe<Scalars['Date']['output']>;
  /**
   * Signed certification documents the state uploads
   * Files can be PDF, DOC, or DOCX format
   */
  rateDocuments: Array<GenericDocument>;
  /** An array of IDs representing historic state programs that the rate covers */
  rateProgramIDs: Array<Scalars['String']['output']>;
  /**
   * Can be 'NEW' or 'AMENDMENT'
   * Refers to whether the state is submitting a brand new rate certification
   * or an amendment to an existing rate certification
   */
  rateType?: Maybe<RateAmendmentType>;
  /**
   * Additional documents the state uploads to support a rate cert
   * Files can be PDF, DOC, DOCX, XLSX, CSV format
   */
  supportingDocuments: Array<GenericDocument>;
};

export type RateFormDataInput = {
  /**
   * Is either OACT_TO_ACTUARY or OACT_TO_STATE
   * It specifies whether the state wants CMS to reach out to their actuaries
   * directly or go through them
   */
  actuaryCommunicationPreference?: InputMaybe<ActuaryCommunication>;
  /**
   * An array of additional ActuaryContacts
   * Each element includes the the name, title/role and email
   */
  addtlActuaryContacts?: InputMaybe<Array<ActuaryContactInput>>;
  /**
   * The end date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateEnd?: InputMaybe<Scalars['Date']['input']>;
  /**
   * The start date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateStart?: InputMaybe<Scalars['Date']['input']>;
  /**
   * An array of ActuaryContacts
   * Each element includes the the name, title/role and email
   * of the actuaries who certified the rate
   */
  certifyingActuaryContacts: Array<ActuaryContactInput>;
  /** Deprecated an array of IDs representing historic state programs that the rate covers */
  deprecatedRateProgramIDs: Array<Scalars['String']['input']>;
  /**
   * Can be 'RATE_CELL' or 'RATE_RANGE'
   * These values represent on what basis the capitation rate is actuarially sound
   */
  rateCapitationType?: InputMaybe<RateCapitationType>;
  /**
   * Represents the name of the rate.
   * This value is auto generated based on rate, package and state program details
   */
  rateCertificationName?: InputMaybe<Scalars['String']['input']>;
  /**
   * The date the rate certification was
   * certified/signed by the state's actuary
   */
  rateDateCertified?: InputMaybe<Scalars['Date']['input']>;
  /**
   * If the rateType is NEW this is the end date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the end date of the
   * rating period for the original rate certification
   */
  rateDateEnd?: InputMaybe<Scalars['Date']['input']>;
  /**
   * If the rateType is NEW this is the start date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the start date of the
   * rating period for the original rate certification
   */
  rateDateStart?: InputMaybe<Scalars['Date']['input']>;
  /**
   * Signed certification documents the state uploads
   * Files can be PDF, DOC, or DOCX format
   */
  rateDocuments: Array<GenericDocumentInput>;
  /** An array of IDs representing historic state programs that the rate covers */
  rateProgramIDs: Array<Scalars['String']['input']>;
  /**
   * Can be 'NEW' or 'AMENDMENT'
   * Refers to whether the state is submitting a brand new rate certification
   * or an amendment to an existing rate certification
   */
  rateType?: InputMaybe<RateAmendmentType>;
  /**
   * Additional documents the state uploads to support a rate cert
   * Files can be PDF, DOC, DOCX, XLSX, CSV format
   */
  supportingDocuments: Array<GenericDocumentInput>;
};

/** RateFormDataStripped represents stripped down form data that excludes relational fields. */
export type RateFormDataStripped = {
  __typename?: 'RateFormDataStripped';
  /**
   * The end date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateEnd?: Maybe<Scalars['Date']['output']>;
  /**
   * The start date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateStart?: Maybe<Scalars['Date']['output']>;
  /** Deprecated an array of IDs representing historic state programs that the rate covers */
  deprecatedRateProgramIDs: Array<Scalars['String']['output']>;
  /**
   * Can be 'RATE_CELL' or 'RATE_RANGE'
   * These values represent on what basis the capitation rate is actuarially sound
   */
  rateCapitationType?: Maybe<RateCapitationType>;
  /**
   * Represents the name of the rate.
   * This value is auto generated based on rate, package and state program details
   */
  rateCertificationName?: Maybe<Scalars['String']['output']>;
  /**
   * The date the rate certification was
   * certified/signed by the state's actuary
   */
  rateDateCertified?: Maybe<Scalars['Date']['output']>;
  /**
   * If the rateType is NEW this is the end date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the end date of the
   * rating period for the original rate certification
   */
  rateDateEnd?: Maybe<Scalars['Date']['output']>;
  /**
   * If the rateType is NEW this is the start date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the start date of the
   * rating period for the original rate certification
   */
  rateDateStart?: Maybe<Scalars['Date']['output']>;
  /** An array of IDs representing historic state programs that the rate covers */
  rateProgramIDs: Array<Scalars['String']['output']>;
  /**
   * Can be 'NEW' or 'AMENDMENT'
   * Refers to whether the state is submitting a brand new rate certification
   * or an amendment to an existing rate certification
   */
  rateType?: Maybe<RateAmendmentType>;
};

/**
 * RatePackageSubmission is a snapshot of a contract and all its related rates in time
 * a RatePackageSubmission can be created by the user submitting a contract or a related rate
 */
export type RatePackageSubmission = {
  __typename?: 'RatePackageSubmission';
  /** cause is a hint as to why this submission was created */
  cause: SubmissionReason;
  /** contractRevision is the contract revision current at the time of this package submission */
  contractRevisions: Array<ContractRevision>;
  /** rateRevision are the linked rate revisions current at the time of this package submission */
  rateRevision: RateRevision;
  /** submitInfo provides the submission reason/date/by for this package submission */
  submitInfo: UpdateInformation;
  /** submittedRevisions is a list of contract and/or rate revisions that were submitted to create this package submission */
  submittedRevisions: Array<SubmittableRevision>;
};

/**
 * RateQuestion is a question sent by CMS to the States for a response, associated with a single rate.
 * CMS may upload one or more documents full of questions to a single Question. States submit a
 * QuestionResponse with documents that answer the questions posed by CMS.
 */
export type RateQuestion = {
  __typename?: 'RateQuestion';
  addedBy: CmsUsersUnion;
  createdAt: Scalars['DateTime']['output'];
  division: Division;
  documents: Array<Document>;
  id: Scalars['ID']['output'];
  rateID: Scalars['ID']['output'];
  responses: Array<QuestionResponse>;
};

export type RateQuestionEdge = {
  __typename?: 'RateQuestionEdge';
  node: RateQuestion;
};

export type RateQuestionList = {
  __typename?: 'RateQuestionList';
  edges: Array<RateQuestionEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

/** This status is used to determine the review status of the rate. */
export type RateReviewStatus =
  | 'UNDER_REVIEW'
  | 'WITHDRAWN';

/** RateReviewStatusActions is used for the review status actions on the rate */
export type RateReviewStatusActions = {
  __typename?: 'RateReviewStatusActions';
  /** type of action */
  actionType: RateActionType;
  rateID: Scalars['ID']['output'];
  /** the datetime when the update occurred */
  updatedAt: Scalars['DateTime']['output'];
  /** the user who performed the update */
  updatedBy: UpdatedBy;
  /** the reason provided by the user when performing the update */
  updatedReason: Scalars['String']['output'];
};

/**
 * A rate revision represents a single submission
 * for the rate and contains the full data from when the rate cert was submitted
 */
export type RateRevision = {
  __typename?: 'RateRevision';
  createdAt: Scalars['DateTime']['output'];
  /** The rate related form data that was inputted by the state */
  formData: RateFormData;
  id: Scalars['ID']['output'];
  rate?: Maybe<Rate>;
  rateID: Scalars['String']['output'];
  /** Information on who, when, and why this revision was submitted. */
  submitInfo?: Maybe<UpdateInformation>;
  /**
   * Information about who, when, and why this revision was unlocked.
   * Will be blank on the initial revision.
   */
  unlockInfo?: Maybe<UpdateInformation>;
  updatedAt: Scalars['DateTime']['output'];
};

/**
 * A rate revision represents a single submission
 * for the rate and contains stripped down data from when the rate cert was submitted
 */
export type RateRevisionStripped = {
  __typename?: 'RateRevisionStripped';
  createdAt: Scalars['DateTime']['output'];
  /** The rate related form data that was inputed by the state */
  formData: RateFormDataStripped;
  id: Scalars['ID']['output'];
  rateID: Scalars['String']['output'];
  /** Information on who, when, and why this revision was submitted. */
  submitInfo?: Maybe<UpdateInformation>;
  /**
   * Information about who, when, and why this revision was unlocked.
   * Will be blank on the initial revision.
   */
  unlockInfo?: Maybe<UpdateInformation>;
  updatedAt: Scalars['DateTime']['output'];
};

/** RateStripped is a stripped down version of a Rate, removing many relational fields to provide a faster query. */
export type RateStripped = {
  __typename?: 'RateStripped';
  /**
   * Synthesized field that represents if a rate's status or
   * reviewStatus should take precedence
   * Options are DRAFT, SUBMITTED, RESUBMITTED UNLOCKED, UNDER_REVIEW, WITHDRAWN
   */
  consolidatedStatus: ConsolidatedRateStatus;
  createdAt: Scalars['DateTime']['output'];
  /** The currently modifiable revision of the rate. Only present when rate has a status of DRAFT or UNLOCKED */
  draftRevision?: Maybe<RateRevisionStripped>;
  id: Scalars['ID']['output'];
  /** The initial date this rate was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['DateTime']['output']>;
  /** The latest submitted rate revision */
  latestSubmittedRevision: RateRevisionStripped;
  /** parentContractID is the ID of the contract that last submitted this rate */
  parentContractID: Scalars['ID']['output'];
  /** Contracts this child or linked rate is tied to */
  relatedContracts?: Maybe<Array<RelatedContractStripped>>;
  /**
   * Where the rate is in the review submission flow
   * Options are UNDER_REVIEW, WITHDRAWN
   */
  reviewStatus: RateReviewStatus;
  /** reviewStatusActions are the who/when/why for review status changes on this contract */
  reviewStatusActions?: Maybe<Array<RateReviewStatusActions>>;
  /** Fuller state data for the submitting state */
  state: State;
  /** The state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * A unique auto-incrementing number generated for this rate
   * This value is used to generate the rateName
   */
  stateNumber: Scalars['Int']['output'];
  /**
   * Where the package is in the submission flow.
   * Options are DRAFT, SUBMITTED, RESUBMITTED and UNLOCKED
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: HealthPlanPackageStatus;
  updatedAt: Scalars['DateTime']['output'];
  /** webURL is a URL that will open the MC Review web app to this Rate */
  webURL: Scalars['String']['output'];
};

export type RateStrippedEdge = {
  __typename?: 'RateStrippedEdge';
  node: RateStripped;
};

/**
 * Related Contracts are the contracts tied to the given child/linked rate
 * Only contains the necessary info for displaying the SubmissionWithdrawWarningBanner
 */
export type RelatedContractStripped = {
  __typename?: 'RelatedContractStripped';
  consolidatedStatus: ConsolidatedContractStatus;
  id: Scalars['ID']['output'];
};

/** State is a single US state or territory that operates managed care programs */
export type State = {
  __typename?: 'State';
  /** The state code (e.g. CA, TN) */
  code: Scalars['String']['output'];
  name: Scalars['String']['output'];
  /** A list of the state's Managed Care programs */
  programs: Array<Program>;
};

export type StateAssignment = {
  __typename?: 'StateAssignment';
  assignedCMSUsers: Array<CmsUsersUnion>;
  name: Scalars['String']['output'];
  stateCode: Scalars['String']['output'];
};

export type StateAssignmentUser = {
  __typename?: 'StateAssignmentUser';
  divisionAssignment?: Maybe<Division>;
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will be 'CMS_USER' or 'CMS_APPROVER_USER' */
  role: Scalars['String']['output'];
};

/** Contact information for contacting states regarding their submission */
export type StateContact = {
  __typename?: 'StateContact';
  email?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  titleRole?: Maybe<Scalars['String']['output']>;
};

/** Contact information input for contacting states regarding their submission */
export type StateContactInput = {
  email?: InputMaybe<Scalars['String']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  titleRole?: InputMaybe<Scalars['String']['input']>;
};

/** StateUser is a user that works for a state, submitting packages to be reviewed by CMSUsers */
export type StateUser = {
  __typename?: 'StateUser';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'STATE_USER' */
  role: Scalars['String']['output'];
  state: State;
};

/** SubmissionReason is a hint as to why this PackageSubmission was created */
export type SubmissionReason =
  /** A submission of this contract and zero or more newly created rates */
  | 'CONTRACT_SUBMISSION'
  /** A submission of an unrelated rate, linking it to this contract */
  | 'RATE_LINK'
  /** A submission of one of the rates related to this contract */
  | 'RATE_SUBMISSION'
  /** A submission of a rate related to this contract, removing the link between the two */
  | 'RATE_UNLINK';

export type SubmissionType =
  | 'CONTRACT_AND_RATES'
  | 'CONTRACT_ONLY';

export type SubmitContractInput = {
  contractID: Scalars['ID']['input'];
  /** User given reason this package was re-submitted. Left blank on initial submit. */
  submittedReason?: InputMaybe<Scalars['String']['input']>;
};

export type SubmitContractPayload = {
  __typename?: 'SubmitContractPayload';
  contract: Contract;
};

export type SubmitHealthPlanPackageInput = {
  pkgID: Scalars['ID']['input'];
  /** User given reason this package was re-submitted. Left blank on initial submit. */
  submittedReason?: InputMaybe<Scalars['String']['input']>;
};

export type SubmitHealthPlanPackagePayload = {
  __typename?: 'SubmitHealthPlanPackagePayload';
  pkg: HealthPlanPackage;
};

export type SubmitRateInput = {
  /** Rate related form data to be updated with submission */
  formData?: InputMaybe<RateFormDataInput>;
  rateID: Scalars['ID']['input'];
  /** User given submission description */
  submittedReason?: InputMaybe<Scalars['String']['input']>;
};

export type SubmitRatePayload = {
  __typename?: 'SubmitRatePayload';
  rate: Rate;
};

/** SubmittableRevision is what can appear in a submission */
export type SubmittableRevision = ContractRevision | RateRevision;

export type UndoWithdrawContractInput = {
  contractID: Scalars['ID']['input'];
  updatedReason: Scalars['String']['input'];
};

export type UndoWithdrawContractPayload = {
  __typename?: 'UndoWithdrawContractPayload';
  contract: Contract;
};

export type UndoWithdrawRateInput = {
  rateID: Scalars['ID']['input'];
  updatedReason: Scalars['String']['input'];
};

export type UndoWithdrawRatePayload = {
  __typename?: 'UndoWithdrawRatePayload';
  rate: Rate;
};

export type UnlockContractInput = {
  contractID: Scalars['ID']['input'];
  /** User given reason this contract was unlocked */
  unlockedReason: Scalars['String']['input'];
};

export type UnlockContractPayload = {
  __typename?: 'UnlockContractPayload';
  contract: UnlockedContract;
};

export type UnlockHealthPlanPackageInput = {
  pkgID: Scalars['ID']['input'];
  /** User given reason this package was unlocked */
  unlockedReason: Scalars['String']['input'];
};

export type UnlockHealthPlanPackagePayload = {
  __typename?: 'UnlockHealthPlanPackagePayload';
  pkg: HealthPlanPackage;
};

export type UnlockRateInput = {
  rateID: Scalars['ID']['input'];
  /** User given reason this rate was unlocked */
  unlockedReason: Scalars['String']['input'];
};

export type UnlockRatePayload = {
  __typename?: 'UnlockRatePayload';
  rate: Rate;
};

/**
 * UnlockedContract is a single unlocked contract, holding all the draft form data for a single contract
 * and associated with zero or more Rates
 */
export type UnlockedContract = {
  __typename?: 'UnlockedContract';
  /**
   * Synthesized field that represents if a contract's status or
   * reviewStatus should take precedence
   * Options are DRAFT, SUBMITTED, RESUBMITTED UNLOCKED, UNDER_REVIEW, APPROVED, WITHDRAWN
   */
  consolidatedStatus: ConsolidatedContractStatus;
  createdAt: Scalars['DateTime']['output'];
  /** dateContractDocsExecuted is the first date, if any in which the revisions were submitted with all contract docs executed. Null otherwise. */
  dateContractDocsExecuted?: Maybe<Scalars['DateTime']['output']>;
  /**
   * draftRates are the Rates that this editable submission are related to.
   * On submission they are cemented into a new ContractPackageSubmission
   */
  draftRates: Array<Rate>;
  /** draftRevision is the currently modifiable revision if the rate is DRAFT or UNLOCKED */
  draftRevision: ContractRevision;
  id: Scalars['ID']['output'];
  /** initiallySubmittedAt is the initial date this contract was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['DateTime']['output']>;
  /** lastUpdatedForDisplay is the last time this contract was officially updated. When it's a draft it will be the last updatedAt date. Afterwards it will be the most recent submit or unlock or review action date. */
  lastUpdatedForDisplay: Scalars['DateTime']['output'];
  /** mccrsID is the four digit id in MC-CRS that corresponds to this Contract, if set */
  mccrsID?: Maybe<Scalars['String']['output']>;
  /**
   * packageSubmissions are a snapshot of the contract and its related rates through time
   * each packageSubmission was created by a submission of this contract and/or its related rates
   * a DRAFT Contract will have no packageSubmissions. Returned in _ascending_ order. Most recent
   * submission is in the first position in the array.
   */
  packageSubmissions: Array<ContractPackageSubmission>;
  /**
   * questions field is an array of questions asked about the contract by CMS. Each questions also contains responses
   * to the question submitted by the State. DRAFT contracts will not have questions, only contracts that have been submitted
   * , unlocked, or resubmitted. The array is in descending order by createdAt.
   */
  questions?: Maybe<IndexContractQuestionsPayload>;
  /**
   * Where the contract is in the review submission flow
   * Options are UNDER_REVIEW, APPROVED, WITHDRAWN
   */
  reviewStatus: ContractReviewStatus;
  /** reviewStatusActions are the who/when/why for review status changes on this contract */
  reviewStatusActions?: Maybe<Array<ContractReviewStatusActions>>;
  /** state is fuller state data for the submitting state */
  state: State;
  /** stateCode is the state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * stateNumber is a unique auto-incrementing number identifying this contract
   * This value is used to generate the contractName
   */
  stateNumber: Scalars['Int']['output'];
  /**
   * Where the contract is in the submission flow.
   * Options are DRAFT, SUBMITTED, RESUBMITTED and UNLOCKED
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: UnlockedStatus;
  updatedAt: Scalars['DateTime']['output'];
  /** webURL is a url that will open the MC Review web app to this Contract */
  webURL: Scalars['String']['output'];
  /** Rates withdrawn from this contract submission */
  withdrawnRates?: Maybe<Array<Rate>>;
};

export type UnlockedStatus =
  | 'DRAFT'
  | 'UNLOCKED';

export type UpdateCmsUserPayload = {
  __typename?: 'UpdateCMSUserPayload';
  user: CmsUsersUnion;
};

export type UpdateContractDraftRevisionInput = {
  contractID: Scalars['ID']['input'];
  formData: ContractDraftRevisionFormDataInput;
  /** date the contracts draft revision was last updated at */
  lastSeenUpdatedAt: Scalars['DateTime']['input'];
};

export type UpdateContractDraftRevisionPayload = {
  __typename?: 'UpdateContractDraftRevisionPayload';
  contract: Contract;
};

export type UpdateContractInput = {
  id: Scalars['ID']['input'];
  mccrsID?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateContractPayload = {
  __typename?: 'UpdateContractPayload';
  pkg: HealthPlanPackage;
};

/**
 * UpdateContractRateInput is a swiss army knife for updating rates related to a given contract.
 * Because GQL does not support unions in inputs, we will fake one here by setting the type parameter
 * on this input and the API will validate that the two optional parameters are set correctly given the type.
 */
export type UpdateContractRateInput = {
  /** formData is the rate data for a child rate, REQUIRED for CREATE and UPDATE types, omitted for LINK */
  formData?: InputMaybe<RateFormDataInput>;
  /** rateID is the rateID of the existing rate. This is REQUIRED for LINK and UPDATE types and OMITTED for CREATE */
  rateID?: InputMaybe<Scalars['ID']['input']>;
  /** type indicates the relationship of this rate to the contract */
  type: UpdateContractRateType;
};

/** UpdateContractRateType describes the relationship of the updated rate to this contract */
export type UpdateContractRateType =
  /** CREATE is going to create a new child rate, never seen before. Future updates of this rate will call UPDATE */
  | 'CREATE'
  /** LINK describes a linked nibling to this contract rate */
  | 'LINK'
  /** UPDATE updates the form data for a given child rate, whether previously created for this submission or unlocked */
  | 'UPDATE';

export type UpdateDivisionAssignmentInput = {
  cmsUserID: Scalars['ID']['input'];
  /** divisionAssignment is one of the CMS divisions to which a user is assigned: 'DMCO', 'DMCP', or 'OACT' */
  divisionAssignment?: InputMaybe<Division>;
};

export type UpdateDraftContractRatesInput = {
  contractID: Scalars['ID']['input'];
  /** The updatedAt of the contract draft revision at the time this mutation. This is used for optimistic concurrency control */
  lastSeenUpdatedAt: Scalars['DateTime']['input'];
  /**
   * updatedRates contains ALL the existing rates associated with this contract.
   * This includes rates that were previously linked or previously created (LINK & UPDATE)
   * as well as newly created rates and newly linked rates (CREATE & LINK)
   * any rates that are no longer associated with this contract should be omitted from the list.
   */
  updatedRates: Array<UpdateContractRateInput>;
};

export type UpdateDraftContractRatesPayload = {
  __typename?: 'UpdateDraftContractRatesPayload';
  contract: Contract;
};

export type UpdateEmailSettingsInput = {
  emailConfiguration: EmailConfigurationInput;
};

export type UpdateEmailSettingsPayload = {
  __typename?: 'UpdateEmailSettingsPayload';
  emailConfiguration: EmailConfiguration;
};

export type UpdateHealthPlanFormDataInput = {
  /**
   * base64 encoded HealthPlanFormData protobuf. This contains all the data
   * from the health plan pacakge form that the state user fills out and submits.
   * Its schema can be found in health_plan_form_data.proto
   */
  healthPlanFormData: Scalars['String']['input'];
  /** ID of the package to be updated, must be DRAFT or UNLOCKED */
  pkgID: Scalars['ID']['input'];
};

export type UpdateHealthPlanFormDataPayload = {
  __typename?: 'UpdateHealthPlanFormDataPayload';
  pkg: HealthPlanPackage;
};

/**
 * UpdateInformation is used for the unlockInfo and the submitInfo on HealthPlanRevision.
 * It tracks who, when, and why the submission or unlock was performed.
 */
export type UpdateInformation = {
  __typename?: 'UpdateInformation';
  /** the datetime when the update occured */
  updatedAt: Scalars['DateTime']['output'];
  /** the email of the user who performed the update */
  updatedBy: UpdatedBy;
  /** the reason provided by the user when performing the update */
  updatedReason: Scalars['String']['output'];
};

export type UpdateOauthClientInput = {
  clientId: Scalars['String']['input'];
  contactEmail?: InputMaybe<Scalars['String']['input']>;
  description?: InputMaybe<Scalars['String']['input']>;
  grants?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type UpdateOauthClientPayload = {
  __typename?: 'UpdateOauthClientPayload';
  oauthClient: OauthClient;
};

export type UpdateStateAssignmentInput = {
  cmsUserID: Scalars['ID']['input'];
  /** stateAssignments is an array of stateCodes (e.g. ['CA', 'NM', 'TN']) */
  stateAssignments: Array<Scalars['String']['input']>;
};

export type UpdateStateAssignmentsByStateInput = {
  /** assignedUsers is an array of userIDs (uuids) */
  assignedUsers: Array<Scalars['String']['input']>;
  stateCode: Scalars['ID']['input'];
};

export type UpdateStateAssignmentsByStatePayload = {
  __typename?: 'UpdateStateAssignmentsByStatePayload';
  assignedUsers: Array<CmsUsersUnion>;
  stateCode: Scalars['ID']['output'];
};

export type UpdatedBy = {
  __typename?: 'UpdatedBy';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  role: Scalars['String']['output'];
};

export type User = AdminUser | BusinessOwnerUser | CmsApproverUser | CmsUser | HelpdeskUser | StateUser;

export type UserEdge = {
  __typename?: 'UserEdge';
  node: User;
};

export type WithdrawContractInput = {
  contractID: Scalars['ID']['input'];
  updatedReason: Scalars['String']['input'];
};

export type WithdrawContractPayload = {
  __typename?: 'WithdrawContractPayload';
  contract: Contract;
};

export type WithdrawRateInput = {
  rateID: Scalars['ID']['input'];
  updatedReason: Scalars['String']['input'];
};

export type WithdrawRatePayload = {
  __typename?: 'WithdrawRatePayload';
  rate: Rate;
};

export type ContractFieldsFragmentFragment = { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } };

export type ContractRevisionFragmentFragment = { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } };

export type EmailConfigurationFragmentFragment = { __typename?: 'EmailConfiguration', emailSource: string, devReviewTeamEmails: Array<string>, oactEmails: Array<string>, dmcpReviewEmails: Array<string>, dmcpSubmissionEmails: Array<string>, dmcoEmails: Array<string>, cmsReviewHelpEmailAddress: string, cmsRateHelpEmailAddress: string, helpDeskEmail: string };

export type GenericDocumentFragmentFragment = { __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null };

export type PackageSubmissionsFragmentFragment = { __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> };

export type ContractQuestionListFragmentFragment = { __typename?: 'ContractQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'ContractQuestionEdge', node: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, round: number, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> };

export type RateQuestionListFragmentFragment = { __typename?: 'RateQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'RateQuestionEdge', node: { __typename?: 'RateQuestion', id: string, rateID: string, createdAt: any, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> };

export type QuestionResponseFragmentFragment = { __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> };

export type ContractQuestionEdgeFragmentFragment = { __typename?: 'ContractQuestionEdge', node: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, round: number, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } };

export type RateQuestionEdgeFragmentFragment = { __typename?: 'RateQuestionEdge', node: { __typename?: 'RateQuestion', id: string, rateID: string, createdAt: any, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } };

export type RateFieldsFragmentFragment = { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null };

export type RatePackageSubmissionsFragmentFragment = { __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> };

export type RateRevisionFragmentFragment = { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } };

export type StrippedRateRevisionFragmentFragment = { __typename?: 'RateRevisionStripped', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormDataStripped', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, rateCertificationName?: string | null } };

type SubmittableRevisionsFieldsFragment_ContractRevision_Fragment = { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } };

type SubmittableRevisionsFieldsFragment_RateRevision_Fragment = { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } };

export type SubmittableRevisionsFieldsFragmentFragment = SubmittableRevisionsFieldsFragment_ContractRevision_Fragment | SubmittableRevisionsFieldsFragment_RateRevision_Fragment;

export type UnlockedContractFieldsFragmentFragment = { __typename?: 'UnlockedContract', id: string, status: UnlockedStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, updatedReason?: string | null, dateApprovalReleasedToState?: any | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } };

export type UpdateInformationFieldsFragment = { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } };

export type CmsUserFragmentFragment = { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> };

export type CmsApproverUserFragmentFragment = { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> };

export type StateUserFragmentFragment = { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } };

export type AdminUserFragmentFragment = { __typename?: 'AdminUser', id: string, email: string, role: string, familyName: string, givenName: string };

export type HelpdeskUserFragmentFragment = { __typename?: 'HelpdeskUser', id: string, email: string, role: string, familyName: string, givenName: string };

export type BusinessUserFragmentFragment = { __typename?: 'BusinessOwnerUser', id: string, email: string, role: string, familyName: string, givenName: string };

export type ApproveContractMutationVariables = Exact<{
  input: ApproveContractInput;
}>;


export type ApproveContractMutation = { __typename?: 'Mutation', approveContract?: { __typename?: 'ApproveContractPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, withdrawnRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } | null };

export type CreateApiKeyMutationVariables = Exact<{ [key: string]: never; }>;


export type CreateApiKeyMutation = { __typename?: 'Mutation', createAPIKey: { __typename?: 'CreateAPIKeyPayload', key: string, expiresAt: any } };

export type CreateContractMutationVariables = Exact<{
  input: CreateContractInput;
}>;


export type CreateContractMutation = { __typename?: 'Mutation', createContract: { __typename?: 'CreateContractPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type CreateContractQuestionMutationVariables = Exact<{
  input: CreateContractQuestionInput;
}>;


export type CreateContractQuestionMutation = { __typename?: 'Mutation', createContractQuestion: { __typename?: 'CreateContractQuestionPayload', question: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, role: string, email: string, givenName: string, familyName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string }> } | { __typename?: 'CMSUser', id: string, role: string, email: string, givenName: string, familyName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string }> }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string }> } } };

export type CreateContractQuestionResponseMutationVariables = Exact<{
  input: CreateQuestionResponseInput;
}>;


export type CreateContractQuestionResponseMutation = { __typename?: 'Mutation', createContractQuestionResponse: { __typename?: 'CreateContractQuestionResponsePayload', question: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, role: string, email: string, givenName: string, familyName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string }> } | { __typename?: 'CMSUser', id: string, role: string, email: string, givenName: string, familyName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string }> }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, role: string, email: string, givenName: string, familyName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string }> }> } } };

export type CreateHealthPlanPackageMutationVariables = Exact<{
  input: CreateHealthPlanPackageInput;
}>;


export type CreateHealthPlanPackageMutation = { __typename?: 'Mutation', createHealthPlanPackage: { __typename?: 'CreateHealthPlanPackagePayload', pkg: { __typename?: 'HealthPlanPackage', id: string, stateCode: string, mccrsID?: string | null, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, revisions: Array<{ __typename?: 'HealthPlanRevisionEdge', node: { __typename?: 'HealthPlanRevision', id: string, createdAt: any, formDataProto: string, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null } }> } } };

export type CreateOauthClientMutationVariables = Exact<{
  input: CreateOauthClientInput;
}>;


export type CreateOauthClientMutation = { __typename?: 'Mutation', createOauthClient: { __typename?: 'CreateOauthClientPayload', oauthClient: { __typename?: 'OauthClient', id: string, clientId: string, clientSecret: string, grants: Array<string>, description?: string | null, contactEmail?: string | null, createdAt: any, updatedAt: any } } };

export type CreateRateQuestionMutationVariables = Exact<{
  input: CreateRateQuestionInput;
}>;


export type CreateRateQuestionMutation = { __typename?: 'Mutation', createRateQuestion: { __typename?: 'CreateRateQuestionPayload', question: { __typename?: 'RateQuestion', id: string, rateID: string, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string }> } } };

export type CreateRateQuestionResponseMutationVariables = Exact<{
  input: CreateQuestionResponseInput;
}>;


export type CreateRateQuestionResponseMutation = { __typename?: 'Mutation', createRateQuestionResponse: { __typename?: 'CreateRateQuestionResponsePayload', question: { __typename?: 'RateQuestion', id: string, rateID: string, createdAt: any, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } } };

export type DeleteOauthClientMutationVariables = Exact<{
  input: DeleteOauthClientInput;
}>;


export type DeleteOauthClientMutation = { __typename?: 'Mutation', deleteOauthClient: { __typename?: 'DeleteOauthClientPayload', oauthClient: { __typename?: 'OauthClient', id: string, clientId: string, clientSecret: string, grants: Array<string>, description?: string | null, contactEmail?: string | null, createdAt: any, updatedAt: any } } };

export type SubmitContractMutationVariables = Exact<{
  input: SubmitContractInput;
}>;


export type SubmitContractMutation = { __typename?: 'Mutation', submitContract: { __typename?: 'SubmitContractPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, withdrawnRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type SubmitHealthPlanPackageMutationVariables = Exact<{
  input: SubmitHealthPlanPackageInput;
}>;


export type SubmitHealthPlanPackageMutation = { __typename?: 'Mutation', submitHealthPlanPackage: { __typename?: 'SubmitHealthPlanPackagePayload', pkg: { __typename?: 'HealthPlanPackage', id: string, stateCode: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, revisions: Array<{ __typename?: 'HealthPlanRevisionEdge', node: { __typename?: 'HealthPlanRevision', id: string, createdAt: any, formDataProto: string, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null } }> } } };

export type SubmitRateMutationVariables = Exact<{
  input: SubmitRateInput;
}>;


export type SubmitRateMutation = { __typename?: 'Mutation', submitRate: { __typename?: 'SubmitRatePayload', rate: { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, withdrawnFromContracts?: Array<{ __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }> | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null } } };

export type UndoWithdrawContractMutationVariables = Exact<{
  input: UndoWithdrawContractInput;
}>;


export type UndoWithdrawContractMutation = { __typename?: 'Mutation', undoWithdrawContract: { __typename?: 'UndoWithdrawContractPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, withdrawnRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type UndoWithdrawnRateMutationVariables = Exact<{
  input: UndoWithdrawRateInput;
}>;


export type UndoWithdrawnRateMutation = { __typename?: 'Mutation', undoWithdrawRate?: { __typename?: 'UndoWithdrawRatePayload', rate: { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, withdrawnFromContracts?: Array<{ __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }> | null, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null } } | null };

export type UnlockContractMutationVariables = Exact<{
  input: UnlockContractInput;
}>;


export type UnlockContractMutation = { __typename?: 'Mutation', unlockContract: { __typename?: 'UnlockContractPayload', contract: { __typename?: 'UnlockedContract', id: string, status: UnlockedStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, draftRates: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }>, withdrawnRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, updatedReason?: string | null, dateApprovalReleasedToState?: any | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type UnlockHealthPlanPackageMutationVariables = Exact<{
  input: UnlockHealthPlanPackageInput;
}>;


export type UnlockHealthPlanPackageMutation = { __typename?: 'Mutation', unlockHealthPlanPackage: { __typename?: 'UnlockHealthPlanPackagePayload', pkg: { __typename?: 'HealthPlanPackage', id: string, stateCode: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, revisions: Array<{ __typename?: 'HealthPlanRevisionEdge', node: { __typename?: 'HealthPlanRevision', id: string, createdAt: any, formDataProto: string, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null } }> } } };

export type UnlockRateMutationVariables = Exact<{
  input: UnlockRateInput;
}>;


export type UnlockRateMutation = { __typename?: 'Mutation', unlockRate: { __typename?: 'UnlockRatePayload', rate: { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, withdrawnFromContracts?: Array<{ __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }> | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null } } };

export type UpdateContractMutationVariables = Exact<{
  input: UpdateContractInput;
}>;


export type UpdateContractMutation = { __typename?: 'Mutation', updateContract: { __typename?: 'UpdateContractPayload', pkg: { __typename?: 'HealthPlanPackage', id: string, stateCode: string, mccrsID?: string | null, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, revisions: Array<{ __typename?: 'HealthPlanRevisionEdge', node: { __typename?: 'HealthPlanRevision', id: string, createdAt: any, formDataProto: string, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null } }> } } };

export type UpdateContractDraftRevisionMutationVariables = Exact<{
  input: UpdateContractDraftRevisionInput;
}>;


export type UpdateContractDraftRevisionMutation = { __typename?: 'Mutation', updateContractDraftRevision: { __typename?: 'UpdateContractDraftRevisionPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type UpdateDivisionAssignmentMutationVariables = Exact<{
  input: UpdateDivisionAssignmentInput;
}>;


export type UpdateDivisionAssignmentMutation = { __typename?: 'Mutation', updateDivisionAssignment: { __typename?: 'UpdateCMSUserPayload', user: { __typename: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } } };

export type UpdateDraftContractRatesMutationVariables = Exact<{
  input: UpdateDraftContractRatesInput;
}>;


export type UpdateDraftContractRatesMutation = { __typename?: 'Mutation', updateDraftContractRates: { __typename?: 'UpdateDraftContractRatesPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type UpdateEmailSettingsMutationVariables = Exact<{
  input: UpdateEmailSettingsInput;
}>;


export type UpdateEmailSettingsMutation = { __typename?: 'Mutation', updateEmailSettings: { __typename?: 'UpdateEmailSettingsPayload', emailConfiguration: { __typename?: 'EmailConfiguration', emailSource: string, devReviewTeamEmails: Array<string>, oactEmails: Array<string>, dmcpReviewEmails: Array<string>, dmcpSubmissionEmails: Array<string>, dmcoEmails: Array<string>, cmsReviewHelpEmailAddress: string, cmsRateHelpEmailAddress: string, helpDeskEmail: string } } };

export type UpdateHealthPlanFormDataMutationVariables = Exact<{
  input: UpdateHealthPlanFormDataInput;
}>;


export type UpdateHealthPlanFormDataMutation = { __typename?: 'Mutation', updateHealthPlanFormData: { __typename?: 'UpdateHealthPlanFormDataPayload', pkg: { __typename?: 'HealthPlanPackage', id: string, stateCode: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, revisions: Array<{ __typename?: 'HealthPlanRevisionEdge', node: { __typename?: 'HealthPlanRevision', id: string, createdAt: any, formDataProto: string, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null } }> } } };

export type UpdateOauthClientMutationVariables = Exact<{
  input: UpdateOauthClientInput;
}>;


export type UpdateOauthClientMutation = { __typename?: 'Mutation', updateOauthClient: { __typename?: 'UpdateOauthClientPayload', oauthClient: { __typename?: 'OauthClient', id: string, clientId: string, clientSecret: string, description?: string | null, contactEmail?: string | null, grants: Array<string>, createdAt: any, updatedAt: any } } };

export type UpdateStateAssignmentMutationVariables = Exact<{
  input: UpdateStateAssignmentInput;
}>;


export type UpdateStateAssignmentMutation = { __typename?: 'Mutation', updateStateAssignment: { __typename?: 'UpdateCMSUserPayload', user: { __typename: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } } };

export type UpdateStateAssignmentsByStateMutationVariables = Exact<{
  input: UpdateStateAssignmentsByStateInput;
}>;


export type UpdateStateAssignmentsByStateMutation = { __typename?: 'Mutation', updateStateAssignmentsByState: { __typename?: 'UpdateStateAssignmentsByStatePayload', stateCode: string, assignedUsers: Array<{ __typename: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }> } };

export type WithdrawContractMutationVariables = Exact<{
  input: WithdrawContractInput;
}>;


export type WithdrawContractMutation = { __typename?: 'Mutation', withdrawContract: { __typename?: 'WithdrawContractPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, withdrawnRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type WithdrawRateMutationVariables = Exact<{
  input: WithdrawRateInput;
}>;


export type WithdrawRateMutation = { __typename?: 'Mutation', withdrawRate?: { __typename?: 'WithdrawRatePayload', rate: { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, withdrawnFromContracts?: Array<{ __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }> | null, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null } } | null };

export type FetchContractQueryVariables = Exact<{
  input: FetchContractInput;
}>;


export type FetchContractQuery = { __typename?: 'Query', fetchContract: { __typename?: 'FetchContractPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, withdrawnRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type FetchContractWithQuestionsQueryVariables = Exact<{
  input: FetchContractInput;
}>;


export type FetchContractWithQuestionsQuery = { __typename?: 'Query', fetchContract: { __typename?: 'FetchContractPayload', contract: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | null, draftRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, withdrawnRates?: Array<{ __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null }> | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, questions?: { __typename?: 'IndexContractQuestionsPayload', DMCOQuestions: { __typename?: 'ContractQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'ContractQuestionEdge', node: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, round: number, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> }, DMCPQuestions: { __typename?: 'ContractQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'ContractQuestionEdge', node: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, round: number, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> }, OACTQuestions: { __typename?: 'ContractQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'ContractQuestionEdge', node: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, round: number, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> } } | null, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } } };

export type FetchCurrentUserQueryVariables = Exact<{ [key: string]: never; }>;


export type FetchCurrentUserQuery = { __typename?: 'Query', fetchCurrentUser: { __typename?: 'AdminUser', id: string, email: string, role: string, familyName: string, givenName: string } | { __typename?: 'BusinessOwnerUser', id: string, email: string, role: string, familyName: string, givenName: string } | { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'HelpdeskUser', id: string, email: string, role: string, familyName: string, givenName: string } | { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } };

export type FetchHealthPlanPackageQueryVariables = Exact<{
  input: FetchHealthPlanPackageInput;
}>;


export type FetchHealthPlanPackageQuery = { __typename?: 'Query', fetchHealthPlanPackage: { __typename?: 'FetchHealthPlanPackagePayload', pkg: { __typename?: 'HealthPlanPackage', id: string, stateCode: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, mccrsID?: string | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, revisions: Array<{ __typename?: 'HealthPlanRevisionEdge', node: { __typename?: 'HealthPlanRevision', id: string, createdAt: any, formDataProto: string, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null } }> } } };

export type FetchHealthPlanPackageWithQuestionsQueryVariables = Exact<{
  input: FetchHealthPlanPackageInput;
}>;


export type FetchHealthPlanPackageWithQuestionsQuery = { __typename?: 'Query', fetchHealthPlanPackage: { __typename?: 'FetchHealthPlanPackagePayload', pkg: { __typename?: 'HealthPlanPackage', id: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, stateCode: string, mccrsID?: string | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, revisions: Array<{ __typename?: 'HealthPlanRevisionEdge', node: { __typename?: 'HealthPlanRevision', id: string, createdAt: any, formDataProto: string, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null } }>, questions?: { __typename?: 'IndexContractQuestionsPayload', DMCOQuestions: { __typename?: 'ContractQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'ContractQuestionEdge', node: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, round: number, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> }, DMCPQuestions: { __typename?: 'ContractQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'ContractQuestionEdge', node: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, round: number, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> }, OACTQuestions: { __typename?: 'ContractQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'ContractQuestionEdge', node: { __typename?: 'ContractQuestion', id: string, contractID: string, createdAt: any, division: Division, round: number, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> } } | null } } };

export type FetchMcReviewSettingsQueryVariables = Exact<{ [key: string]: never; }>;


export type FetchMcReviewSettingsQuery = { __typename?: 'Query', fetchMcReviewSettings: { __typename?: 'FetchMcReviewSettingsPayload', emailConfiguration?: { __typename?: 'EmailConfiguration', emailSource: string, devReviewTeamEmails: Array<string>, oactEmails: Array<string>, dmcpReviewEmails: Array<string>, dmcpSubmissionEmails: Array<string>, dmcoEmails: Array<string>, cmsReviewHelpEmailAddress: string, cmsRateHelpEmailAddress: string, helpDeskEmail: string } | null, stateAssignments: Array<{ __typename?: 'StateAssignment', stateCode: string, name: string, assignedCMSUsers: Array<{ __typename: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }> }> } };

export type FetchOauthClientsQueryVariables = Exact<{
  input?: InputMaybe<FetchOauthClientsInput>;
}>;


export type FetchOauthClientsQuery = { __typename?: 'Query', fetchOauthClients: { __typename?: 'FetchOauthClientsPayload', oauthClients: Array<{ __typename?: 'OauthClient', id: string, clientId: string, clientSecret: string, grants: Array<string>, description?: string | null, contactEmail?: string | null, createdAt: any, updatedAt: any }> } };

export type FetchRateQueryVariables = Exact<{
  input: FetchRateInput;
}>;


export type FetchRateQuery = { __typename?: 'Query', fetchRate: { __typename?: 'FetchRatePayload', rate: { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, withdrawnFromContracts?: Array<{ __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }> | null, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null } } };

export type FetchRateWithQuestionsQueryVariables = Exact<{
  input: FetchRateInput;
}>;


export type FetchRateWithQuestionsQuery = { __typename?: 'Query', fetchRate: { __typename?: 'FetchRatePayload', rate: { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, withdrawnFromContracts?: Array<{ __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, webURL: string, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, dateContractDocsExecuted?: any | null, stateCode: string, mccrsID?: string | null, stateNumber: number, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }, rateRevisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }> }>, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, dateApprovalReleasedToState?: any | null, updatedReason?: string | null, contractID: string, actionType: ContractActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }> | null, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, questions?: { __typename?: 'IndexRateQuestionsPayload', DMCOQuestions: { __typename?: 'RateQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'RateQuestionEdge', node: { __typename?: 'RateQuestion', id: string, rateID: string, createdAt: any, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> }, DMCPQuestions: { __typename?: 'RateQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'RateQuestionEdge', node: { __typename?: 'RateQuestion', id: string, rateID: string, createdAt: any, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> }, OACTQuestions: { __typename?: 'RateQuestionList', totalCount?: number | null, edges: Array<{ __typename?: 'RateQuestionEdge', node: { __typename?: 'RateQuestion', id: string, rateID: string, createdAt: any, division: Division, addedBy: { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> }, documents: Array<{ __typename?: 'Document', s3URL: string, name: string, downloadURL?: string | null }>, responses: Array<{ __typename?: 'QuestionResponse', id: string, questionID: string, createdAt: any, addedBy: { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } }, documents: Array<{ __typename?: 'Document', name: string, s3URL: string, downloadURL?: string | null }> }> } }> } } | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null } } };

export type IndexContractsForDashboardQueryVariables = Exact<{ [key: string]: never; }>;


export type IndexContractsForDashboardQuery = { __typename?: 'Query', indexContracts: { __typename?: 'IndexContractsPayload', totalCount?: number | null, edges: Array<{ __typename?: 'ContractEdge', node: { __typename?: 'Contract', id: string, status: HealthPlanPackageStatus, reviewStatus: ContractReviewStatus, consolidatedStatus: ConsolidatedContractStatus, createdAt: any, updatedAt: any, initiallySubmittedAt?: any | null, lastUpdatedForDisplay: any, stateCode: string, stateNumber: number, reviewStatusActions?: Array<{ __typename?: 'ContractReviewStatusActions', updatedAt: any, actionType: ContractActionType }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, draftRevision?: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, submissionType: SubmissionType } } | null, packageSubmissions: Array<{ __typename?: 'ContractPackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any }, contractRevision: { __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, submissionType: SubmissionType } } }> } }> } };

export type IndexHealthPlanPackagesQueryVariables = Exact<{ [key: string]: never; }>;


export type IndexHealthPlanPackagesQuery = { __typename?: 'Query', indexHealthPlanPackages: { __typename?: 'IndexHealthPlanPackagesPayload', totalCount?: number | null, edges: Array<{ __typename?: 'HealthPlanPackageEdge', node: { __typename?: 'HealthPlanPackage', id: string, stateCode: string, mccrsID?: string | null, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, revisions: Array<{ __typename?: 'HealthPlanRevisionEdge', node: { __typename?: 'HealthPlanRevision', id: string, createdAt: any, formDataProto: string, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null } }> } }> } };

export type IndexRatesQueryVariables = Exact<{
  input?: InputMaybe<IndexRatesInput>;
}>;


export type IndexRatesQuery = { __typename?: 'Query', indexRates: { __typename?: 'IndexRatesPayload', totalCount?: number | null, edges: Array<{ __typename?: 'RateEdge', node: { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, packageSubmissions?: Array<{ __typename?: 'RatePackageSubmission', cause: SubmissionReason, submitInfo: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }, submittedRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } } | { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, rateRevision: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, rateDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', id?: string | null, name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }, contractRevisions: Array<{ __typename?: 'ContractRevision', id: string, createdAt: any, updatedAt: any, contractID: string, contractName: string, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'ContractFormData', programIDs: Array<string>, populationCovered?: PopulationCovered | null, submissionType: SubmissionType, riskBasedContract?: boolean | null, submissionDescription: string, contractType?: ContractType | null, contractExecutionStatus?: ContractExecutionStatus | null, contractDateStart?: any | null, contractDateEnd?: any | null, managedCareEntities: Array<ManagedCareEntity>, federalAuthorities: Array<FederalAuthority>, inLieuServicesAndSettings?: boolean | null, modifiedBenefitsProvided?: boolean | null, modifiedGeoAreaServed?: boolean | null, modifiedMedicaidBeneficiaries?: boolean | null, modifiedRiskSharingStrategy?: boolean | null, modifiedIncentiveArrangements?: boolean | null, modifiedWitholdAgreements?: boolean | null, modifiedStateDirectedPayments?: boolean | null, modifiedPassThroughPayments?: boolean | null, modifiedPaymentsForMentalDiseaseInstitutions?: boolean | null, modifiedMedicalLossRatioStandards?: boolean | null, modifiedOtherFinancialPaymentIncentive?: boolean | null, modifiedEnrollmentProcess?: boolean | null, modifiedGrevienceAndAppeal?: boolean | null, modifiedNetworkAdequacyStandards?: boolean | null, modifiedLengthOfContract?: boolean | null, modifiedNonRiskPaymentArrangements?: boolean | null, statutoryRegulatoryAttestation?: boolean | null, statutoryRegulatoryAttestationDescription?: string | null, stateContacts: Array<{ __typename?: 'StateContact', name?: string | null, titleRole?: string | null, email?: string | null }>, supportingDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }>, contractDocuments: Array<{ __typename?: 'GenericDocument', id?: string | null, name: string, s3URL: string, sha256: string, dateAdded?: any | null, downloadURL?: string | null }> } }> }> | null, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null } }> } };

export type IndexRatesForDashboardQueryVariables = Exact<{
  input?: InputMaybe<IndexRatesInput>;
}>;


export type IndexRatesForDashboardQuery = { __typename?: 'Query', indexRates: { __typename?: 'IndexRatesPayload', totalCount?: number | null, edges: Array<{ __typename?: 'RateEdge', node: { __typename?: 'Rate', id: string, webURL: string, createdAt: any, updatedAt: any, stateCode: string, stateNumber: number, parentContractID: string, status: HealthPlanPackageStatus, initiallySubmittedAt?: any | null, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, draftRevision?: { __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } } | null, revisions: Array<{ __typename?: 'RateRevision', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormData', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, consolidatedRateProgramIDs: Array<string>, rateCertificationName?: string | null, actuaryCommunicationPreference?: ActuaryCommunication | null, certifyingActuaryContacts: Array<{ __typename?: 'ActuaryContact', name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, addtlActuaryContacts: Array<{ __typename?: 'ActuaryContact', name?: string | null, titleRole?: string | null, email?: string | null, actuarialFirm?: ActuarialFirm | null, actuarialFirmOther?: string | null }>, packagesWithSharedRateCerts: Array<{ __typename?: 'PackageWithSameRate', packageName: string, packageId: string, packageStatus?: HealthPlanPackageStatus | null }> } }>, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, updatedReason: string, rateID: string, actionType: RateActionType, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } }> | null } }> } };

export type IndexRatesStrippedQueryVariables = Exact<{
  input?: InputMaybe<IndexRatesInput>;
}>;


export type IndexRatesStrippedQuery = { __typename?: 'Query', indexRatesStripped: { __typename?: 'IndexRatesStrippedPayload', totalCount?: number | null, edges: Array<{ __typename?: 'RateStrippedEdge', node: { __typename?: 'RateStripped', id: string, createdAt: any, updatedAt: any, status: HealthPlanPackageStatus, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, initiallySubmittedAt?: any | null, stateCode: string, stateNumber: number, parentContractID: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, actionType: RateActionType }> | null, draftRevision?: { __typename?: 'RateRevisionStripped', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormDataStripped', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, rateCertificationName?: string | null } } | null, latestSubmittedRevision: { __typename?: 'RateRevisionStripped', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormDataStripped', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, rateCertificationName?: string | null } } } }> } };

export type IndexRatesStrippedWithRelatedContractsQueryVariables = Exact<{
  input?: InputMaybe<IndexRatesInput>;
}>;


export type IndexRatesStrippedWithRelatedContractsQuery = { __typename?: 'Query', indexRatesStripped: { __typename?: 'IndexRatesStrippedPayload', totalCount?: number | null, edges: Array<{ __typename?: 'RateStrippedEdge', node: { __typename?: 'RateStripped', id: string, createdAt: any, updatedAt: any, status: HealthPlanPackageStatus, reviewStatus: RateReviewStatus, consolidatedStatus: ConsolidatedRateStatus, initiallySubmittedAt?: any | null, stateCode: string, stateNumber: number, parentContractID: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }, reviewStatusActions?: Array<{ __typename?: 'RateReviewStatusActions', updatedAt: any, actionType: RateActionType }> | null, draftRevision?: { __typename?: 'RateRevisionStripped', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormDataStripped', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, rateCertificationName?: string | null } } | null, latestSubmittedRevision: { __typename?: 'RateRevisionStripped', id: string, rateID: string, createdAt: any, updatedAt: any, unlockInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, submitInfo?: { __typename?: 'UpdateInformation', updatedAt: any, updatedReason: string, updatedBy: { __typename?: 'UpdatedBy', email: string, role: string, familyName: string, givenName: string } } | null, formData: { __typename?: 'RateFormDataStripped', rateType?: RateAmendmentType | null, rateCapitationType?: RateCapitationType | null, rateDateStart?: any | null, rateDateEnd?: any | null, rateDateCertified?: any | null, amendmentEffectiveDateStart?: any | null, amendmentEffectiveDateEnd?: any | null, rateProgramIDs: Array<string>, deprecatedRateProgramIDs: Array<string>, rateCertificationName?: string | null } }, relatedContracts?: Array<{ __typename?: 'RelatedContractStripped', id: string, consolidatedStatus: ConsolidatedContractStatus }> | null } }> } };

export type IndexUsersQueryVariables = Exact<{ [key: string]: never; }>;


export type IndexUsersQuery = { __typename?: 'Query', indexUsers: { __typename?: 'IndexUsersPayload', totalCount?: number | null, edges: Array<{ __typename?: 'UserEdge', node: { __typename?: 'AdminUser', id: string, email: string, role: string, familyName: string, givenName: string } | { __typename?: 'BusinessOwnerUser' } | { __typename?: 'CMSApproverUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'CMSUser', id: string, email: string, role: string, familyName: string, givenName: string, divisionAssignment?: Division | null, stateAssignments: Array<{ __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> }> } | { __typename?: 'HelpdeskUser' } | { __typename?: 'StateUser', id: string, email: string, role: string, familyName: string, givenName: string, state: { __typename?: 'State', code: string, name: string, programs: Array<{ __typename?: 'Program', id: string, name: string, fullName: string, isRateProgram: boolean }> } } }> } };

export const ContractFieldsFragmentFragmentDoc = gql`
    fragment contractFieldsFragment on Contract {
  id
  status
  reviewStatus
  consolidatedStatus
  createdAt
  updatedAt
  webURL
  initiallySubmittedAt
  lastUpdatedForDisplay
  dateContractDocsExecuted
  stateCode
  mccrsID
  reviewStatusActions {
    updatedAt
    updatedBy {
      email
      role
      familyName
      givenName
    }
    dateApprovalReleasedToState
    updatedReason
    contractID
    actionType
  }
  state {
    code
    name
    programs {
      id
      name
      fullName
      isRateProgram
    }
  }
  stateNumber
}
    `;
export const EmailConfigurationFragmentFragmentDoc = gql`
    fragment emailConfigurationFragment on EmailConfiguration {
  emailSource
  devReviewTeamEmails
  oactEmails
  dmcpReviewEmails
  dmcpSubmissionEmails
  dmcoEmails
  cmsReviewHelpEmailAddress
  cmsRateHelpEmailAddress
  helpDeskEmail
}
    `;
export const UpdateInformationFieldsFragmentDoc = gql`
    fragment updateInformationFields on UpdateInformation {
  updatedAt
  updatedBy {
    email
    role
    familyName
    givenName
  }
  updatedReason
}
    `;
export const GenericDocumentFragmentFragmentDoc = gql`
    fragment genericDocumentFragment on GenericDocument {
  id
  name
  s3URL
  sha256
  dateAdded
  downloadURL
}
    `;
export const SubmittableRevisionsFieldsFragmentFragmentDoc = gql`
    fragment submittableRevisionsFieldsFragment on SubmittableRevision {
  ... on ContractRevision {
    id
    createdAt
    updatedAt
    contractID
    contractName
    submitInfo {
      updatedAt
      updatedBy {
        email
        role
        familyName
        givenName
      }
      updatedReason
    }
    unlockInfo {
      updatedAt
      updatedBy {
        email
        role
        familyName
        givenName
      }
      updatedReason
    }
    formData {
      programIDs
      populationCovered
      submissionType
      riskBasedContract
      submissionDescription
      stateContacts {
        name
        titleRole
        email
      }
      supportingDocuments {
        ...genericDocumentFragment
      }
      contractType
      contractExecutionStatus
      contractDocuments {
        ...genericDocumentFragment
      }
      contractDateStart
      contractDateEnd
      managedCareEntities
      federalAuthorities
      inLieuServicesAndSettings
      modifiedBenefitsProvided
      modifiedGeoAreaServed
      modifiedMedicaidBeneficiaries
      modifiedRiskSharingStrategy
      modifiedIncentiveArrangements
      modifiedWitholdAgreements
      modifiedStateDirectedPayments
      modifiedPassThroughPayments
      modifiedPaymentsForMentalDiseaseInstitutions
      modifiedMedicaidBeneficiaries
      modifiedMedicalLossRatioStandards
      modifiedOtherFinancialPaymentIncentive
      modifiedEnrollmentProcess
      modifiedGrevienceAndAppeal
      modifiedNetworkAdequacyStandards
      modifiedLengthOfContract
      modifiedNonRiskPaymentArrangements
      statutoryRegulatoryAttestation
      statutoryRegulatoryAttestationDescription
    }
  }
  ... on RateRevision {
    id
    rateID
    createdAt
    updatedAt
    unlockInfo {
      ...updateInformationFields
    }
    submitInfo {
      ...updateInformationFields
    }
    formData {
      rateType
      rateCapitationType
      rateDocuments {
        ...genericDocumentFragment
      }
      supportingDocuments {
        ...genericDocumentFragment
      }
      rateDateStart
      rateDateEnd
      rateDateCertified
      amendmentEffectiveDateStart
      amendmentEffectiveDateEnd
      rateProgramIDs
      deprecatedRateProgramIDs
      consolidatedRateProgramIDs
      rateCertificationName
      certifyingActuaryContacts {
        id
        name
        titleRole
        email
        actuarialFirm
        actuarialFirmOther
      }
      addtlActuaryContacts {
        id
        name
        titleRole
        email
        actuarialFirm
        actuarialFirmOther
      }
      actuaryCommunicationPreference
      packagesWithSharedRateCerts {
        packageName
        packageId
        packageStatus
      }
    }
  }
}
    ${GenericDocumentFragmentFragmentDoc}
${UpdateInformationFieldsFragmentDoc}`;
export const ContractRevisionFragmentFragmentDoc = gql`
    fragment contractRevisionFragment on ContractRevision {
  id
  createdAt
  updatedAt
  contractID
  contractName
  submitInfo {
    updatedAt
    updatedBy {
      email
      role
      familyName
      givenName
    }
    updatedReason
  }
  unlockInfo {
    updatedAt
    updatedBy {
      email
      role
      familyName
      givenName
    }
    updatedReason
  }
  formData {
    programIDs
    populationCovered
    submissionType
    riskBasedContract
    submissionDescription
    stateContacts {
      name
      titleRole
      email
    }
    supportingDocuments {
      ...genericDocumentFragment
    }
    contractType
    contractExecutionStatus
    contractDocuments {
      ...genericDocumentFragment
    }
    contractDateStart
    contractDateEnd
    managedCareEntities
    federalAuthorities
    inLieuServicesAndSettings
    modifiedBenefitsProvided
    modifiedGeoAreaServed
    modifiedMedicaidBeneficiaries
    modifiedRiskSharingStrategy
    modifiedIncentiveArrangements
    modifiedWitholdAgreements
    modifiedStateDirectedPayments
    modifiedPassThroughPayments
    modifiedPaymentsForMentalDiseaseInstitutions
    modifiedMedicaidBeneficiaries
    modifiedMedicalLossRatioStandards
    modifiedOtherFinancialPaymentIncentive
    modifiedEnrollmentProcess
    modifiedGrevienceAndAppeal
    modifiedNetworkAdequacyStandards
    modifiedLengthOfContract
    modifiedNonRiskPaymentArrangements
    statutoryRegulatoryAttestation
    statutoryRegulatoryAttestationDescription
  }
}
    ${GenericDocumentFragmentFragmentDoc}`;
export const RateRevisionFragmentFragmentDoc = gql`
    fragment rateRevisionFragment on RateRevision {
  id
  rateID
  createdAt
  updatedAt
  unlockInfo {
    ...updateInformationFields
  }
  submitInfo {
    ...updateInformationFields
  }
  formData {
    rateType
    rateCapitationType
    rateDocuments {
      ...genericDocumentFragment
    }
    supportingDocuments {
      ...genericDocumentFragment
    }
    rateDateStart
    rateDateEnd
    rateDateCertified
    amendmentEffectiveDateStart
    amendmentEffectiveDateEnd
    rateProgramIDs
    deprecatedRateProgramIDs
    consolidatedRateProgramIDs
    rateCertificationName
    certifyingActuaryContacts {
      id
      name
      titleRole
      email
      actuarialFirm
      actuarialFirmOther
    }
    addtlActuaryContacts {
      id
      name
      titleRole
      email
      actuarialFirm
      actuarialFirmOther
    }
    actuaryCommunicationPreference
    packagesWithSharedRateCerts {
      packageName
      packageId
      packageStatus
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}
${GenericDocumentFragmentFragmentDoc}`;
export const PackageSubmissionsFragmentFragmentDoc = gql`
    fragment packageSubmissionsFragment on ContractPackageSubmission {
  cause
  submitInfo {
    ...updateInformationFields
  }
  submittedRevisions {
    ...submittableRevisionsFieldsFragment
  }
  contractRevision {
    ...contractRevisionFragment
  }
  rateRevisions {
    ...rateRevisionFragment
  }
}
    ${UpdateInformationFieldsFragmentDoc}
${SubmittableRevisionsFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}`;
export const CmsUserFragmentFragmentDoc = gql`
    fragment cmsUserFragment on CMSUser {
  id
  email
  role
  familyName
  givenName
  stateAssignments {
    code
    name
    programs {
      id
      name
      fullName
      isRateProgram
    }
  }
  divisionAssignment
}
    `;
export const CmsApproverUserFragmentFragmentDoc = gql`
    fragment cmsApproverUserFragment on CMSApproverUser {
  id
  email
  role
  familyName
  givenName
  stateAssignments {
    code
    name
    programs {
      id
      name
      fullName
      isRateProgram
    }
  }
  divisionAssignment
}
    `;
export const StateUserFragmentFragmentDoc = gql`
    fragment stateUserFragment on StateUser {
  id
  email
  role
  familyName
  givenName
  state {
    code
    name
    programs {
      id
      name
      fullName
      isRateProgram
    }
  }
}
    `;
export const QuestionResponseFragmentFragmentDoc = gql`
    fragment questionResponseFragment on QuestionResponse {
  id
  questionID
  createdAt
  addedBy {
    ... on StateUser {
      ...stateUserFragment
    }
  }
  documents {
    name
    s3URL
    downloadURL
  }
}
    ${StateUserFragmentFragmentDoc}`;
export const ContractQuestionEdgeFragmentFragmentDoc = gql`
    fragment contractQuestionEdgeFragment on ContractQuestionEdge {
  node {
    id
    contractID
    createdAt
    addedBy {
      ... on CMSUser {
        ...cmsUserFragment
      }
      ... on CMSApproverUser {
        ...cmsApproverUserFragment
      }
    }
    division
    round
    documents {
      s3URL
      name
      downloadURL
    }
    responses {
      ...questionResponseFragment
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}
${QuestionResponseFragmentFragmentDoc}`;
export const ContractQuestionListFragmentFragmentDoc = gql`
    fragment contractQuestionListFragment on ContractQuestionList {
  totalCount
  edges {
    ...contractQuestionEdgeFragment
  }
}
    ${ContractQuestionEdgeFragmentFragmentDoc}`;
export const RateQuestionEdgeFragmentFragmentDoc = gql`
    fragment rateQuestionEdgeFragment on RateQuestionEdge {
  node {
    id
    rateID
    createdAt
    addedBy {
      ... on CMSUser {
        ...cmsUserFragment
      }
      ... on CMSApproverUser {
        ...cmsApproverUserFragment
      }
    }
    division
    documents {
      s3URL
      name
      downloadURL
    }
    responses {
      ...questionResponseFragment
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}
${QuestionResponseFragmentFragmentDoc}`;
export const RateQuestionListFragmentFragmentDoc = gql`
    fragment rateQuestionListFragment on RateQuestionList {
  totalCount
  edges {
    ...rateQuestionEdgeFragment
  }
}
    ${RateQuestionEdgeFragmentFragmentDoc}`;
export const RateFieldsFragmentFragmentDoc = gql`
    fragment rateFieldsFragment on Rate {
  id
  webURL
  createdAt
  updatedAt
  stateCode
  stateNumber
  parentContractID
  state {
    code
    name
    programs {
      id
      name
      fullName
      isRateProgram
    }
  }
  status
  initiallySubmittedAt
  reviewStatus
  consolidatedStatus
  reviewStatusActions {
    updatedAt
    updatedBy {
      email
      role
      familyName
      givenName
    }
    updatedReason
    rateID
    actionType
  }
}
    `;
export const RatePackageSubmissionsFragmentFragmentDoc = gql`
    fragment ratePackageSubmissionsFragment on RatePackageSubmission {
  cause
  submitInfo {
    ...updateInformationFields
  }
  submittedRevisions {
    ...submittableRevisionsFieldsFragment
  }
  rateRevision {
    ...rateRevisionFragment
  }
  contractRevisions {
    ...contractRevisionFragment
  }
}
    ${UpdateInformationFieldsFragmentDoc}
${SubmittableRevisionsFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}`;
export const StrippedRateRevisionFragmentFragmentDoc = gql`
    fragment strippedRateRevisionFragment on RateRevisionStripped {
  id
  rateID
  createdAt
  updatedAt
  unlockInfo {
    ...updateInformationFields
  }
  submitInfo {
    ...updateInformationFields
  }
  formData {
    rateType
    rateCapitationType
    rateDateStart
    rateDateEnd
    rateDateCertified
    amendmentEffectiveDateStart
    amendmentEffectiveDateEnd
    rateProgramIDs
    deprecatedRateProgramIDs
    rateCertificationName
  }
}
    ${UpdateInformationFieldsFragmentDoc}`;
export const UnlockedContractFieldsFragmentFragmentDoc = gql`
    fragment unlockedContractFieldsFragment on UnlockedContract {
  id
  status
  reviewStatus
  consolidatedStatus
  createdAt
  updatedAt
  webURL
  initiallySubmittedAt
  lastUpdatedForDisplay
  dateContractDocsExecuted
  stateCode
  mccrsID
  reviewStatusActions {
    updatedAt
    updatedBy {
      email
      role
      familyName
      givenName
    }
    updatedReason
    dateApprovalReleasedToState
    contractID
    actionType
  }
  state {
    code
    name
    programs {
      id
      name
      fullName
      isRateProgram
    }
  }
  stateNumber
}
    `;
export const AdminUserFragmentFragmentDoc = gql`
    fragment adminUserFragment on AdminUser {
  id
  email
  role
  familyName
  givenName
}
    `;
export const HelpdeskUserFragmentFragmentDoc = gql`
    fragment helpdeskUserFragment on HelpdeskUser {
  id
  email
  role
  familyName
  givenName
}
    `;
export const BusinessUserFragmentFragmentDoc = gql`
    fragment businessUserFragment on BusinessOwnerUser {
  id
  email
  role
  familyName
  givenName
}
    `;
export const ApproveContractDocument = gql`
    mutation approveContract($input: ApproveContractInput!) {
  approveContract(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      withdrawnRates {
        ...rateFieldsFragment
        revisions {
          ...rateRevisionFragment
        }
        packageSubmissions {
          ...ratePackageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type ApproveContractMutationFn = Apollo.MutationFunction<ApproveContractMutation, ApproveContractMutationVariables>;

/**
 * __useApproveContractMutation__
 *
 * To run a mutation, you first call `useApproveContractMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useApproveContractMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [approveContractMutation, { data, loading, error }] = useApproveContractMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useApproveContractMutation(baseOptions?: Apollo.MutationHookOptions<ApproveContractMutation, ApproveContractMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<ApproveContractMutation, ApproveContractMutationVariables>(ApproveContractDocument, options);
      }
export type ApproveContractMutationHookResult = ReturnType<typeof useApproveContractMutation>;
export type ApproveContractMutationResult = Apollo.MutationResult<ApproveContractMutation>;
export type ApproveContractMutationOptions = Apollo.BaseMutationOptions<ApproveContractMutation, ApproveContractMutationVariables>;
export const CreateApiKeyDocument = gql`
    mutation createAPIKey {
  createAPIKey {
    key
    expiresAt
  }
}
    `;
export type CreateApiKeyMutationFn = Apollo.MutationFunction<CreateApiKeyMutation, CreateApiKeyMutationVariables>;

/**
 * __useCreateApiKeyMutation__
 *
 * To run a mutation, you first call `useCreateApiKeyMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateApiKeyMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createApiKeyMutation, { data, loading, error }] = useCreateApiKeyMutation({
 *   variables: {
 *   },
 * });
 */
export function useCreateApiKeyMutation(baseOptions?: Apollo.MutationHookOptions<CreateApiKeyMutation, CreateApiKeyMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateApiKeyMutation, CreateApiKeyMutationVariables>(CreateApiKeyDocument, options);
      }
export type CreateApiKeyMutationHookResult = ReturnType<typeof useCreateApiKeyMutation>;
export type CreateApiKeyMutationResult = Apollo.MutationResult<CreateApiKeyMutation>;
export type CreateApiKeyMutationOptions = Apollo.BaseMutationOptions<CreateApiKeyMutation, CreateApiKeyMutationVariables>;
export const CreateContractDocument = gql`
    mutation createContract($input: CreateContractInput!) {
  createContract(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type CreateContractMutationFn = Apollo.MutationFunction<CreateContractMutation, CreateContractMutationVariables>;

/**
 * __useCreateContractMutation__
 *
 * To run a mutation, you first call `useCreateContractMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateContractMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createContractMutation, { data, loading, error }] = useCreateContractMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useCreateContractMutation(baseOptions?: Apollo.MutationHookOptions<CreateContractMutation, CreateContractMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateContractMutation, CreateContractMutationVariables>(CreateContractDocument, options);
      }
export type CreateContractMutationHookResult = ReturnType<typeof useCreateContractMutation>;
export type CreateContractMutationResult = Apollo.MutationResult<CreateContractMutation>;
export type CreateContractMutationOptions = Apollo.BaseMutationOptions<CreateContractMutation, CreateContractMutationVariables>;
export const CreateContractQuestionDocument = gql`
    mutation createContractQuestion($input: CreateContractQuestionInput!) {
  createContractQuestion(input: $input) {
    question {
      id
      contractID
      createdAt
      addedBy {
        ... on CMSUser {
          id
          role
          email
          givenName
          familyName
          divisionAssignment
          stateAssignments {
            code
            name
          }
        }
        ... on CMSApproverUser {
          id
          role
          email
          givenName
          familyName
          divisionAssignment
          stateAssignments {
            code
            name
          }
        }
      }
      division
      documents {
        name
        s3URL
      }
    }
  }
}
    `;
export type CreateContractQuestionMutationFn = Apollo.MutationFunction<CreateContractQuestionMutation, CreateContractQuestionMutationVariables>;

/**
 * __useCreateContractQuestionMutation__
 *
 * To run a mutation, you first call `useCreateContractQuestionMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateContractQuestionMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createContractQuestionMutation, { data, loading, error }] = useCreateContractQuestionMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useCreateContractQuestionMutation(baseOptions?: Apollo.MutationHookOptions<CreateContractQuestionMutation, CreateContractQuestionMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateContractQuestionMutation, CreateContractQuestionMutationVariables>(CreateContractQuestionDocument, options);
      }
export type CreateContractQuestionMutationHookResult = ReturnType<typeof useCreateContractQuestionMutation>;
export type CreateContractQuestionMutationResult = Apollo.MutationResult<CreateContractQuestionMutation>;
export type CreateContractQuestionMutationOptions = Apollo.BaseMutationOptions<CreateContractQuestionMutation, CreateContractQuestionMutationVariables>;
export const CreateContractQuestionResponseDocument = gql`
    mutation createContractQuestionResponse($input: CreateQuestionResponseInput!) {
  createContractQuestionResponse(input: $input) {
    question {
      id
      contractID
      createdAt
      addedBy {
        ... on CMSUser {
          id
          role
          email
          givenName
          familyName
          divisionAssignment
          stateAssignments {
            code
            name
          }
        }
        ... on CMSApproverUser {
          id
          role
          email
          givenName
          familyName
          divisionAssignment
          stateAssignments {
            code
            name
          }
        }
      }
      division
      documents {
        name
        s3URL
      }
      responses {
        id
        questionID
        createdAt
        addedBy {
          id
          role
          email
          givenName
          familyName
          state {
            code
            name
            programs {
              id
              name
              fullName
              isRateProgram
            }
          }
        }
        documents {
          name
          s3URL
        }
      }
    }
  }
}
    `;
export type CreateContractQuestionResponseMutationFn = Apollo.MutationFunction<CreateContractQuestionResponseMutation, CreateContractQuestionResponseMutationVariables>;

/**
 * __useCreateContractQuestionResponseMutation__
 *
 * To run a mutation, you first call `useCreateContractQuestionResponseMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateContractQuestionResponseMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createContractQuestionResponseMutation, { data, loading, error }] = useCreateContractQuestionResponseMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useCreateContractQuestionResponseMutation(baseOptions?: Apollo.MutationHookOptions<CreateContractQuestionResponseMutation, CreateContractQuestionResponseMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateContractQuestionResponseMutation, CreateContractQuestionResponseMutationVariables>(CreateContractQuestionResponseDocument, options);
      }
export type CreateContractQuestionResponseMutationHookResult = ReturnType<typeof useCreateContractQuestionResponseMutation>;
export type CreateContractQuestionResponseMutationResult = Apollo.MutationResult<CreateContractQuestionResponseMutation>;
export type CreateContractQuestionResponseMutationOptions = Apollo.BaseMutationOptions<CreateContractQuestionResponseMutation, CreateContractQuestionResponseMutationVariables>;
export const CreateHealthPlanPackageDocument = gql`
    mutation createHealthPlanPackage($input: CreateHealthPlanPackageInput!) {
  createHealthPlanPackage(input: $input) {
    pkg {
      id
      stateCode
      mccrsID
      state {
        code
        name
        programs {
          id
          name
          fullName
          isRateProgram
        }
      }
      status
      initiallySubmittedAt
      revisions {
        node {
          id
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          createdAt
          formDataProto
        }
      }
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}`;
export type CreateHealthPlanPackageMutationFn = Apollo.MutationFunction<CreateHealthPlanPackageMutation, CreateHealthPlanPackageMutationVariables>;

/**
 * __useCreateHealthPlanPackageMutation__
 *
 * To run a mutation, you first call `useCreateHealthPlanPackageMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateHealthPlanPackageMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createHealthPlanPackageMutation, { data, loading, error }] = useCreateHealthPlanPackageMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useCreateHealthPlanPackageMutation(baseOptions?: Apollo.MutationHookOptions<CreateHealthPlanPackageMutation, CreateHealthPlanPackageMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateHealthPlanPackageMutation, CreateHealthPlanPackageMutationVariables>(CreateHealthPlanPackageDocument, options);
      }
export type CreateHealthPlanPackageMutationHookResult = ReturnType<typeof useCreateHealthPlanPackageMutation>;
export type CreateHealthPlanPackageMutationResult = Apollo.MutationResult<CreateHealthPlanPackageMutation>;
export type CreateHealthPlanPackageMutationOptions = Apollo.BaseMutationOptions<CreateHealthPlanPackageMutation, CreateHealthPlanPackageMutationVariables>;
export const CreateOauthClientDocument = gql`
    mutation createOauthClient($input: CreateOauthClientInput!) {
  createOauthClient(input: $input) {
    oauthClient {
      id
      clientId
      clientSecret
      grants
      description
      contactEmail
      createdAt
      updatedAt
    }
  }
}
    `;
export type CreateOauthClientMutationFn = Apollo.MutationFunction<CreateOauthClientMutation, CreateOauthClientMutationVariables>;

/**
 * __useCreateOauthClientMutation__
 *
 * To run a mutation, you first call `useCreateOauthClientMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateOauthClientMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createOauthClientMutation, { data, loading, error }] = useCreateOauthClientMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useCreateOauthClientMutation(baseOptions?: Apollo.MutationHookOptions<CreateOauthClientMutation, CreateOauthClientMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateOauthClientMutation, CreateOauthClientMutationVariables>(CreateOauthClientDocument, options);
      }
export type CreateOauthClientMutationHookResult = ReturnType<typeof useCreateOauthClientMutation>;
export type CreateOauthClientMutationResult = Apollo.MutationResult<CreateOauthClientMutation>;
export type CreateOauthClientMutationOptions = Apollo.BaseMutationOptions<CreateOauthClientMutation, CreateOauthClientMutationVariables>;
export const CreateRateQuestionDocument = gql`
    mutation createRateQuestion($input: CreateRateQuestionInput!) {
  createRateQuestion(input: $input) {
    question {
      id
      rateID
      addedBy {
        ... on CMSUser {
          ...cmsUserFragment
        }
        ... on CMSApproverUser {
          ...cmsApproverUserFragment
        }
      }
      division
      documents {
        name
        s3URL
      }
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}`;
export type CreateRateQuestionMutationFn = Apollo.MutationFunction<CreateRateQuestionMutation, CreateRateQuestionMutationVariables>;

/**
 * __useCreateRateQuestionMutation__
 *
 * To run a mutation, you first call `useCreateRateQuestionMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateRateQuestionMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createRateQuestionMutation, { data, loading, error }] = useCreateRateQuestionMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useCreateRateQuestionMutation(baseOptions?: Apollo.MutationHookOptions<CreateRateQuestionMutation, CreateRateQuestionMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateRateQuestionMutation, CreateRateQuestionMutationVariables>(CreateRateQuestionDocument, options);
      }
export type CreateRateQuestionMutationHookResult = ReturnType<typeof useCreateRateQuestionMutation>;
export type CreateRateQuestionMutationResult = Apollo.MutationResult<CreateRateQuestionMutation>;
export type CreateRateQuestionMutationOptions = Apollo.BaseMutationOptions<CreateRateQuestionMutation, CreateRateQuestionMutationVariables>;
export const CreateRateQuestionResponseDocument = gql`
    mutation createRateQuestionResponse($input: CreateQuestionResponseInput!) {
  createRateQuestionResponse(input: $input) {
    question {
      id
      rateID
      createdAt
      addedBy {
        ... on CMSUser {
          ...cmsUserFragment
        }
        ... on CMSApproverUser {
          ...cmsApproverUserFragment
        }
      }
      division
      documents {
        name
        s3URL
      }
      responses {
        ... on QuestionResponse {
          ...questionResponseFragment
        }
      }
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}
${QuestionResponseFragmentFragmentDoc}`;
export type CreateRateQuestionResponseMutationFn = Apollo.MutationFunction<CreateRateQuestionResponseMutation, CreateRateQuestionResponseMutationVariables>;

/**
 * __useCreateRateQuestionResponseMutation__
 *
 * To run a mutation, you first call `useCreateRateQuestionResponseMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useCreateRateQuestionResponseMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [createRateQuestionResponseMutation, { data, loading, error }] = useCreateRateQuestionResponseMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useCreateRateQuestionResponseMutation(baseOptions?: Apollo.MutationHookOptions<CreateRateQuestionResponseMutation, CreateRateQuestionResponseMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<CreateRateQuestionResponseMutation, CreateRateQuestionResponseMutationVariables>(CreateRateQuestionResponseDocument, options);
      }
export type CreateRateQuestionResponseMutationHookResult = ReturnType<typeof useCreateRateQuestionResponseMutation>;
export type CreateRateQuestionResponseMutationResult = Apollo.MutationResult<CreateRateQuestionResponseMutation>;
export type CreateRateQuestionResponseMutationOptions = Apollo.BaseMutationOptions<CreateRateQuestionResponseMutation, CreateRateQuestionResponseMutationVariables>;
export const DeleteOauthClientDocument = gql`
    mutation deleteOauthClient($input: DeleteOauthClientInput!) {
  deleteOauthClient(input: $input) {
    oauthClient {
      id
      clientId
      clientSecret
      grants
      description
      contactEmail
      createdAt
      updatedAt
    }
  }
}
    `;
export type DeleteOauthClientMutationFn = Apollo.MutationFunction<DeleteOauthClientMutation, DeleteOauthClientMutationVariables>;

/**
 * __useDeleteOauthClientMutation__
 *
 * To run a mutation, you first call `useDeleteOauthClientMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useDeleteOauthClientMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [deleteOauthClientMutation, { data, loading, error }] = useDeleteOauthClientMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useDeleteOauthClientMutation(baseOptions?: Apollo.MutationHookOptions<DeleteOauthClientMutation, DeleteOauthClientMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<DeleteOauthClientMutation, DeleteOauthClientMutationVariables>(DeleteOauthClientDocument, options);
      }
export type DeleteOauthClientMutationHookResult = ReturnType<typeof useDeleteOauthClientMutation>;
export type DeleteOauthClientMutationResult = Apollo.MutationResult<DeleteOauthClientMutation>;
export type DeleteOauthClientMutationOptions = Apollo.BaseMutationOptions<DeleteOauthClientMutation, DeleteOauthClientMutationVariables>;
export const SubmitContractDocument = gql`
    mutation submitContract($input: SubmitContractInput!) {
  submitContract(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      withdrawnRates {
        ...rateFieldsFragment
        revisions {
          ...rateRevisionFragment
        }
        packageSubmissions {
          ...ratePackageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type SubmitContractMutationFn = Apollo.MutationFunction<SubmitContractMutation, SubmitContractMutationVariables>;

/**
 * __useSubmitContractMutation__
 *
 * To run a mutation, you first call `useSubmitContractMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSubmitContractMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [submitContractMutation, { data, loading, error }] = useSubmitContractMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useSubmitContractMutation(baseOptions?: Apollo.MutationHookOptions<SubmitContractMutation, SubmitContractMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SubmitContractMutation, SubmitContractMutationVariables>(SubmitContractDocument, options);
      }
export type SubmitContractMutationHookResult = ReturnType<typeof useSubmitContractMutation>;
export type SubmitContractMutationResult = Apollo.MutationResult<SubmitContractMutation>;
export type SubmitContractMutationOptions = Apollo.BaseMutationOptions<SubmitContractMutation, SubmitContractMutationVariables>;
export const SubmitHealthPlanPackageDocument = gql`
    mutation submitHealthPlanPackage($input: SubmitHealthPlanPackageInput!) {
  submitHealthPlanPackage(input: $input) {
    pkg {
      id
      stateCode
      status
      initiallySubmittedAt
      revisions {
        node {
          id
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          createdAt
          formDataProto
        }
      }
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}`;
export type SubmitHealthPlanPackageMutationFn = Apollo.MutationFunction<SubmitHealthPlanPackageMutation, SubmitHealthPlanPackageMutationVariables>;

/**
 * __useSubmitHealthPlanPackageMutation__
 *
 * To run a mutation, you first call `useSubmitHealthPlanPackageMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSubmitHealthPlanPackageMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [submitHealthPlanPackageMutation, { data, loading, error }] = useSubmitHealthPlanPackageMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useSubmitHealthPlanPackageMutation(baseOptions?: Apollo.MutationHookOptions<SubmitHealthPlanPackageMutation, SubmitHealthPlanPackageMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SubmitHealthPlanPackageMutation, SubmitHealthPlanPackageMutationVariables>(SubmitHealthPlanPackageDocument, options);
      }
export type SubmitHealthPlanPackageMutationHookResult = ReturnType<typeof useSubmitHealthPlanPackageMutation>;
export type SubmitHealthPlanPackageMutationResult = Apollo.MutationResult<SubmitHealthPlanPackageMutation>;
export type SubmitHealthPlanPackageMutationOptions = Apollo.BaseMutationOptions<SubmitHealthPlanPackageMutation, SubmitHealthPlanPackageMutationVariables>;
export const SubmitRateDocument = gql`
    mutation submitRate($input: SubmitRateInput!) {
  submitRate(input: $input) {
    rate {
      ...rateFieldsFragment
      withdrawnFromContracts {
        ...contractFieldsFragment
        packageSubmissions {
          ...packageSubmissionsFragment
        }
      }
      revisions {
        ...rateRevisionFragment
      }
    }
  }
}
    ${RateFieldsFragmentFragmentDoc}
${ContractFieldsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}`;
export type SubmitRateMutationFn = Apollo.MutationFunction<SubmitRateMutation, SubmitRateMutationVariables>;

/**
 * __useSubmitRateMutation__
 *
 * To run a mutation, you first call `useSubmitRateMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useSubmitRateMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [submitRateMutation, { data, loading, error }] = useSubmitRateMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useSubmitRateMutation(baseOptions?: Apollo.MutationHookOptions<SubmitRateMutation, SubmitRateMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<SubmitRateMutation, SubmitRateMutationVariables>(SubmitRateDocument, options);
      }
export type SubmitRateMutationHookResult = ReturnType<typeof useSubmitRateMutation>;
export type SubmitRateMutationResult = Apollo.MutationResult<SubmitRateMutation>;
export type SubmitRateMutationOptions = Apollo.BaseMutationOptions<SubmitRateMutation, SubmitRateMutationVariables>;
export const UndoWithdrawContractDocument = gql`
    mutation undoWithdrawContract($input: UndoWithdrawContractInput!) {
  undoWithdrawContract(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      withdrawnRates {
        ...rateFieldsFragment
        revisions {
          ...rateRevisionFragment
        }
        packageSubmissions {
          ...ratePackageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type UndoWithdrawContractMutationFn = Apollo.MutationFunction<UndoWithdrawContractMutation, UndoWithdrawContractMutationVariables>;

/**
 * __useUndoWithdrawContractMutation__
 *
 * To run a mutation, you first call `useUndoWithdrawContractMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUndoWithdrawContractMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [undoWithdrawContractMutation, { data, loading, error }] = useUndoWithdrawContractMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUndoWithdrawContractMutation(baseOptions?: Apollo.MutationHookOptions<UndoWithdrawContractMutation, UndoWithdrawContractMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UndoWithdrawContractMutation, UndoWithdrawContractMutationVariables>(UndoWithdrawContractDocument, options);
      }
export type UndoWithdrawContractMutationHookResult = ReturnType<typeof useUndoWithdrawContractMutation>;
export type UndoWithdrawContractMutationResult = Apollo.MutationResult<UndoWithdrawContractMutation>;
export type UndoWithdrawContractMutationOptions = Apollo.BaseMutationOptions<UndoWithdrawContractMutation, UndoWithdrawContractMutationVariables>;
export const UndoWithdrawnRateDocument = gql`
    mutation undoWithdrawnRate($input: UndoWithdrawRateInput!) {
  undoWithdrawRate(input: $input) {
    rate {
      ...rateFieldsFragment
      draftRevision {
        ...rateRevisionFragment
      }
      revisions {
        ...rateRevisionFragment
      }
      withdrawnFromContracts {
        ...contractFieldsFragment
        packageSubmissions {
          ...packageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...ratePackageSubmissionsFragment
      }
    }
  }
}
    ${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${ContractFieldsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}`;
export type UndoWithdrawnRateMutationFn = Apollo.MutationFunction<UndoWithdrawnRateMutation, UndoWithdrawnRateMutationVariables>;

/**
 * __useUndoWithdrawnRateMutation__
 *
 * To run a mutation, you first call `useUndoWithdrawnRateMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUndoWithdrawnRateMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [undoWithdrawnRateMutation, { data, loading, error }] = useUndoWithdrawnRateMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUndoWithdrawnRateMutation(baseOptions?: Apollo.MutationHookOptions<UndoWithdrawnRateMutation, UndoWithdrawnRateMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UndoWithdrawnRateMutation, UndoWithdrawnRateMutationVariables>(UndoWithdrawnRateDocument, options);
      }
export type UndoWithdrawnRateMutationHookResult = ReturnType<typeof useUndoWithdrawnRateMutation>;
export type UndoWithdrawnRateMutationResult = Apollo.MutationResult<UndoWithdrawnRateMutation>;
export type UndoWithdrawnRateMutationOptions = Apollo.BaseMutationOptions<UndoWithdrawnRateMutation, UndoWithdrawnRateMutationVariables>;
export const UnlockContractDocument = gql`
    mutation unlockContract($input: UnlockContractInput!) {
  unlockContract(input: $input) {
    contract {
      ...unlockedContractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      withdrawnRates {
        ...rateFieldsFragment
        revisions {
          ...rateRevisionFragment
        }
        packageSubmissions {
          ...ratePackageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${UnlockedContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type UnlockContractMutationFn = Apollo.MutationFunction<UnlockContractMutation, UnlockContractMutationVariables>;

/**
 * __useUnlockContractMutation__
 *
 * To run a mutation, you first call `useUnlockContractMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUnlockContractMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [unlockContractMutation, { data, loading, error }] = useUnlockContractMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUnlockContractMutation(baseOptions?: Apollo.MutationHookOptions<UnlockContractMutation, UnlockContractMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UnlockContractMutation, UnlockContractMutationVariables>(UnlockContractDocument, options);
      }
export type UnlockContractMutationHookResult = ReturnType<typeof useUnlockContractMutation>;
export type UnlockContractMutationResult = Apollo.MutationResult<UnlockContractMutation>;
export type UnlockContractMutationOptions = Apollo.BaseMutationOptions<UnlockContractMutation, UnlockContractMutationVariables>;
export const UnlockHealthPlanPackageDocument = gql`
    mutation unlockHealthPlanPackage($input: UnlockHealthPlanPackageInput!) {
  unlockHealthPlanPackage(input: $input) {
    pkg {
      id
      stateCode
      state {
        code
        name
        programs {
          id
          name
          fullName
          isRateProgram
        }
      }
      status
      initiallySubmittedAt
      revisions {
        node {
          id
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          createdAt
          formDataProto
        }
      }
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}`;
export type UnlockHealthPlanPackageMutationFn = Apollo.MutationFunction<UnlockHealthPlanPackageMutation, UnlockHealthPlanPackageMutationVariables>;

/**
 * __useUnlockHealthPlanPackageMutation__
 *
 * To run a mutation, you first call `useUnlockHealthPlanPackageMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUnlockHealthPlanPackageMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [unlockHealthPlanPackageMutation, { data, loading, error }] = useUnlockHealthPlanPackageMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUnlockHealthPlanPackageMutation(baseOptions?: Apollo.MutationHookOptions<UnlockHealthPlanPackageMutation, UnlockHealthPlanPackageMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UnlockHealthPlanPackageMutation, UnlockHealthPlanPackageMutationVariables>(UnlockHealthPlanPackageDocument, options);
      }
export type UnlockHealthPlanPackageMutationHookResult = ReturnType<typeof useUnlockHealthPlanPackageMutation>;
export type UnlockHealthPlanPackageMutationResult = Apollo.MutationResult<UnlockHealthPlanPackageMutation>;
export type UnlockHealthPlanPackageMutationOptions = Apollo.BaseMutationOptions<UnlockHealthPlanPackageMutation, UnlockHealthPlanPackageMutationVariables>;
export const UnlockRateDocument = gql`
    mutation unlockRate($input: UnlockRateInput!) {
  unlockRate(input: $input) {
    rate {
      ...rateFieldsFragment
      draftRevision {
        ...rateRevisionFragment
      }
      withdrawnFromContracts {
        ...contractFieldsFragment
        packageSubmissions {
          ...packageSubmissionsFragment
        }
      }
      revisions {
        ...rateRevisionFragment
      }
    }
  }
}
    ${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${ContractFieldsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type UnlockRateMutationFn = Apollo.MutationFunction<UnlockRateMutation, UnlockRateMutationVariables>;

/**
 * __useUnlockRateMutation__
 *
 * To run a mutation, you first call `useUnlockRateMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUnlockRateMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [unlockRateMutation, { data, loading, error }] = useUnlockRateMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUnlockRateMutation(baseOptions?: Apollo.MutationHookOptions<UnlockRateMutation, UnlockRateMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UnlockRateMutation, UnlockRateMutationVariables>(UnlockRateDocument, options);
      }
export type UnlockRateMutationHookResult = ReturnType<typeof useUnlockRateMutation>;
export type UnlockRateMutationResult = Apollo.MutationResult<UnlockRateMutation>;
export type UnlockRateMutationOptions = Apollo.BaseMutationOptions<UnlockRateMutation, UnlockRateMutationVariables>;
export const UpdateContractDocument = gql`
    mutation updateContract($input: UpdateContractInput!) {
  updateContract(input: $input) {
    pkg {
      id
      stateCode
      mccrsID
      state {
        code
        name
        programs {
          id
          name
          fullName
          isRateProgram
        }
      }
      status
      initiallySubmittedAt
      revisions {
        node {
          id
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          createdAt
          formDataProto
        }
      }
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}`;
export type UpdateContractMutationFn = Apollo.MutationFunction<UpdateContractMutation, UpdateContractMutationVariables>;

/**
 * __useUpdateContractMutation__
 *
 * To run a mutation, you first call `useUpdateContractMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateContractMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateContractMutation, { data, loading, error }] = useUpdateContractMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateContractMutation(baseOptions?: Apollo.MutationHookOptions<UpdateContractMutation, UpdateContractMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateContractMutation, UpdateContractMutationVariables>(UpdateContractDocument, options);
      }
export type UpdateContractMutationHookResult = ReturnType<typeof useUpdateContractMutation>;
export type UpdateContractMutationResult = Apollo.MutationResult<UpdateContractMutation>;
export type UpdateContractMutationOptions = Apollo.BaseMutationOptions<UpdateContractMutation, UpdateContractMutationVariables>;
export const UpdateContractDraftRevisionDocument = gql`
    mutation updateContractDraftRevision($input: UpdateContractDraftRevisionInput!) {
  updateContractDraftRevision(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type UpdateContractDraftRevisionMutationFn = Apollo.MutationFunction<UpdateContractDraftRevisionMutation, UpdateContractDraftRevisionMutationVariables>;

/**
 * __useUpdateContractDraftRevisionMutation__
 *
 * To run a mutation, you first call `useUpdateContractDraftRevisionMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateContractDraftRevisionMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateContractDraftRevisionMutation, { data, loading, error }] = useUpdateContractDraftRevisionMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateContractDraftRevisionMutation(baseOptions?: Apollo.MutationHookOptions<UpdateContractDraftRevisionMutation, UpdateContractDraftRevisionMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateContractDraftRevisionMutation, UpdateContractDraftRevisionMutationVariables>(UpdateContractDraftRevisionDocument, options);
      }
export type UpdateContractDraftRevisionMutationHookResult = ReturnType<typeof useUpdateContractDraftRevisionMutation>;
export type UpdateContractDraftRevisionMutationResult = Apollo.MutationResult<UpdateContractDraftRevisionMutation>;
export type UpdateContractDraftRevisionMutationOptions = Apollo.BaseMutationOptions<UpdateContractDraftRevisionMutation, UpdateContractDraftRevisionMutationVariables>;
export const UpdateDivisionAssignmentDocument = gql`
    mutation updateDivisionAssignment($input: UpdateDivisionAssignmentInput!) {
  updateDivisionAssignment(input: $input) {
    user {
      __typename
      ... on CMSUser {
        ...cmsUserFragment
      }
      ... on CMSApproverUser {
        ...cmsApproverUserFragment
      }
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}`;
export type UpdateDivisionAssignmentMutationFn = Apollo.MutationFunction<UpdateDivisionAssignmentMutation, UpdateDivisionAssignmentMutationVariables>;

/**
 * __useUpdateDivisionAssignmentMutation__
 *
 * To run a mutation, you first call `useUpdateDivisionAssignmentMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateDivisionAssignmentMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateDivisionAssignmentMutation, { data, loading, error }] = useUpdateDivisionAssignmentMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateDivisionAssignmentMutation(baseOptions?: Apollo.MutationHookOptions<UpdateDivisionAssignmentMutation, UpdateDivisionAssignmentMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateDivisionAssignmentMutation, UpdateDivisionAssignmentMutationVariables>(UpdateDivisionAssignmentDocument, options);
      }
export type UpdateDivisionAssignmentMutationHookResult = ReturnType<typeof useUpdateDivisionAssignmentMutation>;
export type UpdateDivisionAssignmentMutationResult = Apollo.MutationResult<UpdateDivisionAssignmentMutation>;
export type UpdateDivisionAssignmentMutationOptions = Apollo.BaseMutationOptions<UpdateDivisionAssignmentMutation, UpdateDivisionAssignmentMutationVariables>;
export const UpdateDraftContractRatesDocument = gql`
    mutation updateDraftContractRates($input: UpdateDraftContractRatesInput!) {
  updateDraftContractRates(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type UpdateDraftContractRatesMutationFn = Apollo.MutationFunction<UpdateDraftContractRatesMutation, UpdateDraftContractRatesMutationVariables>;

/**
 * __useUpdateDraftContractRatesMutation__
 *
 * To run a mutation, you first call `useUpdateDraftContractRatesMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateDraftContractRatesMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateDraftContractRatesMutation, { data, loading, error }] = useUpdateDraftContractRatesMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateDraftContractRatesMutation(baseOptions?: Apollo.MutationHookOptions<UpdateDraftContractRatesMutation, UpdateDraftContractRatesMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateDraftContractRatesMutation, UpdateDraftContractRatesMutationVariables>(UpdateDraftContractRatesDocument, options);
      }
export type UpdateDraftContractRatesMutationHookResult = ReturnType<typeof useUpdateDraftContractRatesMutation>;
export type UpdateDraftContractRatesMutationResult = Apollo.MutationResult<UpdateDraftContractRatesMutation>;
export type UpdateDraftContractRatesMutationOptions = Apollo.BaseMutationOptions<UpdateDraftContractRatesMutation, UpdateDraftContractRatesMutationVariables>;
export const UpdateEmailSettingsDocument = gql`
    mutation updateEmailSettings($input: UpdateEmailSettingsInput!) {
  updateEmailSettings(input: $input) {
    emailConfiguration {
      ... on EmailConfiguration {
        ...emailConfigurationFragment
      }
    }
  }
}
    ${EmailConfigurationFragmentFragmentDoc}`;
export type UpdateEmailSettingsMutationFn = Apollo.MutationFunction<UpdateEmailSettingsMutation, UpdateEmailSettingsMutationVariables>;

/**
 * __useUpdateEmailSettingsMutation__
 *
 * To run a mutation, you first call `useUpdateEmailSettingsMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateEmailSettingsMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateEmailSettingsMutation, { data, loading, error }] = useUpdateEmailSettingsMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateEmailSettingsMutation(baseOptions?: Apollo.MutationHookOptions<UpdateEmailSettingsMutation, UpdateEmailSettingsMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateEmailSettingsMutation, UpdateEmailSettingsMutationVariables>(UpdateEmailSettingsDocument, options);
      }
export type UpdateEmailSettingsMutationHookResult = ReturnType<typeof useUpdateEmailSettingsMutation>;
export type UpdateEmailSettingsMutationResult = Apollo.MutationResult<UpdateEmailSettingsMutation>;
export type UpdateEmailSettingsMutationOptions = Apollo.BaseMutationOptions<UpdateEmailSettingsMutation, UpdateEmailSettingsMutationVariables>;
export const UpdateHealthPlanFormDataDocument = gql`
    mutation updateHealthPlanFormData($input: UpdateHealthPlanFormDataInput!) {
  updateHealthPlanFormData(input: $input) {
    pkg {
      id
      stateCode
      state {
        code
        name
        programs {
          id
          name
          fullName
          isRateProgram
        }
      }
      status
      initiallySubmittedAt
      revisions {
        node {
          id
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          createdAt
          formDataProto
        }
      }
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}`;
export type UpdateHealthPlanFormDataMutationFn = Apollo.MutationFunction<UpdateHealthPlanFormDataMutation, UpdateHealthPlanFormDataMutationVariables>;

/**
 * __useUpdateHealthPlanFormDataMutation__
 *
 * To run a mutation, you first call `useUpdateHealthPlanFormDataMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateHealthPlanFormDataMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateHealthPlanFormDataMutation, { data, loading, error }] = useUpdateHealthPlanFormDataMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateHealthPlanFormDataMutation(baseOptions?: Apollo.MutationHookOptions<UpdateHealthPlanFormDataMutation, UpdateHealthPlanFormDataMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateHealthPlanFormDataMutation, UpdateHealthPlanFormDataMutationVariables>(UpdateHealthPlanFormDataDocument, options);
      }
export type UpdateHealthPlanFormDataMutationHookResult = ReturnType<typeof useUpdateHealthPlanFormDataMutation>;
export type UpdateHealthPlanFormDataMutationResult = Apollo.MutationResult<UpdateHealthPlanFormDataMutation>;
export type UpdateHealthPlanFormDataMutationOptions = Apollo.BaseMutationOptions<UpdateHealthPlanFormDataMutation, UpdateHealthPlanFormDataMutationVariables>;
export const UpdateOauthClientDocument = gql`
    mutation UpdateOauthClient($input: UpdateOauthClientInput!) {
  updateOauthClient(input: $input) {
    oauthClient {
      id
      clientId
      clientSecret
      description
      contactEmail
      grants
      createdAt
      updatedAt
    }
  }
}
    `;
export type UpdateOauthClientMutationFn = Apollo.MutationFunction<UpdateOauthClientMutation, UpdateOauthClientMutationVariables>;

/**
 * __useUpdateOauthClientMutation__
 *
 * To run a mutation, you first call `useUpdateOauthClientMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateOauthClientMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateOauthClientMutation, { data, loading, error }] = useUpdateOauthClientMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateOauthClientMutation(baseOptions?: Apollo.MutationHookOptions<UpdateOauthClientMutation, UpdateOauthClientMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateOauthClientMutation, UpdateOauthClientMutationVariables>(UpdateOauthClientDocument, options);
      }
export type UpdateOauthClientMutationHookResult = ReturnType<typeof useUpdateOauthClientMutation>;
export type UpdateOauthClientMutationResult = Apollo.MutationResult<UpdateOauthClientMutation>;
export type UpdateOauthClientMutationOptions = Apollo.BaseMutationOptions<UpdateOauthClientMutation, UpdateOauthClientMutationVariables>;
export const UpdateStateAssignmentDocument = gql`
    mutation updateStateAssignment($input: UpdateStateAssignmentInput!) {
  updateStateAssignment(input: $input) {
    user {
      __typename
      ... on CMSUser {
        ...cmsUserFragment
      }
      ... on CMSApproverUser {
        ...cmsApproverUserFragment
      }
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}`;
export type UpdateStateAssignmentMutationFn = Apollo.MutationFunction<UpdateStateAssignmentMutation, UpdateStateAssignmentMutationVariables>;

/**
 * __useUpdateStateAssignmentMutation__
 *
 * To run a mutation, you first call `useUpdateStateAssignmentMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateStateAssignmentMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateStateAssignmentMutation, { data, loading, error }] = useUpdateStateAssignmentMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateStateAssignmentMutation(baseOptions?: Apollo.MutationHookOptions<UpdateStateAssignmentMutation, UpdateStateAssignmentMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateStateAssignmentMutation, UpdateStateAssignmentMutationVariables>(UpdateStateAssignmentDocument, options);
      }
export type UpdateStateAssignmentMutationHookResult = ReturnType<typeof useUpdateStateAssignmentMutation>;
export type UpdateStateAssignmentMutationResult = Apollo.MutationResult<UpdateStateAssignmentMutation>;
export type UpdateStateAssignmentMutationOptions = Apollo.BaseMutationOptions<UpdateStateAssignmentMutation, UpdateStateAssignmentMutationVariables>;
export const UpdateStateAssignmentsByStateDocument = gql`
    mutation updateStateAssignmentsByState($input: UpdateStateAssignmentsByStateInput!) {
  updateStateAssignmentsByState(input: $input) {
    stateCode
    assignedUsers {
      __typename
      ... on CMSUser {
        ...cmsUserFragment
      }
      ... on CMSApproverUser {
        ...cmsApproverUserFragment
      }
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}`;
export type UpdateStateAssignmentsByStateMutationFn = Apollo.MutationFunction<UpdateStateAssignmentsByStateMutation, UpdateStateAssignmentsByStateMutationVariables>;

/**
 * __useUpdateStateAssignmentsByStateMutation__
 *
 * To run a mutation, you first call `useUpdateStateAssignmentsByStateMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useUpdateStateAssignmentsByStateMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [updateStateAssignmentsByStateMutation, { data, loading, error }] = useUpdateStateAssignmentsByStateMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useUpdateStateAssignmentsByStateMutation(baseOptions?: Apollo.MutationHookOptions<UpdateStateAssignmentsByStateMutation, UpdateStateAssignmentsByStateMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<UpdateStateAssignmentsByStateMutation, UpdateStateAssignmentsByStateMutationVariables>(UpdateStateAssignmentsByStateDocument, options);
      }
export type UpdateStateAssignmentsByStateMutationHookResult = ReturnType<typeof useUpdateStateAssignmentsByStateMutation>;
export type UpdateStateAssignmentsByStateMutationResult = Apollo.MutationResult<UpdateStateAssignmentsByStateMutation>;
export type UpdateStateAssignmentsByStateMutationOptions = Apollo.BaseMutationOptions<UpdateStateAssignmentsByStateMutation, UpdateStateAssignmentsByStateMutationVariables>;
export const WithdrawContractDocument = gql`
    mutation withdrawContract($input: WithdrawContractInput!) {
  withdrawContract(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      withdrawnRates {
        ...rateFieldsFragment
        revisions {
          ...rateRevisionFragment
        }
        packageSubmissions {
          ...ratePackageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;
export type WithdrawContractMutationFn = Apollo.MutationFunction<WithdrawContractMutation, WithdrawContractMutationVariables>;

/**
 * __useWithdrawContractMutation__
 *
 * To run a mutation, you first call `useWithdrawContractMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useWithdrawContractMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [withdrawContractMutation, { data, loading, error }] = useWithdrawContractMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useWithdrawContractMutation(baseOptions?: Apollo.MutationHookOptions<WithdrawContractMutation, WithdrawContractMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<WithdrawContractMutation, WithdrawContractMutationVariables>(WithdrawContractDocument, options);
      }
export type WithdrawContractMutationHookResult = ReturnType<typeof useWithdrawContractMutation>;
export type WithdrawContractMutationResult = Apollo.MutationResult<WithdrawContractMutation>;
export type WithdrawContractMutationOptions = Apollo.BaseMutationOptions<WithdrawContractMutation, WithdrawContractMutationVariables>;
export const WithdrawRateDocument = gql`
    mutation withdrawRate($input: WithdrawRateInput!) {
  withdrawRate(input: $input) {
    rate {
      ...rateFieldsFragment
      draftRevision {
        ...rateRevisionFragment
      }
      revisions {
        ...rateRevisionFragment
      }
      withdrawnFromContracts {
        ...contractFieldsFragment
        packageSubmissions {
          ...packageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...ratePackageSubmissionsFragment
      }
    }
  }
}
    ${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${ContractFieldsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}`;
export type WithdrawRateMutationFn = Apollo.MutationFunction<WithdrawRateMutation, WithdrawRateMutationVariables>;

/**
 * __useWithdrawRateMutation__
 *
 * To run a mutation, you first call `useWithdrawRateMutation` within a React component and pass it any options that fit your needs.
 * When your component renders, `useWithdrawRateMutation` returns a tuple that includes:
 * - A mutate function that you can call at any time to execute the mutation
 * - An object with fields that represent the current status of the mutation's execution
 *
 * @param baseOptions options that will be passed into the mutation, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options-2;
 *
 * @example
 * const [withdrawRateMutation, { data, loading, error }] = useWithdrawRateMutation({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useWithdrawRateMutation(baseOptions?: Apollo.MutationHookOptions<WithdrawRateMutation, WithdrawRateMutationVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useMutation<WithdrawRateMutation, WithdrawRateMutationVariables>(WithdrawRateDocument, options);
      }
export type WithdrawRateMutationHookResult = ReturnType<typeof useWithdrawRateMutation>;
export type WithdrawRateMutationResult = Apollo.MutationResult<WithdrawRateMutation>;
export type WithdrawRateMutationOptions = Apollo.BaseMutationOptions<WithdrawRateMutation, WithdrawRateMutationVariables>;
export const FetchContractDocument = gql`
    query fetchContract($input: FetchContractInput!) {
  fetchContract(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      withdrawnRates {
        ...rateFieldsFragment
        revisions {
          ...rateRevisionFragment
        }
        packageSubmissions {
          ...ratePackageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}`;

/**
 * __useFetchContractQuery__
 *
 * To run a query within a React component, call `useFetchContractQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchContractQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchContractQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useFetchContractQuery(baseOptions: Apollo.QueryHookOptions<FetchContractQuery, FetchContractQueryVariables> & ({ variables: FetchContractQueryVariables; skip?: boolean; } | { skip: boolean; }) ) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchContractQuery, FetchContractQueryVariables>(FetchContractDocument, options);
      }
export function useFetchContractLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchContractQuery, FetchContractQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchContractQuery, FetchContractQueryVariables>(FetchContractDocument, options);
        }
export function useFetchContractSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchContractQuery, FetchContractQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchContractQuery, FetchContractQueryVariables>(FetchContractDocument, options);
        }
export type FetchContractQueryHookResult = ReturnType<typeof useFetchContractQuery>;
export type FetchContractLazyQueryHookResult = ReturnType<typeof useFetchContractLazyQuery>;
export type FetchContractSuspenseQueryHookResult = ReturnType<typeof useFetchContractSuspenseQuery>;
export type FetchContractQueryResult = Apollo.QueryResult<FetchContractQuery, FetchContractQueryVariables>;
export const FetchContractWithQuestionsDocument = gql`
    query fetchContractWithQuestions($input: FetchContractInput!) {
  fetchContract(input: $input) {
    contract {
      ...contractFieldsFragment
      draftRevision {
        ...contractRevisionFragment
      }
      draftRates {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
      }
      withdrawnRates {
        ...rateFieldsFragment
        revisions {
          ...rateRevisionFragment
        }
        packageSubmissions {
          ...ratePackageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...packageSubmissionsFragment
      }
      questions {
        DMCOQuestions {
          ...contractQuestionListFragment
        }
        DMCPQuestions {
          ...contractQuestionListFragment
        }
        OACTQuestions {
          ...contractQuestionListFragment
        }
      }
    }
  }
}
    ${ContractFieldsFragmentFragmentDoc}
${ContractRevisionFragmentFragmentDoc}
${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}
${ContractQuestionListFragmentFragmentDoc}`;

/**
 * __useFetchContractWithQuestionsQuery__
 *
 * To run a query within a React component, call `useFetchContractWithQuestionsQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchContractWithQuestionsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchContractWithQuestionsQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useFetchContractWithQuestionsQuery(baseOptions: Apollo.QueryHookOptions<FetchContractWithQuestionsQuery, FetchContractWithQuestionsQueryVariables> & ({ variables: FetchContractWithQuestionsQueryVariables; skip?: boolean; } | { skip: boolean; }) ) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchContractWithQuestionsQuery, FetchContractWithQuestionsQueryVariables>(FetchContractWithQuestionsDocument, options);
      }
export function useFetchContractWithQuestionsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchContractWithQuestionsQuery, FetchContractWithQuestionsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchContractWithQuestionsQuery, FetchContractWithQuestionsQueryVariables>(FetchContractWithQuestionsDocument, options);
        }
export function useFetchContractWithQuestionsSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchContractWithQuestionsQuery, FetchContractWithQuestionsQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchContractWithQuestionsQuery, FetchContractWithQuestionsQueryVariables>(FetchContractWithQuestionsDocument, options);
        }
export type FetchContractWithQuestionsQueryHookResult = ReturnType<typeof useFetchContractWithQuestionsQuery>;
export type FetchContractWithQuestionsLazyQueryHookResult = ReturnType<typeof useFetchContractWithQuestionsLazyQuery>;
export type FetchContractWithQuestionsSuspenseQueryHookResult = ReturnType<typeof useFetchContractWithQuestionsSuspenseQuery>;
export type FetchContractWithQuestionsQueryResult = Apollo.QueryResult<FetchContractWithQuestionsQuery, FetchContractWithQuestionsQueryVariables>;
export const FetchCurrentUserDocument = gql`
    query fetchCurrentUser {
  fetchCurrentUser {
    ... on CMSUser {
      ...cmsUserFragment
    }
    ... on CMSApproverUser {
      ...cmsApproverUserFragment
    }
    ... on StateUser {
      ...stateUserFragment
    }
    ... on AdminUser {
      ...adminUserFragment
    }
    ... on HelpdeskUser {
      ...helpdeskUserFragment
    }
    ... on BusinessOwnerUser {
      ...businessUserFragment
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}
${StateUserFragmentFragmentDoc}
${AdminUserFragmentFragmentDoc}
${HelpdeskUserFragmentFragmentDoc}
${BusinessUserFragmentFragmentDoc}`;

/**
 * __useFetchCurrentUserQuery__
 *
 * To run a query within a React component, call `useFetchCurrentUserQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchCurrentUserQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchCurrentUserQuery({
 *   variables: {
 *   },
 * });
 */
export function useFetchCurrentUserQuery(baseOptions?: Apollo.QueryHookOptions<FetchCurrentUserQuery, FetchCurrentUserQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchCurrentUserQuery, FetchCurrentUserQueryVariables>(FetchCurrentUserDocument, options);
      }
export function useFetchCurrentUserLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchCurrentUserQuery, FetchCurrentUserQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchCurrentUserQuery, FetchCurrentUserQueryVariables>(FetchCurrentUserDocument, options);
        }
export function useFetchCurrentUserSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchCurrentUserQuery, FetchCurrentUserQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchCurrentUserQuery, FetchCurrentUserQueryVariables>(FetchCurrentUserDocument, options);
        }
export type FetchCurrentUserQueryHookResult = ReturnType<typeof useFetchCurrentUserQuery>;
export type FetchCurrentUserLazyQueryHookResult = ReturnType<typeof useFetchCurrentUserLazyQuery>;
export type FetchCurrentUserSuspenseQueryHookResult = ReturnType<typeof useFetchCurrentUserSuspenseQuery>;
export type FetchCurrentUserQueryResult = Apollo.QueryResult<FetchCurrentUserQuery, FetchCurrentUserQueryVariables>;
export const FetchHealthPlanPackageDocument = gql`
    query fetchHealthPlanPackage($input: FetchHealthPlanPackageInput!) {
  fetchHealthPlanPackage(input: $input) {
    pkg {
      id
      stateCode
      state {
        code
        name
        programs {
          id
          name
          fullName
          isRateProgram
        }
      }
      status
      initiallySubmittedAt
      mccrsID
      revisions {
        node {
          id
          createdAt
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          formDataProto
        }
      }
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}`;

/**
 * __useFetchHealthPlanPackageQuery__
 *
 * To run a query within a React component, call `useFetchHealthPlanPackageQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchHealthPlanPackageQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchHealthPlanPackageQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useFetchHealthPlanPackageQuery(baseOptions: Apollo.QueryHookOptions<FetchHealthPlanPackageQuery, FetchHealthPlanPackageQueryVariables> & ({ variables: FetchHealthPlanPackageQueryVariables; skip?: boolean; } | { skip: boolean; }) ) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchHealthPlanPackageQuery, FetchHealthPlanPackageQueryVariables>(FetchHealthPlanPackageDocument, options);
      }
export function useFetchHealthPlanPackageLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchHealthPlanPackageQuery, FetchHealthPlanPackageQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchHealthPlanPackageQuery, FetchHealthPlanPackageQueryVariables>(FetchHealthPlanPackageDocument, options);
        }
export function useFetchHealthPlanPackageSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchHealthPlanPackageQuery, FetchHealthPlanPackageQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchHealthPlanPackageQuery, FetchHealthPlanPackageQueryVariables>(FetchHealthPlanPackageDocument, options);
        }
export type FetchHealthPlanPackageQueryHookResult = ReturnType<typeof useFetchHealthPlanPackageQuery>;
export type FetchHealthPlanPackageLazyQueryHookResult = ReturnType<typeof useFetchHealthPlanPackageLazyQuery>;
export type FetchHealthPlanPackageSuspenseQueryHookResult = ReturnType<typeof useFetchHealthPlanPackageSuspenseQuery>;
export type FetchHealthPlanPackageQueryResult = Apollo.QueryResult<FetchHealthPlanPackageQuery, FetchHealthPlanPackageQueryVariables>;
export const FetchHealthPlanPackageWithQuestionsDocument = gql`
    query fetchHealthPlanPackageWithQuestions($input: FetchHealthPlanPackageInput!) {
  fetchHealthPlanPackage(input: $input) {
    pkg {
      id
      status
      initiallySubmittedAt
      stateCode
      mccrsID
      state {
        code
        name
        programs {
          id
          name
          fullName
          isRateProgram
        }
      }
      revisions {
        node {
          id
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          createdAt
          formDataProto
        }
      }
      questions {
        DMCOQuestions {
          ...contractQuestionListFragment
        }
        DMCPQuestions {
          ...contractQuestionListFragment
        }
        OACTQuestions {
          ...contractQuestionListFragment
        }
      }
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}
${ContractQuestionListFragmentFragmentDoc}`;

/**
 * __useFetchHealthPlanPackageWithQuestionsQuery__
 *
 * To run a query within a React component, call `useFetchHealthPlanPackageWithQuestionsQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchHealthPlanPackageWithQuestionsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchHealthPlanPackageWithQuestionsQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useFetchHealthPlanPackageWithQuestionsQuery(baseOptions: Apollo.QueryHookOptions<FetchHealthPlanPackageWithQuestionsQuery, FetchHealthPlanPackageWithQuestionsQueryVariables> & ({ variables: FetchHealthPlanPackageWithQuestionsQueryVariables; skip?: boolean; } | { skip: boolean; }) ) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchHealthPlanPackageWithQuestionsQuery, FetchHealthPlanPackageWithQuestionsQueryVariables>(FetchHealthPlanPackageWithQuestionsDocument, options);
      }
export function useFetchHealthPlanPackageWithQuestionsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchHealthPlanPackageWithQuestionsQuery, FetchHealthPlanPackageWithQuestionsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchHealthPlanPackageWithQuestionsQuery, FetchHealthPlanPackageWithQuestionsQueryVariables>(FetchHealthPlanPackageWithQuestionsDocument, options);
        }
export function useFetchHealthPlanPackageWithQuestionsSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchHealthPlanPackageWithQuestionsQuery, FetchHealthPlanPackageWithQuestionsQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchHealthPlanPackageWithQuestionsQuery, FetchHealthPlanPackageWithQuestionsQueryVariables>(FetchHealthPlanPackageWithQuestionsDocument, options);
        }
export type FetchHealthPlanPackageWithQuestionsQueryHookResult = ReturnType<typeof useFetchHealthPlanPackageWithQuestionsQuery>;
export type FetchHealthPlanPackageWithQuestionsLazyQueryHookResult = ReturnType<typeof useFetchHealthPlanPackageWithQuestionsLazyQuery>;
export type FetchHealthPlanPackageWithQuestionsSuspenseQueryHookResult = ReturnType<typeof useFetchHealthPlanPackageWithQuestionsSuspenseQuery>;
export type FetchHealthPlanPackageWithQuestionsQueryResult = Apollo.QueryResult<FetchHealthPlanPackageWithQuestionsQuery, FetchHealthPlanPackageWithQuestionsQueryVariables>;
export const FetchMcReviewSettingsDocument = gql`
    query fetchMcReviewSettings {
  fetchMcReviewSettings {
    emailConfiguration {
      ... on EmailConfiguration {
        ...emailConfigurationFragment
      }
    }
    stateAssignments {
      stateCode
      name
      assignedCMSUsers {
        __typename
        ... on CMSUser {
          ...cmsUserFragment
        }
        ... on CMSApproverUser {
          ...cmsApproverUserFragment
        }
      }
    }
  }
}
    ${EmailConfigurationFragmentFragmentDoc}
${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}`;

/**
 * __useFetchMcReviewSettingsQuery__
 *
 * To run a query within a React component, call `useFetchMcReviewSettingsQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchMcReviewSettingsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchMcReviewSettingsQuery({
 *   variables: {
 *   },
 * });
 */
export function useFetchMcReviewSettingsQuery(baseOptions?: Apollo.QueryHookOptions<FetchMcReviewSettingsQuery, FetchMcReviewSettingsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchMcReviewSettingsQuery, FetchMcReviewSettingsQueryVariables>(FetchMcReviewSettingsDocument, options);
      }
export function useFetchMcReviewSettingsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchMcReviewSettingsQuery, FetchMcReviewSettingsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchMcReviewSettingsQuery, FetchMcReviewSettingsQueryVariables>(FetchMcReviewSettingsDocument, options);
        }
export function useFetchMcReviewSettingsSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchMcReviewSettingsQuery, FetchMcReviewSettingsQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchMcReviewSettingsQuery, FetchMcReviewSettingsQueryVariables>(FetchMcReviewSettingsDocument, options);
        }
export type FetchMcReviewSettingsQueryHookResult = ReturnType<typeof useFetchMcReviewSettingsQuery>;
export type FetchMcReviewSettingsLazyQueryHookResult = ReturnType<typeof useFetchMcReviewSettingsLazyQuery>;
export type FetchMcReviewSettingsSuspenseQueryHookResult = ReturnType<typeof useFetchMcReviewSettingsSuspenseQuery>;
export type FetchMcReviewSettingsQueryResult = Apollo.QueryResult<FetchMcReviewSettingsQuery, FetchMcReviewSettingsQueryVariables>;
export const FetchOauthClientsDocument = gql`
    query fetchOauthClients($input: FetchOauthClientsInput) {
  fetchOauthClients(input: $input) {
    oauthClients {
      id
      clientId
      clientSecret
      grants
      description
      contactEmail
      createdAt
      updatedAt
    }
  }
}
    `;

/**
 * __useFetchOauthClientsQuery__
 *
 * To run a query within a React component, call `useFetchOauthClientsQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchOauthClientsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchOauthClientsQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useFetchOauthClientsQuery(baseOptions?: Apollo.QueryHookOptions<FetchOauthClientsQuery, FetchOauthClientsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchOauthClientsQuery, FetchOauthClientsQueryVariables>(FetchOauthClientsDocument, options);
      }
export function useFetchOauthClientsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchOauthClientsQuery, FetchOauthClientsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchOauthClientsQuery, FetchOauthClientsQueryVariables>(FetchOauthClientsDocument, options);
        }
export function useFetchOauthClientsSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchOauthClientsQuery, FetchOauthClientsQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchOauthClientsQuery, FetchOauthClientsQueryVariables>(FetchOauthClientsDocument, options);
        }
export type FetchOauthClientsQueryHookResult = ReturnType<typeof useFetchOauthClientsQuery>;
export type FetchOauthClientsLazyQueryHookResult = ReturnType<typeof useFetchOauthClientsLazyQuery>;
export type FetchOauthClientsSuspenseQueryHookResult = ReturnType<typeof useFetchOauthClientsSuspenseQuery>;
export type FetchOauthClientsQueryResult = Apollo.QueryResult<FetchOauthClientsQuery, FetchOauthClientsQueryVariables>;
export const FetchRateDocument = gql`
    query fetchRate($input: FetchRateInput!) {
  fetchRate(input: $input) {
    rate {
      ...rateFieldsFragment
      draftRevision {
        ...rateRevisionFragment
      }
      revisions {
        ...rateRevisionFragment
      }
      withdrawnFromContracts {
        ...contractFieldsFragment
        packageSubmissions {
          ...packageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...ratePackageSubmissionsFragment
      }
    }
  }
}
    ${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${ContractFieldsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}`;

/**
 * __useFetchRateQuery__
 *
 * To run a query within a React component, call `useFetchRateQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchRateQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchRateQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useFetchRateQuery(baseOptions: Apollo.QueryHookOptions<FetchRateQuery, FetchRateQueryVariables> & ({ variables: FetchRateQueryVariables; skip?: boolean; } | { skip: boolean; }) ) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchRateQuery, FetchRateQueryVariables>(FetchRateDocument, options);
      }
export function useFetchRateLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchRateQuery, FetchRateQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchRateQuery, FetchRateQueryVariables>(FetchRateDocument, options);
        }
export function useFetchRateSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchRateQuery, FetchRateQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchRateQuery, FetchRateQueryVariables>(FetchRateDocument, options);
        }
export type FetchRateQueryHookResult = ReturnType<typeof useFetchRateQuery>;
export type FetchRateLazyQueryHookResult = ReturnType<typeof useFetchRateLazyQuery>;
export type FetchRateSuspenseQueryHookResult = ReturnType<typeof useFetchRateSuspenseQuery>;
export type FetchRateQueryResult = Apollo.QueryResult<FetchRateQuery, FetchRateQueryVariables>;
export const FetchRateWithQuestionsDocument = gql`
    query fetchRateWithQuestions($input: FetchRateInput!) {
  fetchRate(input: $input) {
    rate {
      ...rateFieldsFragment
      draftRevision {
        ...rateRevisionFragment
      }
      revisions {
        ...rateRevisionFragment
      }
      withdrawnFromContracts {
        ...contractFieldsFragment
        packageSubmissions {
          ...packageSubmissionsFragment
        }
      }
      packageSubmissions {
        ...ratePackageSubmissionsFragment
      }
      questions {
        DMCOQuestions {
          ...rateQuestionListFragment
        }
        DMCPQuestions {
          ...rateQuestionListFragment
        }
        OACTQuestions {
          ...rateQuestionListFragment
        }
      }
    }
  }
}
    ${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${ContractFieldsFragmentFragmentDoc}
${PackageSubmissionsFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}
${RateQuestionListFragmentFragmentDoc}`;

/**
 * __useFetchRateWithQuestionsQuery__
 *
 * To run a query within a React component, call `useFetchRateWithQuestionsQuery` and pass it any options that fit your needs.
 * When your component renders, `useFetchRateWithQuestionsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useFetchRateWithQuestionsQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useFetchRateWithQuestionsQuery(baseOptions: Apollo.QueryHookOptions<FetchRateWithQuestionsQuery, FetchRateWithQuestionsQueryVariables> & ({ variables: FetchRateWithQuestionsQueryVariables; skip?: boolean; } | { skip: boolean; }) ) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<FetchRateWithQuestionsQuery, FetchRateWithQuestionsQueryVariables>(FetchRateWithQuestionsDocument, options);
      }
export function useFetchRateWithQuestionsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<FetchRateWithQuestionsQuery, FetchRateWithQuestionsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<FetchRateWithQuestionsQuery, FetchRateWithQuestionsQueryVariables>(FetchRateWithQuestionsDocument, options);
        }
export function useFetchRateWithQuestionsSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<FetchRateWithQuestionsQuery, FetchRateWithQuestionsQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<FetchRateWithQuestionsQuery, FetchRateWithQuestionsQueryVariables>(FetchRateWithQuestionsDocument, options);
        }
export type FetchRateWithQuestionsQueryHookResult = ReturnType<typeof useFetchRateWithQuestionsQuery>;
export type FetchRateWithQuestionsLazyQueryHookResult = ReturnType<typeof useFetchRateWithQuestionsLazyQuery>;
export type FetchRateWithQuestionsSuspenseQueryHookResult = ReturnType<typeof useFetchRateWithQuestionsSuspenseQuery>;
export type FetchRateWithQuestionsQueryResult = Apollo.QueryResult<FetchRateWithQuestionsQuery, FetchRateWithQuestionsQueryVariables>;
export const IndexContractsForDashboardDocument = gql`
    query indexContractsForDashboard {
  indexContracts {
    totalCount
    edges {
      node {
        id
        status
        reviewStatus
        consolidatedStatus
        createdAt
        updatedAt
        initiallySubmittedAt
        lastUpdatedForDisplay
        stateCode
        reviewStatusActions {
          updatedAt
          actionType
        }
        state {
          code
          name
          programs {
            id
            name
            fullName
            isRateProgram
          }
        }
        stateNumber
        draftRevision {
          id
          createdAt
          updatedAt
          contractName
          submitInfo {
            updatedAt
          }
          unlockInfo {
            updatedAt
          }
          formData {
            programIDs
            submissionType
          }
        }
        packageSubmissions {
          cause
          submitInfo {
            updatedAt
          }
          contractRevision {
            id
            createdAt
            updatedAt
            contractName
            submitInfo {
              updatedAt
            }
            unlockInfo {
              updatedAt
            }
            formData {
              programIDs
              submissionType
            }
          }
        }
      }
    }
  }
}
    `;

/**
 * __useIndexContractsForDashboardQuery__
 *
 * To run a query within a React component, call `useIndexContractsForDashboardQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndexContractsForDashboardQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndexContractsForDashboardQuery({
 *   variables: {
 *   },
 * });
 */
export function useIndexContractsForDashboardQuery(baseOptions?: Apollo.QueryHookOptions<IndexContractsForDashboardQuery, IndexContractsForDashboardQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndexContractsForDashboardQuery, IndexContractsForDashboardQueryVariables>(IndexContractsForDashboardDocument, options);
      }
export function useIndexContractsForDashboardLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndexContractsForDashboardQuery, IndexContractsForDashboardQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndexContractsForDashboardQuery, IndexContractsForDashboardQueryVariables>(IndexContractsForDashboardDocument, options);
        }
export function useIndexContractsForDashboardSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<IndexContractsForDashboardQuery, IndexContractsForDashboardQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<IndexContractsForDashboardQuery, IndexContractsForDashboardQueryVariables>(IndexContractsForDashboardDocument, options);
        }
export type IndexContractsForDashboardQueryHookResult = ReturnType<typeof useIndexContractsForDashboardQuery>;
export type IndexContractsForDashboardLazyQueryHookResult = ReturnType<typeof useIndexContractsForDashboardLazyQuery>;
export type IndexContractsForDashboardSuspenseQueryHookResult = ReturnType<typeof useIndexContractsForDashboardSuspenseQuery>;
export type IndexContractsForDashboardQueryResult = Apollo.QueryResult<IndexContractsForDashboardQuery, IndexContractsForDashboardQueryVariables>;
export const IndexHealthPlanPackagesDocument = gql`
    query indexHealthPlanPackages {
  indexHealthPlanPackages {
    totalCount
    edges {
      node {
        id
        stateCode
        mccrsID
        state {
          code
          name
          programs {
            id
            name
            fullName
            isRateProgram
          }
        }
        status
        initiallySubmittedAt
        revisions {
          node {
            id
            createdAt
            unlockInfo {
              ...updateInformationFields
            }
            submitInfo {
              ...updateInformationFields
            }
            formDataProto
          }
        }
      }
    }
  }
}
    ${UpdateInformationFieldsFragmentDoc}`;

/**
 * __useIndexHealthPlanPackagesQuery__
 *
 * To run a query within a React component, call `useIndexHealthPlanPackagesQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndexHealthPlanPackagesQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndexHealthPlanPackagesQuery({
 *   variables: {
 *   },
 * });
 */
export function useIndexHealthPlanPackagesQuery(baseOptions?: Apollo.QueryHookOptions<IndexHealthPlanPackagesQuery, IndexHealthPlanPackagesQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndexHealthPlanPackagesQuery, IndexHealthPlanPackagesQueryVariables>(IndexHealthPlanPackagesDocument, options);
      }
export function useIndexHealthPlanPackagesLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndexHealthPlanPackagesQuery, IndexHealthPlanPackagesQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndexHealthPlanPackagesQuery, IndexHealthPlanPackagesQueryVariables>(IndexHealthPlanPackagesDocument, options);
        }
export function useIndexHealthPlanPackagesSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<IndexHealthPlanPackagesQuery, IndexHealthPlanPackagesQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<IndexHealthPlanPackagesQuery, IndexHealthPlanPackagesQueryVariables>(IndexHealthPlanPackagesDocument, options);
        }
export type IndexHealthPlanPackagesQueryHookResult = ReturnType<typeof useIndexHealthPlanPackagesQuery>;
export type IndexHealthPlanPackagesLazyQueryHookResult = ReturnType<typeof useIndexHealthPlanPackagesLazyQuery>;
export type IndexHealthPlanPackagesSuspenseQueryHookResult = ReturnType<typeof useIndexHealthPlanPackagesSuspenseQuery>;
export type IndexHealthPlanPackagesQueryResult = Apollo.QueryResult<IndexHealthPlanPackagesQuery, IndexHealthPlanPackagesQueryVariables>;
export const IndexRatesDocument = gql`
    query indexRates($input: IndexRatesInput) {
  indexRates(input: $input) {
    totalCount
    edges {
      node {
        ...rateFieldsFragment
        draftRevision {
          ...rateRevisionFragment
        }
        revisions {
          ...rateRevisionFragment
        }
        packageSubmissions {
          ...ratePackageSubmissionsFragment
        }
      }
    }
  }
}
    ${RateFieldsFragmentFragmentDoc}
${RateRevisionFragmentFragmentDoc}
${RatePackageSubmissionsFragmentFragmentDoc}`;

/**
 * __useIndexRatesQuery__
 *
 * To run a query within a React component, call `useIndexRatesQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndexRatesQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndexRatesQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useIndexRatesQuery(baseOptions?: Apollo.QueryHookOptions<IndexRatesQuery, IndexRatesQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndexRatesQuery, IndexRatesQueryVariables>(IndexRatesDocument, options);
      }
export function useIndexRatesLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndexRatesQuery, IndexRatesQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndexRatesQuery, IndexRatesQueryVariables>(IndexRatesDocument, options);
        }
export function useIndexRatesSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<IndexRatesQuery, IndexRatesQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<IndexRatesQuery, IndexRatesQueryVariables>(IndexRatesDocument, options);
        }
export type IndexRatesQueryHookResult = ReturnType<typeof useIndexRatesQuery>;
export type IndexRatesLazyQueryHookResult = ReturnType<typeof useIndexRatesLazyQuery>;
export type IndexRatesSuspenseQueryHookResult = ReturnType<typeof useIndexRatesSuspenseQuery>;
export type IndexRatesQueryResult = Apollo.QueryResult<IndexRatesQuery, IndexRatesQueryVariables>;
export const IndexRatesForDashboardDocument = gql`
    query indexRatesForDashboard($input: IndexRatesInput) {
  indexRates(input: $input) {
    totalCount
    edges {
      node {
        ...rateFieldsFragment
        draftRevision {
          id
          rateID
          createdAt
          updatedAt
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          formData {
            rateType
            rateCapitationType
            rateDateStart
            rateDateEnd
            rateDateCertified
            amendmentEffectiveDateStart
            amendmentEffectiveDateEnd
            rateProgramIDs
            deprecatedRateProgramIDs
            consolidatedRateProgramIDs
            rateCertificationName
            certifyingActuaryContacts {
              name
              titleRole
              email
              actuarialFirm
              actuarialFirmOther
            }
            addtlActuaryContacts {
              name
              titleRole
              email
              actuarialFirm
              actuarialFirmOther
            }
            actuaryCommunicationPreference
            packagesWithSharedRateCerts {
              packageName
              packageId
              packageStatus
            }
          }
        }
        revisions {
          id
          rateID
          createdAt
          updatedAt
          unlockInfo {
            ...updateInformationFields
          }
          submitInfo {
            ...updateInformationFields
          }
          formData {
            rateType
            rateCapitationType
            rateDateStart
            rateDateEnd
            rateDateCertified
            amendmentEffectiveDateStart
            amendmentEffectiveDateEnd
            rateProgramIDs
            deprecatedRateProgramIDs
            consolidatedRateProgramIDs
            rateCertificationName
            certifyingActuaryContacts {
              name
              titleRole
              email
              actuarialFirm
              actuarialFirmOther
            }
            addtlActuaryContacts {
              name
              titleRole
              email
              actuarialFirm
              actuarialFirmOther
            }
            actuaryCommunicationPreference
            packagesWithSharedRateCerts {
              packageName
              packageId
              packageStatus
            }
          }
        }
      }
    }
  }
}
    ${RateFieldsFragmentFragmentDoc}
${UpdateInformationFieldsFragmentDoc}`;

/**
 * __useIndexRatesForDashboardQuery__
 *
 * To run a query within a React component, call `useIndexRatesForDashboardQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndexRatesForDashboardQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndexRatesForDashboardQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useIndexRatesForDashboardQuery(baseOptions?: Apollo.QueryHookOptions<IndexRatesForDashboardQuery, IndexRatesForDashboardQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndexRatesForDashboardQuery, IndexRatesForDashboardQueryVariables>(IndexRatesForDashboardDocument, options);
      }
export function useIndexRatesForDashboardLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndexRatesForDashboardQuery, IndexRatesForDashboardQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndexRatesForDashboardQuery, IndexRatesForDashboardQueryVariables>(IndexRatesForDashboardDocument, options);
        }
export function useIndexRatesForDashboardSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<IndexRatesForDashboardQuery, IndexRatesForDashboardQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<IndexRatesForDashboardQuery, IndexRatesForDashboardQueryVariables>(IndexRatesForDashboardDocument, options);
        }
export type IndexRatesForDashboardQueryHookResult = ReturnType<typeof useIndexRatesForDashboardQuery>;
export type IndexRatesForDashboardLazyQueryHookResult = ReturnType<typeof useIndexRatesForDashboardLazyQuery>;
export type IndexRatesForDashboardSuspenseQueryHookResult = ReturnType<typeof useIndexRatesForDashboardSuspenseQuery>;
export type IndexRatesForDashboardQueryResult = Apollo.QueryResult<IndexRatesForDashboardQuery, IndexRatesForDashboardQueryVariables>;
export const IndexRatesStrippedDocument = gql`
    query indexRatesStripped($input: IndexRatesInput) {
  indexRatesStripped(input: $input) {
    totalCount
    edges {
      node {
        id
        createdAt
        updatedAt
        status
        reviewStatus
        consolidatedStatus
        initiallySubmittedAt
        stateCode
        state {
          code
          name
          programs {
            id
            name
            fullName
            isRateProgram
          }
        }
        stateNumber
        parentContractID
        reviewStatusActions {
          updatedAt
          actionType
        }
        draftRevision {
          ...strippedRateRevisionFragment
        }
        latestSubmittedRevision {
          ...strippedRateRevisionFragment
        }
      }
    }
  }
}
    ${StrippedRateRevisionFragmentFragmentDoc}`;

/**
 * __useIndexRatesStrippedQuery__
 *
 * To run a query within a React component, call `useIndexRatesStrippedQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndexRatesStrippedQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndexRatesStrippedQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useIndexRatesStrippedQuery(baseOptions?: Apollo.QueryHookOptions<IndexRatesStrippedQuery, IndexRatesStrippedQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndexRatesStrippedQuery, IndexRatesStrippedQueryVariables>(IndexRatesStrippedDocument, options);
      }
export function useIndexRatesStrippedLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndexRatesStrippedQuery, IndexRatesStrippedQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndexRatesStrippedQuery, IndexRatesStrippedQueryVariables>(IndexRatesStrippedDocument, options);
        }
export function useIndexRatesStrippedSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<IndexRatesStrippedQuery, IndexRatesStrippedQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<IndexRatesStrippedQuery, IndexRatesStrippedQueryVariables>(IndexRatesStrippedDocument, options);
        }
export type IndexRatesStrippedQueryHookResult = ReturnType<typeof useIndexRatesStrippedQuery>;
export type IndexRatesStrippedLazyQueryHookResult = ReturnType<typeof useIndexRatesStrippedLazyQuery>;
export type IndexRatesStrippedSuspenseQueryHookResult = ReturnType<typeof useIndexRatesStrippedSuspenseQuery>;
export type IndexRatesStrippedQueryResult = Apollo.QueryResult<IndexRatesStrippedQuery, IndexRatesStrippedQueryVariables>;
export const IndexRatesStrippedWithRelatedContractsDocument = gql`
    query indexRatesStrippedWithRelatedContracts($input: IndexRatesInput) {
  indexRatesStripped(input: $input) {
    totalCount
    edges {
      node {
        id
        createdAt
        updatedAt
        status
        reviewStatus
        consolidatedStatus
        initiallySubmittedAt
        stateCode
        state {
          code
          name
          programs {
            id
            name
            fullName
            isRateProgram
          }
        }
        stateNumber
        parentContractID
        reviewStatusActions {
          updatedAt
          actionType
        }
        draftRevision {
          ...strippedRateRevisionFragment
        }
        latestSubmittedRevision {
          ...strippedRateRevisionFragment
        }
        relatedContracts {
          id
          consolidatedStatus
        }
      }
    }
  }
}
    ${StrippedRateRevisionFragmentFragmentDoc}`;

/**
 * __useIndexRatesStrippedWithRelatedContractsQuery__
 *
 * To run a query within a React component, call `useIndexRatesStrippedWithRelatedContractsQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndexRatesStrippedWithRelatedContractsQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndexRatesStrippedWithRelatedContractsQuery({
 *   variables: {
 *      input: // value for 'input'
 *   },
 * });
 */
export function useIndexRatesStrippedWithRelatedContractsQuery(baseOptions?: Apollo.QueryHookOptions<IndexRatesStrippedWithRelatedContractsQuery, IndexRatesStrippedWithRelatedContractsQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndexRatesStrippedWithRelatedContractsQuery, IndexRatesStrippedWithRelatedContractsQueryVariables>(IndexRatesStrippedWithRelatedContractsDocument, options);
      }
export function useIndexRatesStrippedWithRelatedContractsLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndexRatesStrippedWithRelatedContractsQuery, IndexRatesStrippedWithRelatedContractsQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndexRatesStrippedWithRelatedContractsQuery, IndexRatesStrippedWithRelatedContractsQueryVariables>(IndexRatesStrippedWithRelatedContractsDocument, options);
        }
export function useIndexRatesStrippedWithRelatedContractsSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<IndexRatesStrippedWithRelatedContractsQuery, IndexRatesStrippedWithRelatedContractsQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<IndexRatesStrippedWithRelatedContractsQuery, IndexRatesStrippedWithRelatedContractsQueryVariables>(IndexRatesStrippedWithRelatedContractsDocument, options);
        }
export type IndexRatesStrippedWithRelatedContractsQueryHookResult = ReturnType<typeof useIndexRatesStrippedWithRelatedContractsQuery>;
export type IndexRatesStrippedWithRelatedContractsLazyQueryHookResult = ReturnType<typeof useIndexRatesStrippedWithRelatedContractsLazyQuery>;
export type IndexRatesStrippedWithRelatedContractsSuspenseQueryHookResult = ReturnType<typeof useIndexRatesStrippedWithRelatedContractsSuspenseQuery>;
export type IndexRatesStrippedWithRelatedContractsQueryResult = Apollo.QueryResult<IndexRatesStrippedWithRelatedContractsQuery, IndexRatesStrippedWithRelatedContractsQueryVariables>;
export const IndexUsersDocument = gql`
    query indexUsers {
  indexUsers {
    totalCount
    edges {
      node {
        ... on CMSUser {
          ...cmsUserFragment
        }
        ... on CMSApproverUser {
          ...cmsApproverUserFragment
        }
        ... on StateUser {
          ...stateUserFragment
        }
        ... on AdminUser {
          ...adminUserFragment
        }
      }
    }
  }
}
    ${CmsUserFragmentFragmentDoc}
${CmsApproverUserFragmentFragmentDoc}
${StateUserFragmentFragmentDoc}
${AdminUserFragmentFragmentDoc}`;

/**
 * __useIndexUsersQuery__
 *
 * To run a query within a React component, call `useIndexUsersQuery` and pass it any options that fit your needs.
 * When your component renders, `useIndexUsersQuery` returns an object from Apollo Client that contains loading, error, and data properties
 * you can use to render your UI.
 *
 * @param baseOptions options that will be passed into the query, supported options are listed on: https://www.apollographql.com/docs/react/api/react-hooks/#options;
 *
 * @example
 * const { data, loading, error } = useIndexUsersQuery({
 *   variables: {
 *   },
 * });
 */
export function useIndexUsersQuery(baseOptions?: Apollo.QueryHookOptions<IndexUsersQuery, IndexUsersQueryVariables>) {
        const options = {...defaultOptions, ...baseOptions}
        return Apollo.useQuery<IndexUsersQuery, IndexUsersQueryVariables>(IndexUsersDocument, options);
      }
export function useIndexUsersLazyQuery(baseOptions?: Apollo.LazyQueryHookOptions<IndexUsersQuery, IndexUsersQueryVariables>) {
          const options = {...defaultOptions, ...baseOptions}
          return Apollo.useLazyQuery<IndexUsersQuery, IndexUsersQueryVariables>(IndexUsersDocument, options);
        }
export function useIndexUsersSuspenseQuery(baseOptions?: Apollo.SkipToken | Apollo.SuspenseQueryHookOptions<IndexUsersQuery, IndexUsersQueryVariables>) {
          const options = baseOptions === Apollo.skipToken ? baseOptions : {...defaultOptions, ...baseOptions}
          return Apollo.useSuspenseQuery<IndexUsersQuery, IndexUsersQueryVariables>(IndexUsersDocument, options);
        }
export type IndexUsersQueryHookResult = ReturnType<typeof useIndexUsersQuery>;
export type IndexUsersLazyQueryHookResult = ReturnType<typeof useIndexUsersLazyQuery>;
export type IndexUsersSuspenseQueryHookResult = ReturnType<typeof useIndexUsersSuspenseQuery>;
export type IndexUsersQueryResult = Apollo.QueryResult<IndexUsersQuery, IndexUsersQueryVariables>;