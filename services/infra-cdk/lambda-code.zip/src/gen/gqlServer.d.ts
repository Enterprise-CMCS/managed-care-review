import { GraphQLResolveInfo, GraphQLScalarType, GraphQLScalarTypeConfig } from 'graphql';
import { UserType, StateUserType, CMSUserType, HealthPlanPackageType, RateType, RateRevisionWithContractsType, ContractType as ContractDomainType, UnlockedContractType as UnlockedContractDomainType, ContractRevisionType, ContractPackageSubmissionWithCauseType, RatePackageSubmissionWithCauseType } from '../domain-models';
import { CMSApproverUserType, StrippedRateType } from '../domain-model';
import { Context } from '../handlers/apollo_gql';
export type Maybe<T> = T | null;
export type InputMaybe<T> = Maybe<T>;
export type Exact<T extends { [key: string]: unknown }> = { [K in keyof T]: T[K] };
export type MakeOptional<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]?: Maybe<T[SubKey]> };
export type MakeMaybe<T, K extends keyof T> = Omit<T, K> & { [SubKey in K]: Maybe<T[SubKey]> };
export type MakeEmpty<T extends { [key: string]: unknown }, K extends keyof T> = { [_ in K]?: never };
export type Incremental<T> = T | { [P in keyof T]?: P extends ' $fragmentName' | '__typename' ? T[P] : never };
export type Omit<T, K extends keyof T> = Pick<T, Exclude<keyof T, K>>;
export type RequireFields<T, K extends keyof T> = Omit<T, K> & { [P in K]-?: NonNullable<T[P]> };
/** All built-in and custom scalars, mapped to their actual values */
export type Scalars = {
  ID: { input: string; output: string; }
  String: { input: string; output: string; }
  Boolean: { input: boolean; output: boolean; }
  Int: { input: number; output: number; }
  Float: { input: number; output: number; }
  /** Date is a CalendarDate representing a day without time information */
  Date: { input: any; output: any; }
  /** DateTime is a moment in time with date and time information */
  DateTime: { input: any; output: any; }
};

/** The firm that the certifying actuary works for */
export type ActuarialFirm =
  | 'DELOITTE'
  | 'GUIDEHOUSE'
  | 'MERCER'
  | 'MILLIMAN'
  | 'OPTUMAS'
  | 'OTHER'
  | 'STATE_IN_HOUSE';

/**
 * State's communication preference for contacting their actuaries. Either:
 * - wants CMS to reach out to their actuaries directly or
 * - go through them
 */
export type ActuaryCommunication =
  | 'OACT_TO_ACTUARY'
  | 'OACT_TO_STATE';

/** Contact information for the certifying or additional state actuary */
export type ActuaryContact = {
  __typename?: 'ActuaryContact';
  actuarialFirm?: Maybe<ActuarialFirm>;
  actuarialFirmOther?: Maybe<Scalars['String']['output']>;
  email?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  titleRole?: Maybe<Scalars['String']['output']>;
};

/** Contact information input for the certifying or additional state actuary */
export type ActuaryContactInput = {
  actuarialFirm?: InputMaybe<ActuarialFirm>;
  actuarialFirmOther?: InputMaybe<Scalars['String']['input']>;
  email?: InputMaybe<Scalars['String']['input']>;
  id?: InputMaybe<Scalars['ID']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  titleRole?: InputMaybe<Scalars['String']['input']>;
};

/** AdminUser is a user that works on the MC Review app itself */
export type AdminUser = {
  __typename?: 'AdminUser';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'ADMIN_USER' */
  role: Scalars['String']['output'];
};

export type ApproveContractInput = {
  /** The ID of the contract to approve */
  contractID: Scalars['ID']['input'];
  /** Manually entered date for when the approval was released to the state */
  dateApprovalReleasedToState: Scalars['Date']['input'];
};

export type ApproveContractPayload = {
  __typename?: 'ApproveContractPayload';
  contract: Contract;
};

/** The Business Owner is the root of our role hierarchy with the power to approve new admin accounts */
export type BusinessOwnerUser = {
  __typename?: 'BusinessOwnerUser';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'BUSINESSOWNER_USER' */
  role: Scalars['String']['output'];
};

/** CMSApproverUser is a user that works for CMS, approving CMS approver request and able to do everything a CMSUser can do */
export type CmsApproverUser = {
  __typename?: 'CMSApproverUser';
  divisionAssignment?: Maybe<Division>;
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'CMS_APPROVER_USER' */
  role: Scalars['String']['output'];
  stateAssignments: Array<State>;
};

/** CMSUser is a user that works for CMS, reviewing packages submitted by StateUsers */
export type CmsUser = {
  __typename?: 'CMSUser';
  divisionAssignment?: Maybe<Division>;
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'CMS_USER' */
  role: Scalars['String']['output'];
  stateAssignments: Array<State>;
};

export type CmsUsersUnion = CmsApproverUser | CmsUser;

/**
 * This status has been synthesized to reflect if the status or review status
 * should be used
 */
export type ConsolidatedContractStatus =
  | 'APPROVED'
  | 'DRAFT'
  | 'RESUBMITTED'
  | 'SUBMITTED'
  | 'UNLOCKED'
  | 'WITHDRAWN';

/**
 * This status has been synthesized to reflect if the status or review status
 * should be used
 */
export type ConsolidatedRateStatus =
  | 'DRAFT'
  | 'RESUBMITTED'
  | 'SUBMITTED'
  | 'UNLOCKED'
  | 'WITHDRAWN';

/**
 * Contract is a single contract submission, holding all the form data for a single contract
 * and associated with zero or more Rates
 */
export type Contract = {
  __typename?: 'Contract';
  /**
   * Synthesized field that represents if a contract's status or
   * reviewStatus should take precedence
   * Options are DRAFT, SUBMITTED, RESUBMITTED UNLOCKED, UNDER_REVIEW, APPROVED, WITHDRAWN
   */
  consolidatedStatus: ConsolidatedContractStatus;
  createdAt: Scalars['DateTime']['output'];
  /** dateContractDocsExecuted is the first date, if any in which the revisions were submitted with all contract docs executed. Null otherwise. */
  dateContractDocsExecuted?: Maybe<Scalars['DateTime']['output']>;
  /**
   * draftRates are the Rates that this editable submission are related to.
   * On submission they are cemented into a new ContractPackageSubmission
   */
  draftRates?: Maybe<Array<Rate>>;
  /** draftRevision is the currently modifiable revision if the rate is DRAFT or UNLOCKED */
  draftRevision?: Maybe<ContractRevision>;
  id: Scalars['ID']['output'];
  /** initiallySubmittedAt is the initial date this contract was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['DateTime']['output']>;
  /** lastUpdatedForDisplay is the last time this contract was officially updated. When it's a draft it will be the last updatedAt date. Afterwards it will be the most recent submit or unlock or review action date. */
  lastUpdatedForDisplay: Scalars['DateTime']['output'];
  /** mccrsID is the four digit id in MC-CRS that corresponds to this Contract, if set */
  mccrsID?: Maybe<Scalars['String']['output']>;
  /**
   * packageSubmissions are a snapshot of the contract and its related rates through time
   * each packageSubmission was created by a submission of this contract and/or its related rates
   * a DRAFT Contract will have no packageSubmissions. Returned in _ascending_ order. Most recent
   * submission is in the first position in the array.
   */
  packageSubmissions: Array<ContractPackageSubmission>;
  /**
   * questions field is an array of questions asked about the contract by CMS. Each questions also contains responses
   * to the question submitted by the State. DRAFT contracts will not have questions, only contracts that have been submitted
   * , unlocked, or resubmitted. The array is in descending order by createdAt.
   */
  questions?: Maybe<IndexContractQuestionsPayload>;
  /**
   * Where the contract is in the review submission flow
   * Options are UNDER_REVIEW, APPROVED, WITHDRAWN
   */
  reviewStatus: ContractReviewStatus;
  /** reviewStatusActions are the who/when/why for review status changes on this contract */
  reviewStatusActions?: Maybe<Array<ContractReviewStatusActions>>;
  /** state is fuller state data for the submitting state */
  state: State;
  /** stateCode is the state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * stateNumber is a unique auto-incrementing number identifying this contract
   * This value is used to generate the contractName
   */
  stateNumber: Scalars['Int']['output'];
  /**
   * Where the contract is in the submission flow.
   * Options are DRAFT, SUBMITTED, RESUBMITTED and UNLOCKED
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: HealthPlanPackageStatus;
  updatedAt: Scalars['DateTime']['output'];
  /** webURL is a url that will open the MC Review web app to this Contract */
  webURL: Scalars['String']['output'];
  /** Rates withdrawn from this contract submission */
  withdrawnRates?: Maybe<Array<Rate>>;
};

export type ContractActionType =
  | 'MARK_AS_APPROVED'
  | 'UNDER_REVIEW'
  | 'WITHDRAW';

export type ContractDraftRevisionFormDataInput = {
  /** End date of the contract */
  contractDateEnd?: InputMaybe<Scalars['Date']['input']>;
  /** Start date of the contract */
  contractDateStart?: InputMaybe<Scalars['Date']['input']>;
  /** State upload of the submitted contract */
  contractDocuments: Array<GenericDocumentInput>;
  /**
   * Execution status for a contract.
   * Contracts are fully executed or unexecuted by some or all parties
   * Status can be either EXECUTED or UNEXECUTED
   */
  contractExecutionStatus?: InputMaybe<ContractExecutionStatus>;
  /**
   * Type of contract the state is submitting
   * Options are: BASE, AMENDMENT
   */
  contractType?: InputMaybe<ContractType>;
  /**
   * The state plan and/or waiver authorities that allow the state
   * to run its managed care programs
   */
  federalAuthorities: Array<FederalAuthority>;
  /**
   * If contract is in Lieu-of Services and Settings (ILOSs)
   * in accordance with 42 CFR § 438.3(e)(2)
   */
  inLieuServicesAndSettings?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * The type of organization the state is contracting with
   * in order to deliver managed care services
   * Options are MCO, PIHP, PAHP, and PCCM
   */
  managedCareEntities: Array<ManagedCareEntity>;
  /** If contract includes modifications to benefits provided by the managed care plans */
  modifiedBenefitsProvided?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the enrollment/disenrollment process */
  modifiedEnrollmentProcess?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the geographic areas served by the managed care plans */
  modifiedGeoAreaServed?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the grevience and appeal system */
  modifiedGrevienceAndAppeal?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to incentive arrangements */
  modifiedIncentiveArrangements?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the length of the contract period */
  modifiedLengthOfContract?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * If contract includes modifications to the Medicaid beneficiaries served by the managed care
   * plans (e.g. eligibility or enrollment criteria)
   */
  modifiedMedicaidBeneficiaries?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the medical loss ratio standards */
  modifiedMedicalLossRatioStandards?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the network adequacy standards */
  modifiedNetworkAdequacyStandards?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the non-risk payment arrangements */
  modifiedNonRiskPaymentArrangements?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * If contract includes modifications to
   * other financial, payment, incentive or related contractual provisions
   */
  modifiedOtherFinancialPaymentIncentive?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the pass-through payments */
  modifiedPassThroughPayments?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * If contract includes modifications to payments to MCOs and PIHPs for enrollees that
   * are a patient in an institution for mental disease
   */
  modifiedPaymentsForMentalDiseaseInstitutions?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the risk sharing strategy */
  modifiedRiskSharingStrategy?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the state directed payments */
  modifiedStateDirectedPayments?: InputMaybe<Scalars['Boolean']['input']>;
  /** If contract includes modifications to the withold agreements */
  modifiedWitholdAgreements?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * The large overarching population of people that the program covers.
   * Options are MEDICAID, CHIP, MEDICAID_AND_CHIP
   */
  populationCovered?: InputMaybe<PopulationCovered>;
  /** An array of IDs representing state programs that the contract covers */
  programIDs: Array<Scalars['String']['input']>;
  /**
   * Whether or not this contract is risk based
   * Risk-based contracts have specific requirements that
   * non-risk based contracts do not have
   */
  riskBasedContract?: InputMaybe<Scalars['Boolean']['input']>;
  /**
   * Array of state contacts of state representatives who should be
   * contacted about updates to the contract
   * Each state contact contains string fields for: name, title, and email
   */
  stateContacts: Array<StateContactInput>;
  /** If contract has statutory regulatory attestation */
  statutoryRegulatoryAttestation?: InputMaybe<Scalars['Boolean']['input']>;
  /** Description provided for if contract has statutory regulatory attestation */
  statutoryRegulatoryAttestationDescription?: InputMaybe<Scalars['String']['input']>;
  /** State provided summary of the contract being submitted */
  submissionDescription?: InputMaybe<Scalars['String']['input']>;
  /**
   * The submission type of this package
   * Options are CONTRACT_ONLY and CONTRACT_AND_RATES
   */
  submissionType?: InputMaybe<SubmissionType>;
  /**
   * Additional documents the state uploads to support a contract
   * Files can be PDF, DOC, DOCX, XLSX, CSV format
   */
  supportingDocuments: Array<GenericDocumentInput>;
};

export type ContractEdge = {
  __typename?: 'ContractEdge';
  node: Contract;
};

/** Whether contract has been fully executed by all parties or not */
export type ContractExecutionStatus =
  | 'EXECUTED'
  | 'UNEXECUTED';

/**
 * ContractFormData represents the form data that was inputted by the state
 * This type is used for the form data field found on a contract revision
 */
export type ContractFormData = {
  __typename?: 'ContractFormData';
  /** End date of the contract */
  contractDateEnd?: Maybe<Scalars['Date']['output']>;
  /** Start date of the contract */
  contractDateStart?: Maybe<Scalars['Date']['output']>;
  /** State upload of the submitted contract */
  contractDocuments: Array<GenericDocument>;
  /**
   * Execution status for a contract.
   * Contracts are fully executed or unexecuted by some or all parties
   * Status can be either EXECUTED or UNEXECUTED
   */
  contractExecutionStatus?: Maybe<ContractExecutionStatus>;
  /**
   * Type of contract the state is submitting
   * Options are: BASE, AMENDMENT
   */
  contractType?: Maybe<ContractType>;
  /**
   * The state plan and/or waiver authorities that allow the state
   * to run its managed care programs
   */
  federalAuthorities: Array<FederalAuthority>;
  /**
   * If contract is in Lieu-of Services and Settings (ILOSs)
   * in accordance with 42 CFR § 438.3(e)(2)
   */
  inLieuServicesAndSettings?: Maybe<Scalars['Boolean']['output']>;
  /**
   * The type of organization the state is contracting with
   * in order to deliver managed care services
   * Options are MCO, PIHP, PAHP, and PCCM
   */
  managedCareEntities: Array<ManagedCareEntity>;
  /** If contract includes modifications to benefits provided by the managed care plans */
  modifiedBenefitsProvided?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the enrollment/disenrollment process */
  modifiedEnrollmentProcess?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the geographic areas served by the managed care plans */
  modifiedGeoAreaServed?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the grevience and appeal system */
  modifiedGrevienceAndAppeal?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to incentive arrangements */
  modifiedIncentiveArrangements?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the length of the contract period */
  modifiedLengthOfContract?: Maybe<Scalars['Boolean']['output']>;
  /**
   * If contract includes modifications to the Medicaid beneficiaries served by the managed care
   * plans (e.g. eligibility or enrollment criteria)
   */
  modifiedMedicaidBeneficiaries?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the medical loss ratio standards */
  modifiedMedicalLossRatioStandards?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the network adequacy standards */
  modifiedNetworkAdequacyStandards?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the non-risk payment arrangements */
  modifiedNonRiskPaymentArrangements?: Maybe<Scalars['Boolean']['output']>;
  /**
   * If contract includes modifications to
   * other financial, payment, incentive or related contractual provisions
   */
  modifiedOtherFinancialPaymentIncentive?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the pass-through payments */
  modifiedPassThroughPayments?: Maybe<Scalars['Boolean']['output']>;
  /**
   * If contract includes modifications to payments to MCOs and PIHPs for enrollees that
   * are a patient in an institution for mental disease
   */
  modifiedPaymentsForMentalDiseaseInstitutions?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the risk sharing strategy */
  modifiedRiskSharingStrategy?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the state directed payments */
  modifiedStateDirectedPayments?: Maybe<Scalars['Boolean']['output']>;
  /** If contract includes modifications to the withold agreements */
  modifiedWitholdAgreements?: Maybe<Scalars['Boolean']['output']>;
  /**
   * The large overarching population of people that the program covers.
   * Options are MEDICAID, CHIP, MEDICAID_AND_CHIP
   */
  populationCovered?: Maybe<PopulationCovered>;
  /** An array of IDs representing state programs that the contract covers */
  programIDs: Array<Scalars['String']['output']>;
  /**
   * Whether or not this contract is risk based
   * Risk-based contracts have specific requirements that
   * non-risk based contracts do not have
   */
  riskBasedContract?: Maybe<Scalars['Boolean']['output']>;
  /**
   * Array of state contacts of state representatives who should be
   * contacted about updates to the contract
   * Each state contact contains string fields for: name, title, and email
   */
  stateContacts: Array<StateContact>;
  /** If contract has statutory regulatory attestation */
  statutoryRegulatoryAttestation?: Maybe<Scalars['Boolean']['output']>;
  /** Description provided for if contract has statutory regulatory attestation */
  statutoryRegulatoryAttestationDescription?: Maybe<Scalars['String']['output']>;
  /** State provided summary of the contract being submitted */
  submissionDescription: Scalars['String']['output'];
  /**
   * The submission type of this package
   * Options are CONTRACT_ONLY and CONTRACT_AND_RATES
   */
  submissionType: SubmissionType;
  /**
   * Additional documents the state uploads to support a contract
   * Files can be PDF, DOC, DOCX, XLSX, CSV format
   */
  supportingDocuments: Array<GenericDocument>;
};

/**
 * ContractPackageSubmission is a snapshot of a contract and all its related rates in time
 * a ContractPackageSubmission can be created by the user submitting a contract or a related rate
 */
export type ContractPackageSubmission = {
  __typename?: 'ContractPackageSubmission';
  /** cause is a hint as to why this submission was created */
  cause: SubmissionReason;
  /** contractRevision is the contract revision current at the time of this package submission */
  contractRevision: ContractRevision;
  /** rateRevisions are the linked rate revisions current at the time of this package submission */
  rateRevisions: Array<RateRevision>;
  /** submitInfo provides the submission reason/date/by for this package submission */
  submitInfo: UpdateInformation;
  /** submittedRevisions is a list of contract and/or rate revisions that were submitted to create this package submission */
  submittedRevisions: Array<SubmittableRevision>;
};

/**
 * ContractQuestion is a question sent by CMS to the States for a response, associated with a single contract.
 * CMS may upload one or more documents full of questions to a single ContractQuestion. States submit a
 * QuestionResponse with documents that answer the questions posed by CMS.
 */
export type ContractQuestion = {
  __typename?: 'ContractQuestion';
  addedBy: CmsUsersUnion;
  contractID: Scalars['ID']['output'];
  createdAt: Scalars['DateTime']['output'];
  division: Division;
  documents: Array<Document>;
  id: Scalars['ID']['output'];
  responses: Array<QuestionResponse>;
  round: Scalars['Int']['output'];
};

export type ContractQuestionEdge = {
  __typename?: 'ContractQuestionEdge';
  node: ContractQuestion;
};

export type ContractQuestionList = {
  __typename?: 'ContractQuestionList';
  edges: Array<ContractQuestionEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

/**
 * This status is used to determine whether the package is currently being edited by a state user
 * or if it has been submitted and is being reviewed by CMS users.
 */
export type ContractReviewStatus =
  | 'APPROVED'
  | 'UNDER_REVIEW'
  | 'WITHDRAWN';

/** ContractReviewStatusActions is used for the review status actions on the contract */
export type ContractReviewStatusActions = {
  __typename?: 'ContractReviewStatusActions';
  /** the type of review action performed on the contract: APPROVED, WITHDRAWN */
  actionType: ContractActionType;
  contractID: Scalars['ID']['output'];
  /** Manual time entered by CMS to represent when an approval released to state */
  dateApprovalReleasedToState?: Maybe<Scalars['DateTime']['output']>;
  /** the datetime when the update occurred */
  updatedAt: Scalars['DateTime']['output'];
  /** the user who performed the update */
  updatedBy: UpdatedBy;
  /** the reason provided by the user when performing the update */
  updatedReason?: Maybe<Scalars['String']['output']>;
};

/**
 * ContractRevision is a single instance of all the contract specific data in a submission
 * it contains the unlock and submit info.
 */
export type ContractRevision = {
  __typename?: 'ContractRevision';
  contractID: Scalars['String']['output'];
  /**
   * Represents the name of the contract pacakge.
   * This value is auto generated based on contract state number, contract type, dates, and state program details"\
   */
  contractName: Scalars['String']['output'];
  createdAt: Scalars['DateTime']['output'];
  /** formData is all the contract specific info part of this submission */
  formData: ContractFormData;
  id: Scalars['ID']['output'];
  /** submitInfo is the who/when/why for this revision being submitted. An Unlocked revision has no submitInfo */
  submitInfo?: Maybe<UpdateInformation>;
  /** unlockInfo is the who/when/why for this revision being unlocked. A DRAFT or SUBMITTED revision will not have one */
  unlockInfo?: Maybe<UpdateInformation>;
  updatedAt: Scalars['DateTime']['output'];
};

export type ContractType =
  | 'AMENDMENT'
  | 'BASE';

export type CreateApiKeyPayload = {
  __typename?: 'CreateAPIKeyPayload';
  expiresAt: Scalars['DateTime']['output'];
  key: Scalars['String']['output'];
};

export type CreateContractInput = {
  /**
   * Type of contract the state is submitting
   * Options are: BASE, AMENDMENT
   */
  contractType: ContractType;
  /**
   * The large overarching population of people that the program covers.
   * Options are MEDICAID, CHIP, MEDICAID_AND_CHIP
   */
  populationCovered: PopulationCovered;
  /** An array of managed care program IDs this package covers */
  programIDs: Array<Scalars['String']['input']>;
  /** Whether or not this contract is risk based */
  riskBasedContract?: InputMaybe<Scalars['Boolean']['input']>;
  /** User description of the reason for the submission */
  submissionDescription: Scalars['String']['input'];
  /**
   * The submission type of this package
   * Options are CONTRACT_ONLY and CONTRACT_AND_RATES
   */
  submissionType: SubmissionType;
};

export type CreateContractPayload = {
  __typename?: 'CreateContractPayload';
  contract: Contract;
};

export type CreateContractQuestionInput = {
  /** The ID of the package for which to create a question */
  contractID: Scalars['ID']['input'];
  /** A list of documents to attach to the question */
  documents: Array<DocumentInput>;
  /** The date the answer to the question is due */
  dueDate?: InputMaybe<Scalars['Date']['input']>;
  /** A note to attach to the question */
  noteText?: InputMaybe<Scalars['String']['input']>;
  /** The rate IDs associated with the question */
  rateIDs?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type CreateContractQuestionPayload = {
  __typename?: 'CreateContractQuestionPayload';
  /** The newly created Question */
  question: ContractQuestion;
};

export type CreateContractQuestionResponsePayload = {
  __typename?: 'CreateContractQuestionResponsePayload';
  /** Contract Question with newly created response */
  question: ContractQuestion;
};

export type CreateHealthPlanPackageInput = {
  /**
   * Type of contract the state is submitting
   * Options are: BASE, AMENDMENT
   */
  contractType: ContractType;
  /**
   * The large overarching population of people that the program covers.
   * Options are MEDICAID, CHIP, MEDICAID_AND_CHIP
   */
  populationCovered: PopulationCoveredType;
  /** An array of managed care program IDs this package covers */
  programIDs: Array<Scalars['ID']['input']>;
  /** Whether or not this contract is risk based */
  riskBasedContract?: InputMaybe<Scalars['Boolean']['input']>;
  /** User description of the reason for the submission */
  submissionDescription: Scalars['String']['input'];
  /**
   * The submission type of this package
   * Options are CONTRACT_ONLY and CONTRACT_AND_RATES
   */
  submissionType: SubmissionType;
};

export type CreateHealthPlanPackagePayload = {
  __typename?: 'CreateHealthPlanPackagePayload';
  /** The newly created HealthPlanPackage */
  pkg: HealthPlanPackage;
};

export type CreateOauthClientInput = {
  contactEmail: Scalars['String']['input'];
  description?: InputMaybe<Scalars['String']['input']>;
  grants?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type CreateOauthClientPayload = {
  __typename?: 'CreateOauthClientPayload';
  oauthClient: OauthClient;
};

/** Generic input type for both Contract and Rate Question. */
export type CreateQuestionResponseInput = {
  /** A list of documents to attach to the response */
  documents: Array<DocumentInput>;
  /** A note to attach to the response */
  noteText?: InputMaybe<Scalars['String']['input']>;
  /** The ID of the question for which to create a response */
  questionID: Scalars['ID']['input'];
};

export type CreateRateQuestionInput = {
  /** A list of documents to attach to the question */
  documents: Array<DocumentInput>;
  /** The date the answer to the question is due */
  dueDate?: InputMaybe<Scalars['Date']['input']>;
  /** A note to attach to the question */
  noteText?: InputMaybe<Scalars['String']['input']>;
  /** The ID of the rate for which to create a question */
  rateID: Scalars['ID']['input'];
};

export type CreateRateQuestionPayload = {
  __typename?: 'CreateRateQuestionPayload';
  /** The newly created rate question */
  question: RateQuestion;
};

export type CreateRateQuestionResponsePayload = {
  __typename?: 'CreateRateQuestionResponsePayload';
  /** Rate Question with newly created response */
  question: RateQuestion;
};

export type DeleteOauthClientInput = {
  clientId: Scalars['String']['input'];
};

export type DeleteOauthClientPayload = {
  __typename?: 'DeleteOauthClientPayload';
  oauthClient: OauthClient;
};

export type Division =
  | 'DMCO'
  | 'DMCP'
  | 'OACT';

/**
 * Document represents a document that has been uploaded to S3. It can be retrieved at the s3URL
 * by an authenticated user.
 */
export type Document = {
  __typename?: 'Document';
  downloadURL?: Maybe<Scalars['String']['output']>;
  name: Scalars['String']['output'];
  s3URL: Scalars['String']['output'];
};

export type DocumentInput = {
  /** The url used for downloading a file from S3 */
  downloadURL?: InputMaybe<Scalars['String']['input']>;
  /** The name of the document */
  name: Scalars['String']['input'];
  /** The S3 URL of the document */
  s3URL: Scalars['String']['input'];
};

/** Email configurations for the application used in automated emails */
export type EmailConfiguration = {
  __typename?: 'EmailConfiguration';
  cmsRateHelpEmailAddress: Scalars['String']['output'];
  cmsReviewHelpEmailAddress: Scalars['String']['output'];
  devReviewTeamEmails: Array<Scalars['String']['output']>;
  dmcoEmails: Array<Scalars['String']['output']>;
  dmcpReviewEmails: Array<Scalars['String']['output']>;
  dmcpSubmissionEmails: Array<Scalars['String']['output']>;
  emailSource: Scalars['String']['output'];
  helpDeskEmail: Scalars['String']['output'];
  oactEmails: Array<Scalars['String']['output']>;
};

export type EmailConfigurationInput = {
  cmsRateHelpEmailAddress: Scalars['String']['input'];
  cmsReviewHelpEmailAddress: Scalars['String']['input'];
  devReviewTeamEmails: Array<Scalars['String']['input']>;
  dmcoEmails: Array<Scalars['String']['input']>;
  dmcpReviewEmails: Array<Scalars['String']['input']>;
  dmcpSubmissionEmails: Array<Scalars['String']['input']>;
  emailSource: Scalars['String']['input'];
  helpDeskEmail: Scalars['String']['input'];
  oactEmails: Array<Scalars['String']['input']>;
};

/**
 * The state plan and/or waiver authorities that allow the
 * state to run its managed care programs
 */
export type FederalAuthority =
  | 'BENCHMARK'
  | 'STATE_PLAN'
  | 'TITLE_XXI'
  | 'VOLUNTARY'
  | 'WAIVER_1115'
  | 'WAIVER_1915B';

export type FetchContractInput = {
  contractID: Scalars['ID']['input'];
};

export type FetchContractPayload = {
  __typename?: 'FetchContractPayload';
  /** A contract that include contract and rate revisions */
  contract: Contract;
};

export type FetchHealthPlanPackageInput = {
  /** The ID of the package to fetch */
  pkgID: Scalars['ID']['input'];
};

export type FetchHealthPlanPackagePayload = {
  __typename?: 'FetchHealthPlanPackagePayload';
  /** A single HealthPlanPackage */
  pkg: HealthPlanPackage;
};

export type FetchMcReviewSettingsPayload = {
  __typename?: 'FetchMcReviewSettingsPayload';
  emailConfiguration?: Maybe<EmailConfiguration>;
  stateAssignments: Array<StateAssignment>;
};

export type FetchOauthClientsInput = {
  clientIds?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type FetchOauthClientsPayload = {
  __typename?: 'FetchOauthClientsPayload';
  oauthClients: Array<OauthClient>;
};

export type FetchRateInput = {
  rateID: Scalars['ID']['input'];
};

export type FetchRatePayload = {
  __typename?: 'FetchRatePayload';
  /** A rate that include contract and rate revisions */
  rate: Rate;
};

/**
 * GenericDocument
 *
 * This document type should be used (or extended) everywhere we pass documents through GraphQL regardless of domain
 */
export type GenericDocument = {
  __typename?: 'GenericDocument';
  /** The first date this document was added to submitted package - if still an initial draft, this date is last updated, otherwise it is the submitInfo lastUpdated */
  dateAdded?: Maybe<Scalars['DateTime']['output']>;
  /** URL received from S3 for downloading the document */
  downloadURL?: Maybe<Scalars['String']['output']>;
  id?: Maybe<Scalars['ID']['output']>;
  /** The user created name of the document */
  name: Scalars['String']['output'];
  /** The S3 URL of the document, generated on the FE currently in the FileUpload component */
  s3URL: Scalars['String']['output'];
  /** The sha256 is a unique string representing the file, generated on the FE currently in the FileUpload component */
  sha256: Scalars['String']['output'];
};

/**
 * GenericDocument
 *
 * This document input should be used (or extended) everywhere we pass documents through GraphQL regardless of domain
 */
export type GenericDocumentInput = {
  /** The first date this document was added to submitted package - this is ignored on input and regenerated on return */
  dateAdded?: InputMaybe<Scalars['DateTime']['input']>;
  /** The url used for downloading a file from S3 */
  downloadURL?: InputMaybe<Scalars['String']['input']>;
  /** The user created name of the document */
  name: Scalars['String']['input'];
  /** The S3 URL of the document, generated on the FE currently in the FileUpload component */
  s3URL: Scalars['String']['input'];
  /** The sha256 is a unique string representing the file, generated on the FE currently in the FileUpload component */
  sha256: Scalars['String']['input'];
};

/**
 * HealthPlanPackage is the core type for a single package submission. All the
 * submission data is contained in the HealthPlanRevision type, allowing us to store
 * the full history of packages previously submitted.
 *
 * HealthPlanPackages are submitted by state users and reviewed by CMS users.
 * Initally created in DRAFT state, they are submitted using the submitHealthPlanPackage mutation.
 * CMS users are able to use the unlockHealthPlanPackage mutation to return it to the state user in
 * the UNLOCKED state for corrections. State users can then resubmit.
 */
export type HealthPlanPackage = {
  __typename?: 'HealthPlanPackage';
  /** uuid */
  id: Scalars['ID']['output'];
  /** The initial date this package was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['Date']['output']>;
  /** MC-CRS record number provided by CMS user (e.g. 1234) */
  mccrsID?: Maybe<Scalars['String']['output']>;
  questions?: Maybe<IndexContractQuestionsPayload>;
  /**
   * Array of revisions for this package. Each revision represents a single submission
   * for the package and contains the full data from when it was submitted
   */
  revisions: Array<HealthPlanRevisionEdge>;
  /** Fuller state data for the submitting state */
  state: State;
  /** The state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * Where the package is in the submission flow.
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: HealthPlanPackageStatus;
};

export type HealthPlanPackageEdge = {
  __typename?: 'HealthPlanPackageEdge';
  node: HealthPlanPackage;
};

/**
 * HealthPlanPackageStatus tracks the editing vs. submitted status of the package.
 * It is not intended to track the overall status of the package through the review process
 * as that is fleshed out.
 *
 * State Machine:
 * ```
 * DRAFT -> SUBMITTED -> UNLOCKED -> RESUBMITTED
 *                          ^               |
 *                          |---------------|
 * ```
 *
 * This status is used to determine whether the package is currently being edited by a state user
 * or if it has been submitted and is being reviewed by CMS users.
 */
export type HealthPlanPackageStatus =
  | 'DRAFT'
  | 'RESUBMITTED'
  | 'SUBMITTED'
  | 'UNLOCKED';

/**
 * HealthPlanRevision is a single revision of the package. It contains all the
 * data from the form filled out by a state user about their package. When a
 * HealthPlanPackage is initially created, a single revision is created as well. That
 * revision has its submitInfo filled out when it is submitted, which is what marks
 * the HealthPlanPackage as SUBMITTED.
 *
 * When a HealthPlanPackage is unlocked with the unlockHealthPlanPackage mutation
 * a new revision is created with a copy of the previous revision's formDataProto and its
 * unlockInfo filled out. This can then be modified by the state user and resubmitted.
 */
export type HealthPlanRevision = {
  __typename?: 'HealthPlanRevision';
  createdAt: Scalars['DateTime']['output'];
  /**
   * base64 encoded HealthPlanFormData protobuf. This contains all the data
   * from the health plan pacakge form that the state user fills out and submits.
   * Its schema can be found in health_plan_form_data.proto
   */
  formDataProto: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** Information on who, when, and why this revision was submitted. */
  submitInfo?: Maybe<UpdateInformation>;
  /**
   * Information about who, when, and why this revision was unlocked.
   * Will be blank on the initial revision.
   */
  unlockInfo?: Maybe<UpdateInformation>;
};

export type HealthPlanRevisionEdge = {
  __typename?: 'HealthPlanRevisionEdge';
  node: HealthPlanRevision;
};

/** HelpdeskUser is a user that supports state and cms users */
export type HelpdeskUser = {
  __typename?: 'HelpdeskUser';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'HELPDESK_USER' */
  role: Scalars['String']['output'];
};

export type IndexContractQuestionsPayload = {
  __typename?: 'IndexContractQuestionsPayload';
  /** Questions for a given submission that were asked by DMCO within CMS */
  DMCOQuestions: ContractQuestionList;
  /** Questions for a given submission that were asked by DMCP within CMS */
  DMCPQuestions: ContractQuestionList;
  /** Questions for a given submission that were asked by OACT within CMS */
  OACTQuestions: ContractQuestionList;
};

export type IndexContractsPayload = {
  __typename?: 'IndexContractsPayload';
  edges: Array<ContractEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type IndexHealthPlanPackagesPayload = {
  __typename?: 'IndexHealthPlanPackagesPayload';
  edges: Array<HealthPlanPackageEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type IndexRateQuestionsPayload = {
  __typename?: 'IndexRateQuestionsPayload';
  /** Questions for a given rate that were asked by DMCO within CMS */
  DMCOQuestions: RateQuestionList;
  /** Questions for a given rate that were asked by DMCP within CMS */
  DMCPQuestions: RateQuestionList;
  /** Questions for a given rate that were asked by OACT within CMS */
  OACTQuestions: RateQuestionList;
};

export type IndexRatesInput = {
  rateIDs?: InputMaybe<Array<Scalars['String']['input']>>;
  stateCode?: InputMaybe<Scalars['String']['input']>;
};

export type IndexRatesPayload = {
  __typename?: 'IndexRatesPayload';
  /** Rates that include rate and contract revisions */
  edges: Array<RateEdge>;
  /** Total number of submitted rates returned on request */
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type IndexRatesStrippedPayload = {
  __typename?: 'IndexRatesStrippedPayload';
  edges: Array<RateStrippedEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

export type IndexUsersPayload = {
  __typename?: 'IndexUsersPayload';
  edges: Array<UserEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

/**
 * The type of organization the state is contracting with in order to deliver
 * managed care services
 */
export type ManagedCareEntity =
  | 'MCO'
  | 'PAHP'
  | 'PCCM'
  | 'PIHP';

export type Mutation = {
  __typename?: 'Mutation';
  /**
   * approveContract is a CMS user only action
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMS/CMS Approver user called this
   * - UserInputError:
   *     - A contract is not in the correct submission status: SUBMITTED or RESUBMITTED
   *     - A contract is not in the correct review status: UNDER_REVIEW
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - A contract cannot be found by id
   */
  approveContract?: Maybe<ApproveContractPayload>;
  /** createAPIKey creates a valid API key for the logged in user, valid for 90 days */
  createAPIKey: CreateApiKeyPayload;
  /**
   * createContract creates a new Contract.
   *
   * The new Contract is created with a single contractRevision with
   * the information specified in the input parameters. The created contract will have
   * the DRAFT status. The stateCode of the contract will be set to the state the
   * user that calls this mutation is from.
   *
   * This can only be called by StateUsers
   *
   * Errors:
   * - ForbiddenError: A CMSUser calls this mutation
   * - UserInputError: ProgramID not found in this state's programs
   */
  createContract: CreateContractPayload;
  /**
   * createContractQuestion creates a new question for the given Contract
   * A CMS User can add text to a note field and append a document to their question
   * They can also specify a due date, and specify rate IDs that are associated with the question
   *
   * This can only be called by a CMSUser
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMSUser called this
   *     - A CMS user with unassigned division
   * - UserInputError
   *     - A package cannot be found with the given `contractID`
   *     - The contract is in the DRAFT state
   *     - The due date is in the past
   *     - The rateIDs are not associated with the package
   */
  createContractQuestion: CreateContractQuestionPayload;
  /**
   * createContractQuestionResponse creates a new response for the given question
   * A State User can add text to a note field and append a document to their response
   *
   * This can only be called by a StateUser
   *
   * Errors:
   * - ForbiddenError:
   *     - A non StateUser called this
   * - UserInputError
   *     - A Question cannot be found given `questionID`
   */
  createContractQuestionResponse: CreateContractQuestionResponsePayload;
  /**
   * createHealthPlanPackage creates a new HealthPlanPackage.
   *
   * The new HealthPlanPackage is created with a single HealthPlanRevision with
   * the information specified in the input parameters. The created package will have
   * the DRAFT status. The stateCode of the package will be set to the state the
   * user that calls this mutation is from.
   *
   * This can only be called by StateUsers
   *
   * Errors:
   * - ForbiddenError: A CMSUser calls this mutation
   * - UserInputError: ProgramID not found in this state's programs
   */
  createHealthPlanPackage: CreateHealthPlanPackagePayload;
  createOauthClient: CreateOauthClientPayload;
  /**
   * createRateQuestion creates a new Question for the given rate
   * A CMS User can add text to a note field and append a document to their question
   * They can also specify a due date, and specify rate IDs that are associated with the question
   *
   * This can only be called by a CMSUser
   *
   * Errors:
   * - ForbiddenError:
   * - A non CMSUser called this
   * - A CMS user with unassigned division
   * - UserInputError
   * - A rate cannot be found with the given `rateID`
   * - The rate is in the DRAFT state
   * - The due date is in the past
   */
  createRateQuestion: CreateRateQuestionPayload;
  createRateQuestionResponse: CreateRateQuestionResponsePayload;
  deleteOauthClient: DeleteOauthClientPayload;
  /**
   * submitContract submits the given package for review by CMS.
   *
   * This can only be called by a StateUser from the state the package is for.
   * The package must be either in DRAFT or UNLOCKED state to be submitted
   * On resubmit the `submittedReason` field must be filled out.
   * The submission must be complete for this mutation to succeed. All required fields
   * in the ContractFormData and RateFormData must be filled out correctly.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A CMSUser called this
   *     - A state user from a different state called this.
   * - UserInputError
   *     - A package cannot be found with the given `pkgID`
   *     - The contract and or rates do not have all required fields filled out
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to submit a package in the SUBMITTED or RESUBMITTED state
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to find a package
   *         - Postgres returns error when attempting to update a package
   *         - Attempt to find state programs from json file returns an error
   *     - EMAIL_ERROR
   *
   *         - Sending state or CMS email failed.
   */
  submitContract: SubmitContractPayload;
  /**
   * submitHealthPlanPackage submits the given package for review by CMS.
   *
   * This can only be called by a StateUser from the state the package is for.
   * The package must be either in DRAFT or UNLOCKED state to be submitted
   * On resubmit the `submittedReason` field must be filled out.
   * The submission must be complete for this mutation to succeed. All required fields
   * in the healthPlanFormData must be filled out correctly.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A CMSUser called this
   *     - A state user from a different state called this.
   * - UserInputError
   *     - A package cannot be found with the given `pkgID`
   *     - The healthPlanFormData does not have all required field filled out
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to find a package
   *         - Postgres returns error when attempting to update a package
   *         - Attempt to find state programs from json file returns an error
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to submit a package in the SUBMITTED or RESUBMITTED state
   *     - PROTO_DECODE_ERROR
   *         - Failed to decode draft proto
   *     - EMAIL_ERROR
   *         - Sending state or CMS email failed.
   */
  submitHealthPlanPackage: SubmitHealthPlanPackagePayload;
  /**
   * submitRate will submit an unlocked rate and return the submitted rate data.
   *
   * This can only be called by a StateUser.
   * The rate must be in the DRAFT or UNLOCKED state to be submitted.
   *
   * Errors:
   * - ForbiddenError:
   *     - A non State user called this
   * - UserInputError
   *     - A rate cannot be found with the given `rateID`
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to finding rate
   *         - Postgres returns error when attempting to update rate
   *         - Postgres returns error when attempting to submit rate
   *         - Postgres returns error when both rateID or rateRevisionID are blank.
   *         - Postgres returns error when current rate revision to submit cannot be found
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to unlock a rate in the DRAFT or UNLOCKED state
   */
  submitRate: SubmitRatePayload;
  /** unoWithdrawSubmission is a CMS user only action to undo a submission widthdrawal, which includes contract and and child rates withdrawn together. */
  undoWithdrawContract: UndoWithdrawContractPayload;
  /**
   * undoWithdrawRate is CMS user only action to undo a rate withdraw
   *
   * Errors:
   * - ForbiddenError:
   * - A non CMS/CMS Approver user called this
   * - UserInputError:
   * - Rate is not in the correct consolidated status: WITHDRAWN
   * - A associated contract is not in the correct consolidated status: SUBMITTED or RESUBMITTED
   * - INTERNAL_SERVER_ERROR
   * - DB_ERROR
   * - A rate cannot be found
   * - Contracts that rate was withdrawn from cannot be found
   * - Issues restoring relationships between rate and contracts
   */
  undoWithdrawRate?: Maybe<UndoWithdrawRatePayload>;
  /**
   * unlockHealthPlanPackage returns a submitted package to the state for additional
   * edits.
   *
   * This can only be called by a CMSUser.
   * The package must be in the SUBMITTED or RESUBMITTED state to be unlocked.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMSuser called this
   * - UserInputError
   *     - A package cannot be found with the given `pkgID`
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to finding a package
   *         - Postgres returns error when attempting to update a package
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to unlock a package in the DRAFT or UNLOCKED state
   *     - PROTO_DECODE_ERROR
   *         - Failed to decode draft proto
   *     - EMAIL_ERROR
   *         - Sending state or CMS email failed.
   */
  unlockContract: UnlockContractPayload;
  /**
   * unlockHealthPlanPackage returns a submitted package to the state for additional
   * edits.
   *
   * This can only be called by a CMSUser.
   * The package must be in the SUBMITTED or RESUBMITTED state to be unlocked.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMSuser called this
   * - UserInputError
   *     - A package cannot be found with the given `pkgID`
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to finding a package
   *         - Postgres returns error when attempting to update a package
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to unlock a package in the DRAFT or UNLOCKED state
   *     - PROTO_DECODE_ERROR
   *         - Failed to decode draft proto
   *     - EMAIL_ERROR
   *         - Sending state or CMS email failed.
   */
  unlockHealthPlanPackage: UnlockHealthPlanPackagePayload;
  /**
   * unlockRate returns a submitted package to the state for additional edits.
   *
   * This can only be called by a CMSUser.
   * The rate must be in the SUBMITTED or RESUBMITTED state to be unlocked.
   * Email notifications will be sent to all the relevant parties
   *
   * Errors:
   * - ForbiddenError:
   *     - A non CMSuser called this
   * - UserInputError
   *     - A rate cannot be found with the given `rateID`
   * - INTERNAL_SERVER_ERROR
   *     - DB_ERROR
   *         - Postgres returns error when attempting to finding rate
   *         - Postgres returns error when attempting to update rate
   *     - INVALID_PACKAGE_STATUS
   *         - Attempted to unlock a rate in the DRAFT or UNLOCKED state
   *     - EMAIL_ERROR
   *         - Sending state or CMS email failed.
   */
  unlockRate: UnlockRatePayload;
  /**
   * updateContract can be used to update fields on the contract
   * as opposed to an individual revision
   */
  updateContract: UpdateContractPayload;
  /**
   * updateContractDraftRevision updates a contract's draft revision with the current
   * state of the form.
   *
   * The contract must be either in the DRAFT or UNLOCKED state.
   * Only a state user from the state this package is attached to can call this mutation
   *
   * Errors:
   * - ForbiddenError:
   * - A CMSUser called this
   * - A state user from a different state called this.
   * UserInputError:
   * - The package is in the LOCKED or RESUBMITTED status
   * - A package cannot be found with the given `contractID`
   */
  updateContractDraftRevision: UpdateContractDraftRevisionPayload;
  /**
   * updateDivisionAssignment updates CMS user division assignment.
   *
   * This can only be called by an AdminUser.
   * The cmsUserID must be a CMSUser's id, not a state user
   *
   * Errors:
   * - ForbiddenError:
   *     - A non AdminUser called this
   * - UserInputError
   *     - cmsUserID was not a CMSUser's ID
   *     - stateCodes included an invalid state code
   */
  updateDivisionAssignment: UpdateCmsUserPayload;
  /**
   * updateDraftContractRates updates the rates associated with a DRAFT contract revision.
   * It takes in an array of rate inputs, which can be new rates, updated rates, or linked rates.
   * The API will make the necessary data changes to make the data match the update, including
   * unlinking removed rates
   *
   * Errors:
   * - ForbiddenError:
   *     - A CMSUser called this
   *     - A state user from a different state called this.
   * - UserInputError:
   *     - any of the linked or update rates' ids don't exist
   *     - attempts to update the data of a nibling rate
   *     - attempts to simply link a child rate
   *     - The package is in the LOCKED or RESUBMITTED status
   *     - A package cannot be found with the given `pkgID`
   */
  updateDraftContractRates: UpdateDraftContractRatesPayload;
  /** updateEmailSettings updates the email settings the MC Review app */
  updateEmailSettings: UpdateEmailSettingsPayload;
  /**
   * updateHealthPlanFormData updates a single package with the current
   * state of the form encoded as a protobuf.
   *
   * The package must be either in the DRAFT or UNLOCKED state.
   * Only a state user from the state this package is attached to can call this mutation
   *
   * There are some fields in the healthPlanFormData type that must not be modified
   * by this mutation. They are set on the initial submission and are only changed by the server:
   * - id
   * - stateCode
   * - stateNumber
   * - createdAt
   * - updatedAt
   *
   * Errors:
   * - ForbiddenError:
   *     - A CMSUser called this
   *     - A state user from a different state called this.
   * - UserInputError:
   *     - The healthPlanFormData proto did not decode correctly
   *     - The healthPlanFormData decodes to a LockedHealthPlanFormData
   *     - The package is in the LOCKED or RESUBMITTED status
   *     - A package cannot be found with the given `pkgID`
   *     - The healthPlanFormData includes changes to any of the fields that are fixed on submission
   */
  updateHealthPlanFormData: UpdateHealthPlanFormDataPayload;
  updateOauthClient: UpdateOauthClientPayload;
  /**
   * updateStateAssignment updates an individual CMSUser state assignments.
   *
   * This can only be called by an AdminUser or a DMCO CMS user.
   * The cmsUserID must be a CMSUser's id, not a state user
   *
   * Errors:
   * - ForbiddenError:
   * - A non AdminUser called this
   * - A non DMCO CMS user called this
   * - UserInputError
   * - cmsUserID was not a CMSUser's ID
   * - stateCodes included an invalid state code
   */
  updateStateAssignment: UpdateCmsUserPayload;
  /**
   * updateStateAssignmentByState updates a group of CMSUsers to be assigned to a given state.
   *
   * This can only be called by an AdminUser or a DMCO CMS user.
   * The cmsUserID must be a CMSUser's id, not a state user
   *
   * Errors:
   * - ForbiddenError:
   * - A non AdminUser called this
   * - A non DMCO CMS user called this
   * - UserInputError
   * - cmsUserID was not a CMSUser's ID
   * - stateCodes included an invalid state code
   */
  updateStateAssignmentsByState: UpdateStateAssignmentsByStatePayload;
  /**
   * withdrawSubmission is a CMS user only action to withdraw an entire submission package, which includes contract and child rates
   *
   * Errors:
   * - ForbiddenError:
   * - A non CMS/CMS Approver user called this
   * - UserInputError:
   * - A contract is not in the correct submission status: SUBMITTED or RESUBMITTED
   * - A contract is not in the correct review status: UNDER_REVIEW
   * - INTERNAL_SERVER_ERROR
   * - DB_ERROR
   * - A contract cannot be found by id
   */
  withdrawContract: WithdrawContractPayload;
  /**
   * withdrawRate is CMS user only action to withdraw a rate from review
   *
   * Errors:
   * - ForbiddenError:
   * - A non CMS/CMS Approver user called this
   * - UserInputError:
   * - A contract is not in the correct submission status: SUBMITTED or RESUBMITTED
   * - A contract is not in the correct review status: UNDER_REVIEW
   * - INTERNAL_SERVER_ERROR
   * - DB_ERROR
   * - A contract cannot be found by id
   */
  withdrawRate?: Maybe<WithdrawRatePayload>;
};


export type MutationApproveContractArgs = {
  input: ApproveContractInput;
};


export type MutationCreateContractArgs = {
  input: CreateContractInput;
};


export type MutationCreateContractQuestionArgs = {
  input: CreateContractQuestionInput;
};


export type MutationCreateContractQuestionResponseArgs = {
  input: CreateQuestionResponseInput;
};


export type MutationCreateHealthPlanPackageArgs = {
  input: CreateHealthPlanPackageInput;
};


export type MutationCreateOauthClientArgs = {
  input: CreateOauthClientInput;
};


export type MutationCreateRateQuestionArgs = {
  input: CreateRateQuestionInput;
};


export type MutationCreateRateQuestionResponseArgs = {
  input: CreateQuestionResponseInput;
};


export type MutationDeleteOauthClientArgs = {
  input: DeleteOauthClientInput;
};


export type MutationSubmitContractArgs = {
  input: SubmitContractInput;
};


export type MutationSubmitHealthPlanPackageArgs = {
  input: SubmitHealthPlanPackageInput;
};


export type MutationSubmitRateArgs = {
  input: SubmitRateInput;
};


export type MutationUndoWithdrawContractArgs = {
  input: UndoWithdrawContractInput;
};


export type MutationUndoWithdrawRateArgs = {
  input: UndoWithdrawRateInput;
};


export type MutationUnlockContractArgs = {
  input: UnlockContractInput;
};


export type MutationUnlockHealthPlanPackageArgs = {
  input: UnlockHealthPlanPackageInput;
};


export type MutationUnlockRateArgs = {
  input: UnlockRateInput;
};


export type MutationUpdateContractArgs = {
  input: UpdateContractInput;
};


export type MutationUpdateContractDraftRevisionArgs = {
  input: UpdateContractDraftRevisionInput;
};


export type MutationUpdateDivisionAssignmentArgs = {
  input: UpdateDivisionAssignmentInput;
};


export type MutationUpdateDraftContractRatesArgs = {
  input: UpdateDraftContractRatesInput;
};


export type MutationUpdateEmailSettingsArgs = {
  input: UpdateEmailSettingsInput;
};


export type MutationUpdateHealthPlanFormDataArgs = {
  input: UpdateHealthPlanFormDataInput;
};


export type MutationUpdateOauthClientArgs = {
  input: UpdateOauthClientInput;
};


export type MutationUpdateStateAssignmentArgs = {
  input: UpdateStateAssignmentInput;
};


export type MutationUpdateStateAssignmentsByStateArgs = {
  input: UpdateStateAssignmentsByStateInput;
};


export type MutationWithdrawContractArgs = {
  input: WithdrawContractInput;
};


export type MutationWithdrawRateArgs = {
  input: WithdrawRateInput;
};

export type OauthClient = {
  __typename?: 'OauthClient';
  clientId: Scalars['String']['output'];
  clientSecret: Scalars['String']['output'];
  contactEmail?: Maybe<Scalars['String']['output']>;
  createdAt: Scalars['DateTime']['output'];
  description?: Maybe<Scalars['String']['output']>;
  grants: Array<Scalars['String']['output']>;
  id: Scalars['ID']['output'];
  updatedAt: Scalars['DateTime']['output'];
};

/**
 * A package in the system
 * that shares a rate with another package.
 * It's used as a part of RateFormData
 */
export type PackageWithSameRate = {
  __typename?: 'PackageWithSameRate';
  packageId: Scalars['String']['output'];
  packageName: Scalars['String']['output'];
  packageStatus?: Maybe<HealthPlanPackageStatus>;
};

/** The large overarching population of people that the program covers. */
export type PopulationCovered =
  | 'CHIP'
  | 'MEDICAID'
  | 'MEDICAID_AND_CHIP';

export type PopulationCoveredType =
  | 'CHIP'
  | 'MEDICAID'
  | 'MEDICAID_AND_CHIP';

/** Program represents a Managed Care program for the given state */
export type Program = {
  __typename?: 'Program';
  /** The full name for the program */
  fullName: Scalars['String']['output'];
  /** uuid */
  id: Scalars['ID']['output'];
  /** Specifies if a program relates to a rate rather than a contract */
  isRateProgram: Scalars['Boolean']['output'];
  /** A nickname for the program */
  name: Scalars['String']['output'];
};

export type Query = {
  __typename?: 'Query';
  /**
   * fetchContract returns a single contract, linked to revisions and related rates
   * given a contractID
   *
   * It can be called by CMS or State users
   *
   * Errors:
   * - ForbiddenError: A State user requests a contract that belongs to another state
   * - NotFoundError: contract for contractID not found in database
   */
  fetchContract: FetchContractPayload;
  /**
   * fetchCurrentUser returns user information for the currently logged in User
   *
   * If no user is currently logged in, the http request will return a 403 error, no graphQL body will be returned.
   */
  fetchCurrentUser: User;
  /**
   * fetchHealthPlanPackage returns a specific HealthPlanPackage by id
   *
   * If a package with the given ID cannot be found, this query returns undefined
   * CMS users cannot fetch a DRAFT HealthPlanPackage
   *
   * Errors:
   * - ForbiddenError:
   *     - A state user from a different state called this.
   *     - A CMSUser attempted to fetch a DRAFT HealthPlanPackage
   */
  fetchHealthPlanPackage: FetchHealthPlanPackagePayload;
  /**
   * fetchMcReviewSettings returns settings for the MC review app
   *
   * stateAssignments: List of all States in the system with their assigned CMS users.
   *
   * Errors:
   * - ForbiddenError: A State user requests a contract that belongs to another state
   */
  fetchMcReviewSettings: FetchMcReviewSettingsPayload;
  fetchOauthClients: FetchOauthClientsPayload;
  /**
   * fetchRate returns a rate with its revisions, including contract revisions
   * for a given rate's ID
   *
   * It can be called by CMS or State users
   *
   * Errors:
   * - ForbiddenError: This API is not available due to feature flags
   * - NotFoundError: rate for rate.ID not found in database
   */
  fetchRate: FetchRatePayload;
  /**
   * indexContracts returns all of the contracts the current user can see.
   *
   * StateUsers can find all the contracts for their state
   * CMSUsers can find all the contracts that do not have the DRAFT status
   */
  indexContracts: IndexContractsPayload;
  /**
   * indexHealthPlanPackages returns all of the HealthPlanPackages the current user can see.
   *
   * StateUsers can find all the packages for their state
   * CMSUsers can find all the packages that do not have the DRAFT status
   */
  indexHealthPlanPackages: IndexHealthPlanPackagesPayload;
  /**
   * indexRates returns full submitted rates
   * indexRates can be called by CMS and admin users, also used in link rate dropdown
   *
   * Errors:
   * - ForbiddenError: User must be a CMS or Admin type user
   * - NotFoundError:  No submitted rates found
   */
  indexRates: IndexRatesPayload;
  /**
   * indexRatesStripped returns abbreviated rate data
   * Intended for use with CMS dashboards, initially minimal rate query
   *
   *   Errors:
   * - ForbiddenError: User must be a CMS or Admin type user
   * - NotFoundError: No submitted rates found
   */
  indexRatesStripped: IndexRatesStrippedPayload;
  /**
   * indexUsers returns all of the Users in the system.
   *
   * It can only be called by an AdminUser
   *
   * Errors: ForbiddenError: A non-AdminUser called this
   */
  indexUsers: IndexUsersPayload;
};


export type QueryFetchContractArgs = {
  input: FetchContractInput;
};


export type QueryFetchHealthPlanPackageArgs = {
  input: FetchHealthPlanPackageInput;
};


export type QueryFetchOauthClientsArgs = {
  input?: InputMaybe<FetchOauthClientsInput>;
};


export type QueryFetchRateArgs = {
  input: FetchRateInput;
};


export type QueryIndexRatesArgs = {
  input?: InputMaybe<IndexRatesInput>;
};


export type QueryIndexRatesStrippedArgs = {
  input?: InputMaybe<IndexRatesInput>;
};

/**
 * QuestionResponse are responses to Rate or Contract questions, the graphql type has no differentiation between responses
 * for both questions types.
 */
export type QuestionResponse = {
  __typename?: 'QuestionResponse';
  addedBy: StateUser;
  createdAt: Scalars['DateTime']['output'];
  documents: Array<Document>;
  id: Scalars['ID']['output'];
  questionID: Scalars['ID']['output'];
};

/**
 * Rates are rate certifications and their associated actuary contacts and documents
 * State users may create, update, and submit several rates at a time
 */
export type Rate = {
  __typename?: 'Rate';
  /**
   * Synthesized field that represents if a rate's status or
   * reviewStatus should take precedence
   * Options are DRAFT, SUBMITTED, RESUBMITTED, UNLOCKED, WITHDRAWN
   */
  consolidatedStatus: ConsolidatedRateStatus;
  createdAt: Scalars['DateTime']['output'];
  /** The currently modifiable revision of the rate. Only present when rate has a status of DRAFT or UNLOCKED */
  draftRevision?: Maybe<RateRevision>;
  id: Scalars['ID']['output'];
  /** The initial date this rate was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['DateTime']['output']>;
  /**
   * packageSubmissions are a list of all the submissions of this rate and any contracts it
   * was associated with.
   */
  packageSubmissions?: Maybe<Array<RatePackageSubmission>>;
  /** parentContractID is the ID of the contract that last submitted this rate */
  parentContractID: Scalars['ID']['output'];
  /**
   * questions field is an array of questions asked about the rate by CMS. Each questions also contains responses
   * to the question submitted by the State. DRAFT rates will not have questions, only rates that have been submitted
   * , unlocked, or resubmitted. The array is in descending order by createdAt.
   */
  questions?: Maybe<IndexRateQuestionsPayload>;
  /**
   * Where the rate is in the review submission flow
   * Options are UNDER_REVIEW, WITHDRAWN
   */
  reviewStatus: RateReviewStatus;
  /** reviewStatusActions are the who/when/why for review status changes on this contract */
  reviewStatusActions?: Maybe<Array<RateReviewStatusActions>>;
  /**
   * Array of revisions for this rate. Each revision represents a single submission
   * for the rate and contains the full data from when the rate cert was submitted
   */
  revisions: Array<RateRevision>;
  /** Fuller state data for the submitting state */
  state: State;
  /** The state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * A unique auto-incrementing number generated for this rate
   * This value is used to generate the rateName
   */
  stateNumber: Scalars['Int']['output'];
  /**
   * Where the package is in the submission flow.
   * Options are DRAFT, SUBMITTED, RESUBMITTED and UNLOCKED
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: HealthPlanPackageStatus;
  updatedAt: Scalars['DateTime']['output'];
  /** webURL is a URL that will open the MC Review web app to this Rate */
  webURL: Scalars['String']['output'];
  /** Contracts this withdrawn rates was the child or linked to */
  withdrawnFromContracts?: Maybe<Array<Contract>>;
};

export type RateActionType =
  | 'UNDER_REVIEW'
  | 'WITHDRAW';

/** Either new capitation rates (NEW) or updates to previously certified capitation rates (AMENDMENT) */
export type RateAmendmentType =
  | 'AMENDMENT'
  | 'NEW';

/**
 * Determines on what basis the capitation rate is actuarially sound.
 * With RATE_RANGE the state certifies a range of rates
 * from the low to high end of the range as actuarially sound
 */
export type RateCapitationType =
  | 'RATE_CELL'
  | 'RATE_RANGE';

export type RateEdge = {
  __typename?: 'RateEdge';
  node: Rate;
};

/**
 * RateFormData represents the form data that was inputted by the state
 * This type is used for the form data field found on a rate revision
 */
export type RateFormData = {
  __typename?: 'RateFormData';
  /**
   * Is either OACT_TO_ACTUARY or OACT_TO_STATE
   * It specifies whether the state wants CMS to reach out to their actuaries
   * directly or go through them
   */
  actuaryCommunicationPreference?: Maybe<ActuaryCommunication>;
  /**
   * An array of additional ActuaryContacts
   * Each element includes the the name, title/role and email
   */
  addtlActuaryContacts: Array<ActuaryContact>;
  /**
   * The end date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateEnd?: Maybe<Scalars['Date']['output']>;
  /**
   * The start date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateStart?: Maybe<Scalars['Date']['output']>;
  /**
   * An array of ActuaryContacts
   * Each element includes the the name, title/role and email
   * of the actuaries who certified the rate
   */
  certifyingActuaryContacts: Array<ActuaryContact>;
  /** consolidatedRateProgramIDs An array of IDs representing state programs. Deprecated if that's all that exists, or the current ones if they exist. */
  consolidatedRateProgramIDs: Array<Scalars['String']['output']>;
  /** Deprecated an array of IDs representing historic state programs that the rate covers */
  deprecatedRateProgramIDs: Array<Scalars['String']['output']>;
  /**
   * An array of PackageWithSameRate elements
   * which contain the packageName, packageId, and packageStatus
   * These elements represent other packages in the system
   * that are using this rate
   */
  packagesWithSharedRateCerts: Array<PackageWithSameRate>;
  /**
   * Can be 'RATE_CELL' or 'RATE_RANGE'
   * These values represent on what basis the capitation rate is actuarially sound
   */
  rateCapitationType?: Maybe<RateCapitationType>;
  /**
   * Represents the name of the rate.
   * This value is auto generated based on rate, package and state program details
   */
  rateCertificationName?: Maybe<Scalars['String']['output']>;
  /**
   * The date the rate certification was
   * certified/signed by the state's actuary
   */
  rateDateCertified?: Maybe<Scalars['Date']['output']>;
  /**
   * If the rateType is NEW this is the end date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the end date of the
   * rating period for the original rate certification
   */
  rateDateEnd?: Maybe<Scalars['Date']['output']>;
  /**
   * If the rateType is NEW this is the start date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the start date of the
   * rating period for the original rate certification
   */
  rateDateStart?: Maybe<Scalars['Date']['output']>;
  /**
   * Signed certification documents the state uploads
   * Files can be PDF, DOC, or DOCX format
   */
  rateDocuments: Array<GenericDocument>;
  /** An array of IDs representing historic state programs that the rate covers */
  rateProgramIDs: Array<Scalars['String']['output']>;
  /**
   * Can be 'NEW' or 'AMENDMENT'
   * Refers to whether the state is submitting a brand new rate certification
   * or an amendment to an existing rate certification
   */
  rateType?: Maybe<RateAmendmentType>;
  /**
   * Additional documents the state uploads to support a rate cert
   * Files can be PDF, DOC, DOCX, XLSX, CSV format
   */
  supportingDocuments: Array<GenericDocument>;
};

export type RateFormDataInput = {
  /**
   * Is either OACT_TO_ACTUARY or OACT_TO_STATE
   * It specifies whether the state wants CMS to reach out to their actuaries
   * directly or go through them
   */
  actuaryCommunicationPreference?: InputMaybe<ActuaryCommunication>;
  /**
   * An array of additional ActuaryContacts
   * Each element includes the the name, title/role and email
   */
  addtlActuaryContacts?: InputMaybe<Array<ActuaryContactInput>>;
  /**
   * The end date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateEnd?: InputMaybe<Scalars['Date']['input']>;
  /**
   * The start date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateStart?: InputMaybe<Scalars['Date']['input']>;
  /**
   * An array of ActuaryContacts
   * Each element includes the the name, title/role and email
   * of the actuaries who certified the rate
   */
  certifyingActuaryContacts: Array<ActuaryContactInput>;
  /** Deprecated an array of IDs representing historic state programs that the rate covers */
  deprecatedRateProgramIDs: Array<Scalars['String']['input']>;
  /**
   * Can be 'RATE_CELL' or 'RATE_RANGE'
   * These values represent on what basis the capitation rate is actuarially sound
   */
  rateCapitationType?: InputMaybe<RateCapitationType>;
  /**
   * Represents the name of the rate.
   * This value is auto generated based on rate, package and state program details
   */
  rateCertificationName?: InputMaybe<Scalars['String']['input']>;
  /**
   * The date the rate certification was
   * certified/signed by the state's actuary
   */
  rateDateCertified?: InputMaybe<Scalars['Date']['input']>;
  /**
   * If the rateType is NEW this is the end date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the end date of the
   * rating period for the original rate certification
   */
  rateDateEnd?: InputMaybe<Scalars['Date']['input']>;
  /**
   * If the rateType is NEW this is the start date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the start date of the
   * rating period for the original rate certification
   */
  rateDateStart?: InputMaybe<Scalars['Date']['input']>;
  /**
   * Signed certification documents the state uploads
   * Files can be PDF, DOC, or DOCX format
   */
  rateDocuments: Array<GenericDocumentInput>;
  /** An array of IDs representing historic state programs that the rate covers */
  rateProgramIDs: Array<Scalars['String']['input']>;
  /**
   * Can be 'NEW' or 'AMENDMENT'
   * Refers to whether the state is submitting a brand new rate certification
   * or an amendment to an existing rate certification
   */
  rateType?: InputMaybe<RateAmendmentType>;
  /**
   * Additional documents the state uploads to support a rate cert
   * Files can be PDF, DOC, DOCX, XLSX, CSV format
   */
  supportingDocuments: Array<GenericDocumentInput>;
};

/** RateFormDataStripped represents stripped down form data that excludes relational fields. */
export type RateFormDataStripped = {
  __typename?: 'RateFormDataStripped';
  /**
   * The end date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateEnd?: Maybe<Scalars['Date']['output']>;
  /**
   * The start date of the rate amendment
   * Only relevant if rate type is AMENDMENT
   */
  amendmentEffectiveDateStart?: Maybe<Scalars['Date']['output']>;
  /** Deprecated an array of IDs representing historic state programs that the rate covers */
  deprecatedRateProgramIDs: Array<Scalars['String']['output']>;
  /**
   * Can be 'RATE_CELL' or 'RATE_RANGE'
   * These values represent on what basis the capitation rate is actuarially sound
   */
  rateCapitationType?: Maybe<RateCapitationType>;
  /**
   * Represents the name of the rate.
   * This value is auto generated based on rate, package and state program details
   */
  rateCertificationName?: Maybe<Scalars['String']['output']>;
  /**
   * The date the rate certification was
   * certified/signed by the state's actuary
   */
  rateDateCertified?: Maybe<Scalars['Date']['output']>;
  /**
   * If the rateType is NEW this is the end date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the end date of the
   * rating period for the original rate certification
   */
  rateDateEnd?: Maybe<Scalars['Date']['output']>;
  /**
   * If the rateType is NEW this is the start date of the
   * rating period for a new certification.
   * If the rateType is AMENDMENT this is the start date of the
   * rating period for the original rate certification
   */
  rateDateStart?: Maybe<Scalars['Date']['output']>;
  /** An array of IDs representing historic state programs that the rate covers */
  rateProgramIDs: Array<Scalars['String']['output']>;
  /**
   * Can be 'NEW' or 'AMENDMENT'
   * Refers to whether the state is submitting a brand new rate certification
   * or an amendment to an existing rate certification
   */
  rateType?: Maybe<RateAmendmentType>;
};

/**
 * RatePackageSubmission is a snapshot of a contract and all its related rates in time
 * a RatePackageSubmission can be created by the user submitting a contract or a related rate
 */
export type RatePackageSubmission = {
  __typename?: 'RatePackageSubmission';
  /** cause is a hint as to why this submission was created */
  cause: SubmissionReason;
  /** contractRevision is the contract revision current at the time of this package submission */
  contractRevisions: Array<ContractRevision>;
  /** rateRevision are the linked rate revisions current at the time of this package submission */
  rateRevision: RateRevision;
  /** submitInfo provides the submission reason/date/by for this package submission */
  submitInfo: UpdateInformation;
  /** submittedRevisions is a list of contract and/or rate revisions that were submitted to create this package submission */
  submittedRevisions: Array<SubmittableRevision>;
};

/**
 * RateQuestion is a question sent by CMS to the States for a response, associated with a single rate.
 * CMS may upload one or more documents full of questions to a single Question. States submit a
 * QuestionResponse with documents that answer the questions posed by CMS.
 */
export type RateQuestion = {
  __typename?: 'RateQuestion';
  addedBy: CmsUsersUnion;
  createdAt: Scalars['DateTime']['output'];
  division: Division;
  documents: Array<Document>;
  id: Scalars['ID']['output'];
  rateID: Scalars['ID']['output'];
  responses: Array<QuestionResponse>;
};

export type RateQuestionEdge = {
  __typename?: 'RateQuestionEdge';
  node: RateQuestion;
};

export type RateQuestionList = {
  __typename?: 'RateQuestionList';
  edges: Array<RateQuestionEdge>;
  totalCount?: Maybe<Scalars['Int']['output']>;
};

/** This status is used to determine the review status of the rate. */
export type RateReviewStatus =
  | 'UNDER_REVIEW'
  | 'WITHDRAWN';

/** RateReviewStatusActions is used for the review status actions on the rate */
export type RateReviewStatusActions = {
  __typename?: 'RateReviewStatusActions';
  /** type of action */
  actionType: RateActionType;
  rateID: Scalars['ID']['output'];
  /** the datetime when the update occurred */
  updatedAt: Scalars['DateTime']['output'];
  /** the user who performed the update */
  updatedBy: UpdatedBy;
  /** the reason provided by the user when performing the update */
  updatedReason: Scalars['String']['output'];
};

/**
 * A rate revision represents a single submission
 * for the rate and contains the full data from when the rate cert was submitted
 */
export type RateRevision = {
  __typename?: 'RateRevision';
  createdAt: Scalars['DateTime']['output'];
  /** The rate related form data that was inputted by the state */
  formData: RateFormData;
  id: Scalars['ID']['output'];
  rate?: Maybe<Rate>;
  rateID: Scalars['String']['output'];
  /** Information on who, when, and why this revision was submitted. */
  submitInfo?: Maybe<UpdateInformation>;
  /**
   * Information about who, when, and why this revision was unlocked.
   * Will be blank on the initial revision.
   */
  unlockInfo?: Maybe<UpdateInformation>;
  updatedAt: Scalars['DateTime']['output'];
};

/**
 * A rate revision represents a single submission
 * for the rate and contains stripped down data from when the rate cert was submitted
 */
export type RateRevisionStripped = {
  __typename?: 'RateRevisionStripped';
  createdAt: Scalars['DateTime']['output'];
  /** The rate related form data that was inputed by the state */
  formData: RateFormDataStripped;
  id: Scalars['ID']['output'];
  rateID: Scalars['String']['output'];
  /** Information on who, when, and why this revision was submitted. */
  submitInfo?: Maybe<UpdateInformation>;
  /**
   * Information about who, when, and why this revision was unlocked.
   * Will be blank on the initial revision.
   */
  unlockInfo?: Maybe<UpdateInformation>;
  updatedAt: Scalars['DateTime']['output'];
};

/** RateStripped is a stripped down version of a Rate, removing many relational fields to provide a faster query. */
export type RateStripped = {
  __typename?: 'RateStripped';
  /**
   * Synthesized field that represents if a rate's status or
   * reviewStatus should take precedence
   * Options are DRAFT, SUBMITTED, RESUBMITTED UNLOCKED, UNDER_REVIEW, WITHDRAWN
   */
  consolidatedStatus: ConsolidatedRateStatus;
  createdAt: Scalars['DateTime']['output'];
  /** The currently modifiable revision of the rate. Only present when rate has a status of DRAFT or UNLOCKED */
  draftRevision?: Maybe<RateRevisionStripped>;
  id: Scalars['ID']['output'];
  /** The initial date this rate was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['DateTime']['output']>;
  /** The latest submitted rate revision */
  latestSubmittedRevision: RateRevisionStripped;
  /** parentContractID is the ID of the contract that last submitted this rate */
  parentContractID: Scalars['ID']['output'];
  /** Contracts this child or linked rate is tied to */
  relatedContracts?: Maybe<Array<RelatedContractStripped>>;
  /**
   * Where the rate is in the review submission flow
   * Options are UNDER_REVIEW, WITHDRAWN
   */
  reviewStatus: RateReviewStatus;
  /** reviewStatusActions are the who/when/why for review status changes on this contract */
  reviewStatusActions?: Maybe<Array<RateReviewStatusActions>>;
  /** Fuller state data for the submitting state */
  state: State;
  /** The state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * A unique auto-incrementing number generated for this rate
   * This value is used to generate the rateName
   */
  stateNumber: Scalars['Int']['output'];
  /**
   * Where the package is in the submission flow.
   * Options are DRAFT, SUBMITTED, RESUBMITTED and UNLOCKED
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: HealthPlanPackageStatus;
  updatedAt: Scalars['DateTime']['output'];
  /** webURL is a URL that will open the MC Review web app to this Rate */
  webURL: Scalars['String']['output'];
};

export type RateStrippedEdge = {
  __typename?: 'RateStrippedEdge';
  node: RateStripped;
};

/**
 * Related Contracts are the contracts tied to the given child/linked rate
 * Only contains the necessary info for displaying the SubmissionWithdrawWarningBanner
 */
export type RelatedContractStripped = {
  __typename?: 'RelatedContractStripped';
  consolidatedStatus: ConsolidatedContractStatus;
  id: Scalars['ID']['output'];
};

/** State is a single US state or territory that operates managed care programs */
export type State = {
  __typename?: 'State';
  /** The state code (e.g. CA, TN) */
  code: Scalars['String']['output'];
  name: Scalars['String']['output'];
  /** A list of the state's Managed Care programs */
  programs: Array<Program>;
};

export type StateAssignment = {
  __typename?: 'StateAssignment';
  assignedCMSUsers: Array<CmsUsersUnion>;
  name: Scalars['String']['output'];
  stateCode: Scalars['String']['output'];
};

export type StateAssignmentUser = {
  __typename?: 'StateAssignmentUser';
  divisionAssignment?: Maybe<Division>;
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will be 'CMS_USER' or 'CMS_APPROVER_USER' */
  role: Scalars['String']['output'];
};

/** Contact information for contacting states regarding their submission */
export type StateContact = {
  __typename?: 'StateContact';
  email?: Maybe<Scalars['String']['output']>;
  name?: Maybe<Scalars['String']['output']>;
  titleRole?: Maybe<Scalars['String']['output']>;
};

/** Contact information input for contacting states regarding their submission */
export type StateContactInput = {
  email?: InputMaybe<Scalars['String']['input']>;
  name?: InputMaybe<Scalars['String']['input']>;
  titleRole?: InputMaybe<Scalars['String']['input']>;
};

/** StateUser is a user that works for a state, submitting packages to be reviewed by CMSUsers */
export type StateUser = {
  __typename?: 'StateUser';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  id: Scalars['ID']['output'];
  /** will always be 'STATE_USER' */
  role: Scalars['String']['output'];
  state: State;
};

/** SubmissionReason is a hint as to why this PackageSubmission was created */
export type SubmissionReason =
  /** A submission of this contract and zero or more newly created rates */
  | 'CONTRACT_SUBMISSION'
  /** A submission of an unrelated rate, linking it to this contract */
  | 'RATE_LINK'
  /** A submission of one of the rates related to this contract */
  | 'RATE_SUBMISSION'
  /** A submission of a rate related to this contract, removing the link between the two */
  | 'RATE_UNLINK';

export type SubmissionType =
  | 'CONTRACT_AND_RATES'
  | 'CONTRACT_ONLY';

export type SubmitContractInput = {
  contractID: Scalars['ID']['input'];
  /** User given reason this package was re-submitted. Left blank on initial submit. */
  submittedReason?: InputMaybe<Scalars['String']['input']>;
};

export type SubmitContractPayload = {
  __typename?: 'SubmitContractPayload';
  contract: Contract;
};

export type SubmitHealthPlanPackageInput = {
  pkgID: Scalars['ID']['input'];
  /** User given reason this package was re-submitted. Left blank on initial submit. */
  submittedReason?: InputMaybe<Scalars['String']['input']>;
};

export type SubmitHealthPlanPackagePayload = {
  __typename?: 'SubmitHealthPlanPackagePayload';
  pkg: HealthPlanPackage;
};

export type SubmitRateInput = {
  /** Rate related form data to be updated with submission */
  formData?: InputMaybe<RateFormDataInput>;
  rateID: Scalars['ID']['input'];
  /** User given submission description */
  submittedReason?: InputMaybe<Scalars['String']['input']>;
};

export type SubmitRatePayload = {
  __typename?: 'SubmitRatePayload';
  rate: Rate;
};

/** SubmittableRevision is what can appear in a submission */
export type SubmittableRevision = ContractRevision | RateRevision;

export type UndoWithdrawContractInput = {
  contractID: Scalars['ID']['input'];
  updatedReason: Scalars['String']['input'];
};

export type UndoWithdrawContractPayload = {
  __typename?: 'UndoWithdrawContractPayload';
  contract: Contract;
};

export type UndoWithdrawRateInput = {
  rateID: Scalars['ID']['input'];
  updatedReason: Scalars['String']['input'];
};

export type UndoWithdrawRatePayload = {
  __typename?: 'UndoWithdrawRatePayload';
  rate: Rate;
};

export type UnlockContractInput = {
  contractID: Scalars['ID']['input'];
  /** User given reason this contract was unlocked */
  unlockedReason: Scalars['String']['input'];
};

export type UnlockContractPayload = {
  __typename?: 'UnlockContractPayload';
  contract: UnlockedContract;
};

export type UnlockHealthPlanPackageInput = {
  pkgID: Scalars['ID']['input'];
  /** User given reason this package was unlocked */
  unlockedReason: Scalars['String']['input'];
};

export type UnlockHealthPlanPackagePayload = {
  __typename?: 'UnlockHealthPlanPackagePayload';
  pkg: HealthPlanPackage;
};

export type UnlockRateInput = {
  rateID: Scalars['ID']['input'];
  /** User given reason this rate was unlocked */
  unlockedReason: Scalars['String']['input'];
};

export type UnlockRatePayload = {
  __typename?: 'UnlockRatePayload';
  rate: Rate;
};

/**
 * UnlockedContract is a single unlocked contract, holding all the draft form data for a single contract
 * and associated with zero or more Rates
 */
export type UnlockedContract = {
  __typename?: 'UnlockedContract';
  /**
   * Synthesized field that represents if a contract's status or
   * reviewStatus should take precedence
   * Options are DRAFT, SUBMITTED, RESUBMITTED UNLOCKED, UNDER_REVIEW, APPROVED, WITHDRAWN
   */
  consolidatedStatus: ConsolidatedContractStatus;
  createdAt: Scalars['DateTime']['output'];
  /** dateContractDocsExecuted is the first date, if any in which the revisions were submitted with all contract docs executed. Null otherwise. */
  dateContractDocsExecuted?: Maybe<Scalars['DateTime']['output']>;
  /**
   * draftRates are the Rates that this editable submission are related to.
   * On submission they are cemented into a new ContractPackageSubmission
   */
  draftRates: Array<Rate>;
  /** draftRevision is the currently modifiable revision if the rate is DRAFT or UNLOCKED */
  draftRevision: ContractRevision;
  id: Scalars['ID']['output'];
  /** initiallySubmittedAt is the initial date this contract was submitted at. Is not changed by unlock or resubmission. */
  initiallySubmittedAt?: Maybe<Scalars['DateTime']['output']>;
  /** lastUpdatedForDisplay is the last time this contract was officially updated. When it's a draft it will be the last updatedAt date. Afterwards it will be the most recent submit or unlock or review action date. */
  lastUpdatedForDisplay: Scalars['DateTime']['output'];
  /** mccrsID is the four digit id in MC-CRS that corresponds to this Contract, if set */
  mccrsID?: Maybe<Scalars['String']['output']>;
  /**
   * packageSubmissions are a snapshot of the contract and its related rates through time
   * each packageSubmission was created by a submission of this contract and/or its related rates
   * a DRAFT Contract will have no packageSubmissions. Returned in _ascending_ order. Most recent
   * submission is in the first position in the array.
   */
  packageSubmissions: Array<ContractPackageSubmission>;
  /**
   * questions field is an array of questions asked about the contract by CMS. Each questions also contains responses
   * to the question submitted by the State. DRAFT contracts will not have questions, only contracts that have been submitted
   * , unlocked, or resubmitted. The array is in descending order by createdAt.
   */
  questions?: Maybe<IndexContractQuestionsPayload>;
  /**
   * Where the contract is in the review submission flow
   * Options are UNDER_REVIEW, APPROVED, WITHDRAWN
   */
  reviewStatus: ContractReviewStatus;
  /** reviewStatusActions are the who/when/why for review status changes on this contract */
  reviewStatusActions?: Maybe<Array<ContractReviewStatusActions>>;
  /** state is fuller state data for the submitting state */
  state: State;
  /** stateCode is the state code (e.g. CA or TN) for the submitting state */
  stateCode: Scalars['String']['output'];
  /**
   * stateNumber is a unique auto-incrementing number identifying this contract
   * This value is used to generate the contractName
   */
  stateNumber: Scalars['Int']['output'];
  /**
   * Where the contract is in the submission flow.
   * Options are DRAFT, SUBMITTED, RESUBMITTED and UNLOCKED
   * SUBMITTED and RESUBMITTED packages cannot be modified
   */
  status: UnlockedStatus;
  updatedAt: Scalars['DateTime']['output'];
  /** webURL is a url that will open the MC Review web app to this Contract */
  webURL: Scalars['String']['output'];
  /** Rates withdrawn from this contract submission */
  withdrawnRates?: Maybe<Array<Rate>>;
};

export type UnlockedStatus =
  | 'DRAFT'
  | 'UNLOCKED';

export type UpdateCmsUserPayload = {
  __typename?: 'UpdateCMSUserPayload';
  user: CmsUsersUnion;
};

export type UpdateContractDraftRevisionInput = {
  contractID: Scalars['ID']['input'];
  formData: ContractDraftRevisionFormDataInput;
  /** date the contracts draft revision was last updated at */
  lastSeenUpdatedAt: Scalars['DateTime']['input'];
};

export type UpdateContractDraftRevisionPayload = {
  __typename?: 'UpdateContractDraftRevisionPayload';
  contract: Contract;
};

export type UpdateContractInput = {
  id: Scalars['ID']['input'];
  mccrsID?: InputMaybe<Scalars['String']['input']>;
};

export type UpdateContractPayload = {
  __typename?: 'UpdateContractPayload';
  pkg: HealthPlanPackage;
};

/**
 * UpdateContractRateInput is a swiss army knife for updating rates related to a given contract.
 * Because GQL does not support unions in inputs, we will fake one here by setting the type parameter
 * on this input and the API will validate that the two optional parameters are set correctly given the type.
 */
export type UpdateContractRateInput = {
  /** formData is the rate data for a child rate, REQUIRED for CREATE and UPDATE types, omitted for LINK */
  formData?: InputMaybe<RateFormDataInput>;
  /** rateID is the rateID of the existing rate. This is REQUIRED for LINK and UPDATE types and OMITTED for CREATE */
  rateID?: InputMaybe<Scalars['ID']['input']>;
  /** type indicates the relationship of this rate to the contract */
  type: UpdateContractRateType;
};

/** UpdateContractRateType describes the relationship of the updated rate to this contract */
export type UpdateContractRateType =
  /** CREATE is going to create a new child rate, never seen before. Future updates of this rate will call UPDATE */
  | 'CREATE'
  /** LINK describes a linked nibling to this contract rate */
  | 'LINK'
  /** UPDATE updates the form data for a given child rate, whether previously created for this submission or unlocked */
  | 'UPDATE';

export type UpdateDivisionAssignmentInput = {
  cmsUserID: Scalars['ID']['input'];
  /** divisionAssignment is one of the CMS divisions to which a user is assigned: 'DMCO', 'DMCP', or 'OACT' */
  divisionAssignment?: InputMaybe<Division>;
};

export type UpdateDraftContractRatesInput = {
  contractID: Scalars['ID']['input'];
  /** The updatedAt of the contract draft revision at the time this mutation. This is used for optimistic concurrency control */
  lastSeenUpdatedAt: Scalars['DateTime']['input'];
  /**
   * updatedRates contains ALL the existing rates associated with this contract.
   * This includes rates that were previously linked or previously created (LINK & UPDATE)
   * as well as newly created rates and newly linked rates (CREATE & LINK)
   * any rates that are no longer associated with this contract should be omitted from the list.
   */
  updatedRates: Array<UpdateContractRateInput>;
};

export type UpdateDraftContractRatesPayload = {
  __typename?: 'UpdateDraftContractRatesPayload';
  contract: Contract;
};

export type UpdateEmailSettingsInput = {
  emailConfiguration: EmailConfigurationInput;
};

export type UpdateEmailSettingsPayload = {
  __typename?: 'UpdateEmailSettingsPayload';
  emailConfiguration: EmailConfiguration;
};

export type UpdateHealthPlanFormDataInput = {
  /**
   * base64 encoded HealthPlanFormData protobuf. This contains all the data
   * from the health plan pacakge form that the state user fills out and submits.
   * Its schema can be found in health_plan_form_data.proto
   */
  healthPlanFormData: Scalars['String']['input'];
  /** ID of the package to be updated, must be DRAFT or UNLOCKED */
  pkgID: Scalars['ID']['input'];
};

export type UpdateHealthPlanFormDataPayload = {
  __typename?: 'UpdateHealthPlanFormDataPayload';
  pkg: HealthPlanPackage;
};

/**
 * UpdateInformation is used for the unlockInfo and the submitInfo on HealthPlanRevision.
 * It tracks who, when, and why the submission or unlock was performed.
 */
export type UpdateInformation = {
  __typename?: 'UpdateInformation';
  /** the datetime when the update occured */
  updatedAt: Scalars['DateTime']['output'];
  /** the email of the user who performed the update */
  updatedBy: UpdatedBy;
  /** the reason provided by the user when performing the update */
  updatedReason: Scalars['String']['output'];
};

export type UpdateOauthClientInput = {
  clientId: Scalars['String']['input'];
  contactEmail?: InputMaybe<Scalars['String']['input']>;
  description?: InputMaybe<Scalars['String']['input']>;
  grants?: InputMaybe<Array<Scalars['String']['input']>>;
};

export type UpdateOauthClientPayload = {
  __typename?: 'UpdateOauthClientPayload';
  oauthClient: OauthClient;
};

export type UpdateStateAssignmentInput = {
  cmsUserID: Scalars['ID']['input'];
  /** stateAssignments is an array of stateCodes (e.g. ['CA', 'NM', 'TN']) */
  stateAssignments: Array<Scalars['String']['input']>;
};

export type UpdateStateAssignmentsByStateInput = {
  /** assignedUsers is an array of userIDs (uuids) */
  assignedUsers: Array<Scalars['String']['input']>;
  stateCode: Scalars['ID']['input'];
};

export type UpdateStateAssignmentsByStatePayload = {
  __typename?: 'UpdateStateAssignmentsByStatePayload';
  assignedUsers: Array<CmsUsersUnion>;
  stateCode: Scalars['ID']['output'];
};

export type UpdatedBy = {
  __typename?: 'UpdatedBy';
  email: Scalars['String']['output'];
  familyName: Scalars['String']['output'];
  givenName: Scalars['String']['output'];
  role: Scalars['String']['output'];
};

export type User = AdminUser | BusinessOwnerUser | CmsApproverUser | CmsUser | HelpdeskUser | StateUser;

export type UserEdge = {
  __typename?: 'UserEdge';
  node: User;
};

export type WithdrawContractInput = {
  contractID: Scalars['ID']['input'];
  updatedReason: Scalars['String']['input'];
};

export type WithdrawContractPayload = {
  __typename?: 'WithdrawContractPayload';
  contract: Contract;
};

export type WithdrawRateInput = {
  rateID: Scalars['ID']['input'];
  updatedReason: Scalars['String']['input'];
};

export type WithdrawRatePayload = {
  __typename?: 'WithdrawRatePayload';
  rate: Rate;
};

export type WithIndex<TObject> = TObject & Record<string, any>;
export type ResolversObject<TObject> = WithIndex<TObject>;

export type ResolverTypeWrapper<T> = Promise<T> | T;


export type ResolverWithResolve<TResult, TParent, TContext, TArgs> = {
  resolve: ResolverFn<TResult, TParent, TContext, TArgs>;
};
export type Resolver<TResult, TParent = {}, TContext = {}, TArgs = {}> = ResolverFn<TResult, TParent, TContext, TArgs> | ResolverWithResolve<TResult, TParent, TContext, TArgs>;

export type ResolverFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => Promise<TResult> | TResult;

export type SubscriptionSubscribeFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => AsyncIterable<TResult> | Promise<AsyncIterable<TResult>>;

export type SubscriptionResolveFn<TResult, TParent, TContext, TArgs> = (
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

export interface SubscriptionSubscriberObject<TResult, TKey extends string, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<{ [key in TKey]: TResult }, TParent, TContext, TArgs>;
  resolve?: SubscriptionResolveFn<TResult, { [key in TKey]: TResult }, TContext, TArgs>;
}

export interface SubscriptionResolverObject<TResult, TParent, TContext, TArgs> {
  subscribe: SubscriptionSubscribeFn<any, TParent, TContext, TArgs>;
  resolve: SubscriptionResolveFn<TResult, any, TContext, TArgs>;
}

export type SubscriptionObject<TResult, TKey extends string, TParent, TContext, TArgs> =
  | SubscriptionSubscriberObject<TResult, TKey, TParent, TContext, TArgs>
  | SubscriptionResolverObject<TResult, TParent, TContext, TArgs>;

export type SubscriptionResolver<TResult, TKey extends string, TParent = {}, TContext = {}, TArgs = {}> =
  | ((...args: any[]) => SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>)
  | SubscriptionObject<TResult, TKey, TParent, TContext, TArgs>;

export type TypeResolveFn<TTypes, TParent = {}, TContext = {}> = (
  parent: TParent,
  context: TContext,
  info: GraphQLResolveInfo
) => Maybe<TTypes> | Promise<Maybe<TTypes>>;

export type IsTypeOfResolverFn<T = {}, TContext = {}> = (obj: T, context: TContext, info: GraphQLResolveInfo) => boolean | Promise<boolean>;

export type NextResolverFn<T> = () => Promise<T>;

export type DirectiveResolverFn<TResult = {}, TParent = {}, TContext = {}, TArgs = {}> = (
  next: NextResolverFn<TResult>,
  parent: TParent,
  args: TArgs,
  context: TContext,
  info: GraphQLResolveInfo
) => TResult | Promise<TResult>;

/** Mapping of union types */
export type ResolversUnionTypes<_RefType extends Record<string, unknown>> = ResolversObject<{
  CMSUsersUnion: ( CMSApproverUserType ) | ( CMSUserType );
  SubmittableRevision: ( ContractRevisionType ) | ( RateRevisionWithContractsType );
  User: ( Partial<AdminUser> ) | ( Partial<BusinessOwnerUser> ) | ( CMSApproverUserType ) | ( CMSUserType ) | ( Partial<HelpdeskUser> ) | ( StateUserType );
}>;


/** Mapping between all available schema types and the resolvers types */
export type ResolversTypes = ResolversObject<{
  ActuarialFirm: ResolverTypeWrapper<Partial<ActuarialFirm>>;
  ActuaryCommunication: ResolverTypeWrapper<Partial<ActuaryCommunication>>;
  ActuaryContact: ResolverTypeWrapper<Partial<ActuaryContact>>;
  ActuaryContactInput: ResolverTypeWrapper<Partial<ActuaryContactInput>>;
  AdminUser: ResolverTypeWrapper<Partial<AdminUser>>;
  ApproveContractInput: ResolverTypeWrapper<Partial<ApproveContractInput>>;
  ApproveContractPayload: ResolverTypeWrapper<Partial<Omit<ApproveContractPayload, 'contract'> & { contract: ResolversTypes['Contract'] }>>;
  Boolean: ResolverTypeWrapper<Partial<Scalars['Boolean']['output']>>;
  BusinessOwnerUser: ResolverTypeWrapper<Partial<BusinessOwnerUser>>;
  CMSApproverUser: ResolverTypeWrapper<CMSApproverUserType>;
  CMSUser: ResolverTypeWrapper<CMSUserType>;
  CMSUsersUnion: Partial<ResolverTypeWrapper<ResolversUnionTypes<ResolversTypes>['CMSUsersUnion']>>;
  ConsolidatedContractStatus: ResolverTypeWrapper<Partial<ConsolidatedContractStatus>>;
  ConsolidatedRateStatus: ResolverTypeWrapper<Partial<ConsolidatedRateStatus>>;
  Contract: ResolverTypeWrapper<ContractDomainType>;
  ContractActionType: ResolverTypeWrapper<Partial<ContractActionType>>;
  ContractDraftRevisionFormDataInput: ResolverTypeWrapper<Partial<ContractDraftRevisionFormDataInput>>;
  ContractEdge: ResolverTypeWrapper<Partial<Omit<ContractEdge, 'node'> & { node: ResolversTypes['Contract'] }>>;
  ContractExecutionStatus: ResolverTypeWrapper<Partial<ContractExecutionStatus>>;
  ContractFormData: ResolverTypeWrapper<Partial<ContractFormData>>;
  ContractPackageSubmission: ResolverTypeWrapper<ContractPackageSubmissionWithCauseType>;
  ContractQuestion: ResolverTypeWrapper<Partial<Omit<ContractQuestion, 'addedBy' | 'responses'> & { addedBy: ResolversTypes['CMSUsersUnion'], responses: Array<ResolversTypes['QuestionResponse']> }>>;
  ContractQuestionEdge: ResolverTypeWrapper<Partial<Omit<ContractQuestionEdge, 'node'> & { node: ResolversTypes['ContractQuestion'] }>>;
  ContractQuestionList: ResolverTypeWrapper<Partial<Omit<ContractQuestionList, 'edges'> & { edges: Array<ResolversTypes['ContractQuestionEdge']> }>>;
  ContractReviewStatus: ResolverTypeWrapper<Partial<ContractReviewStatus>>;
  ContractReviewStatusActions: ResolverTypeWrapper<Partial<ContractReviewStatusActions>>;
  ContractRevision: ResolverTypeWrapper<ContractRevisionType>;
  ContractType: ResolverTypeWrapper<Partial<ContractType>>;
  CreateAPIKeyPayload: ResolverTypeWrapper<Partial<CreateApiKeyPayload>>;
  CreateContractInput: ResolverTypeWrapper<Partial<CreateContractInput>>;
  CreateContractPayload: ResolverTypeWrapper<Partial<Omit<CreateContractPayload, 'contract'> & { contract: ResolversTypes['Contract'] }>>;
  CreateContractQuestionInput: ResolverTypeWrapper<Partial<CreateContractQuestionInput>>;
  CreateContractQuestionPayload: ResolverTypeWrapper<Partial<Omit<CreateContractQuestionPayload, 'question'> & { question: ResolversTypes['ContractQuestion'] }>>;
  CreateContractQuestionResponsePayload: ResolverTypeWrapper<Partial<Omit<CreateContractQuestionResponsePayload, 'question'> & { question: ResolversTypes['ContractQuestion'] }>>;
  CreateHealthPlanPackageInput: ResolverTypeWrapper<Partial<CreateHealthPlanPackageInput>>;
  CreateHealthPlanPackagePayload: ResolverTypeWrapper<Partial<Omit<CreateHealthPlanPackagePayload, 'pkg'> & { pkg: ResolversTypes['HealthPlanPackage'] }>>;
  CreateOauthClientInput: ResolverTypeWrapper<Partial<CreateOauthClientInput>>;
  CreateOauthClientPayload: ResolverTypeWrapper<Partial<CreateOauthClientPayload>>;
  CreateQuestionResponseInput: ResolverTypeWrapper<Partial<CreateQuestionResponseInput>>;
  CreateRateQuestionInput: ResolverTypeWrapper<Partial<CreateRateQuestionInput>>;
  CreateRateQuestionPayload: ResolverTypeWrapper<Partial<Omit<CreateRateQuestionPayload, 'question'> & { question: ResolversTypes['RateQuestion'] }>>;
  CreateRateQuestionResponsePayload: ResolverTypeWrapper<Partial<Omit<CreateRateQuestionResponsePayload, 'question'> & { question: ResolversTypes['RateQuestion'] }>>;
  Date: ResolverTypeWrapper<Partial<Scalars['Date']['output']>>;
  DateTime: ResolverTypeWrapper<Partial<Scalars['DateTime']['output']>>;
  DeleteOauthClientInput: ResolverTypeWrapper<Partial<DeleteOauthClientInput>>;
  DeleteOauthClientPayload: ResolverTypeWrapper<Partial<DeleteOauthClientPayload>>;
  Division: ResolverTypeWrapper<Partial<Division>>;
  Document: ResolverTypeWrapper<Partial<Document>>;
  DocumentInput: ResolverTypeWrapper<Partial<DocumentInput>>;
  EmailConfiguration: ResolverTypeWrapper<Partial<EmailConfiguration>>;
  EmailConfigurationInput: ResolverTypeWrapper<Partial<EmailConfigurationInput>>;
  FederalAuthority: ResolverTypeWrapper<Partial<FederalAuthority>>;
  FetchContractInput: ResolverTypeWrapper<Partial<FetchContractInput>>;
  FetchContractPayload: ResolverTypeWrapper<Partial<Omit<FetchContractPayload, 'contract'> & { contract: ResolversTypes['Contract'] }>>;
  FetchHealthPlanPackageInput: ResolverTypeWrapper<Partial<FetchHealthPlanPackageInput>>;
  FetchHealthPlanPackagePayload: ResolverTypeWrapper<Partial<Omit<FetchHealthPlanPackagePayload, 'pkg'> & { pkg: ResolversTypes['HealthPlanPackage'] }>>;
  FetchMcReviewSettingsPayload: ResolverTypeWrapper<Partial<Omit<FetchMcReviewSettingsPayload, 'stateAssignments'> & { stateAssignments: Array<ResolversTypes['StateAssignment']> }>>;
  FetchOauthClientsInput: ResolverTypeWrapper<Partial<FetchOauthClientsInput>>;
  FetchOauthClientsPayload: ResolverTypeWrapper<Partial<FetchOauthClientsPayload>>;
  FetchRateInput: ResolverTypeWrapper<Partial<FetchRateInput>>;
  FetchRatePayload: ResolverTypeWrapper<Partial<Omit<FetchRatePayload, 'rate'> & { rate: ResolversTypes['Rate'] }>>;
  GenericDocument: ResolverTypeWrapper<Partial<GenericDocument>>;
  GenericDocumentInput: ResolverTypeWrapper<Partial<GenericDocumentInput>>;
  HealthPlanPackage: ResolverTypeWrapper<HealthPlanPackageType>;
  HealthPlanPackageEdge: ResolverTypeWrapper<Partial<Omit<HealthPlanPackageEdge, 'node'> & { node: ResolversTypes['HealthPlanPackage'] }>>;
  HealthPlanPackageStatus: ResolverTypeWrapper<Partial<HealthPlanPackageStatus>>;
  HealthPlanRevision: ResolverTypeWrapper<Partial<HealthPlanRevision>>;
  HealthPlanRevisionEdge: ResolverTypeWrapper<Partial<HealthPlanRevisionEdge>>;
  HelpdeskUser: ResolverTypeWrapper<Partial<HelpdeskUser>>;
  ID: ResolverTypeWrapper<Partial<Scalars['ID']['output']>>;
  IndexContractQuestionsPayload: ResolverTypeWrapper<Partial<Omit<IndexContractQuestionsPayload, 'DMCOQuestions' | 'DMCPQuestions' | 'OACTQuestions'> & { DMCOQuestions: ResolversTypes['ContractQuestionList'], DMCPQuestions: ResolversTypes['ContractQuestionList'], OACTQuestions: ResolversTypes['ContractQuestionList'] }>>;
  IndexContractsPayload: ResolverTypeWrapper<Partial<Omit<IndexContractsPayload, 'edges'> & { edges: Array<ResolversTypes['ContractEdge']> }>>;
  IndexHealthPlanPackagesPayload: ResolverTypeWrapper<Partial<Omit<IndexHealthPlanPackagesPayload, 'edges'> & { edges: Array<ResolversTypes['HealthPlanPackageEdge']> }>>;
  IndexRateQuestionsPayload: ResolverTypeWrapper<Partial<Omit<IndexRateQuestionsPayload, 'DMCOQuestions' | 'DMCPQuestions' | 'OACTQuestions'> & { DMCOQuestions: ResolversTypes['RateQuestionList'], DMCPQuestions: ResolversTypes['RateQuestionList'], OACTQuestions: ResolversTypes['RateQuestionList'] }>>;
  IndexRatesInput: ResolverTypeWrapper<Partial<IndexRatesInput>>;
  IndexRatesPayload: ResolverTypeWrapper<Partial<Omit<IndexRatesPayload, 'edges'> & { edges: Array<ResolversTypes['RateEdge']> }>>;
  IndexRatesStrippedPayload: ResolverTypeWrapper<Partial<Omit<IndexRatesStrippedPayload, 'edges'> & { edges: Array<ResolversTypes['RateStrippedEdge']> }>>;
  IndexUsersPayload: ResolverTypeWrapper<Partial<Omit<IndexUsersPayload, 'edges'> & { edges: Array<ResolversTypes['UserEdge']> }>>;
  Int: ResolverTypeWrapper<Partial<Scalars['Int']['output']>>;
  ManagedCareEntity: ResolverTypeWrapper<Partial<ManagedCareEntity>>;
  Mutation: ResolverTypeWrapper<{}>;
  OauthClient: ResolverTypeWrapper<Partial<OauthClient>>;
  PackageWithSameRate: ResolverTypeWrapper<Partial<PackageWithSameRate>>;
  PopulationCovered: ResolverTypeWrapper<Partial<PopulationCovered>>;
  PopulationCoveredType: ResolverTypeWrapper<Partial<PopulationCoveredType>>;
  Program: ResolverTypeWrapper<Partial<Program>>;
  Query: ResolverTypeWrapper<{}>;
  QuestionResponse: ResolverTypeWrapper<Partial<Omit<QuestionResponse, 'addedBy'> & { addedBy: ResolversTypes['StateUser'] }>>;
  Rate: ResolverTypeWrapper<RateType>;
  RateActionType: ResolverTypeWrapper<Partial<RateActionType>>;
  RateAmendmentType: ResolverTypeWrapper<Partial<RateAmendmentType>>;
  RateCapitationType: ResolverTypeWrapper<Partial<RateCapitationType>>;
  RateEdge: ResolverTypeWrapper<Partial<Omit<RateEdge, 'node'> & { node: ResolversTypes['Rate'] }>>;
  RateFormData: ResolverTypeWrapper<Partial<RateFormData>>;
  RateFormDataInput: ResolverTypeWrapper<Partial<RateFormDataInput>>;
  RateFormDataStripped: ResolverTypeWrapper<Partial<RateFormDataStripped>>;
  RatePackageSubmission: ResolverTypeWrapper<RatePackageSubmissionWithCauseType>;
  RateQuestion: ResolverTypeWrapper<Partial<Omit<RateQuestion, 'addedBy' | 'responses'> & { addedBy: ResolversTypes['CMSUsersUnion'], responses: Array<ResolversTypes['QuestionResponse']> }>>;
  RateQuestionEdge: ResolverTypeWrapper<Partial<Omit<RateQuestionEdge, 'node'> & { node: ResolversTypes['RateQuestion'] }>>;
  RateQuestionList: ResolverTypeWrapper<Partial<Omit<RateQuestionList, 'edges'> & { edges: Array<ResolversTypes['RateQuestionEdge']> }>>;
  RateReviewStatus: ResolverTypeWrapper<Partial<RateReviewStatus>>;
  RateReviewStatusActions: ResolverTypeWrapper<Partial<RateReviewStatusActions>>;
  RateRevision: ResolverTypeWrapper<RateRevisionWithContractsType>;
  RateRevisionStripped: ResolverTypeWrapper<Partial<RateRevisionStripped>>;
  RateStripped: ResolverTypeWrapper<StrippedRateType>;
  RateStrippedEdge: ResolverTypeWrapper<Partial<Omit<RateStrippedEdge, 'node'> & { node: ResolversTypes['RateStripped'] }>>;
  RelatedContractStripped: ResolverTypeWrapper<Partial<RelatedContractStripped>>;
  State: ResolverTypeWrapper<Partial<State>>;
  StateAssignment: ResolverTypeWrapper<Partial<Omit<StateAssignment, 'assignedCMSUsers'> & { assignedCMSUsers: Array<ResolversTypes['CMSUsersUnion']> }>>;
  StateAssignmentUser: ResolverTypeWrapper<Partial<StateAssignmentUser>>;
  StateContact: ResolverTypeWrapper<Partial<StateContact>>;
  StateContactInput: ResolverTypeWrapper<Partial<StateContactInput>>;
  StateUser: ResolverTypeWrapper<StateUserType>;
  String: ResolverTypeWrapper<Partial<Scalars['String']['output']>>;
  SubmissionReason: ResolverTypeWrapper<Partial<SubmissionReason>>;
  SubmissionType: ResolverTypeWrapper<Partial<SubmissionType>>;
  SubmitContractInput: ResolverTypeWrapper<Partial<SubmitContractInput>>;
  SubmitContractPayload: ResolverTypeWrapper<Partial<Omit<SubmitContractPayload, 'contract'> & { contract: ResolversTypes['Contract'] }>>;
  SubmitHealthPlanPackageInput: ResolverTypeWrapper<Partial<SubmitHealthPlanPackageInput>>;
  SubmitHealthPlanPackagePayload: ResolverTypeWrapper<Partial<Omit<SubmitHealthPlanPackagePayload, 'pkg'> & { pkg: ResolversTypes['HealthPlanPackage'] }>>;
  SubmitRateInput: ResolverTypeWrapper<Partial<SubmitRateInput>>;
  SubmitRatePayload: ResolverTypeWrapper<Partial<Omit<SubmitRatePayload, 'rate'> & { rate: ResolversTypes['Rate'] }>>;
  SubmittableRevision: Partial<ResolverTypeWrapper<ResolversUnionTypes<ResolversTypes>['SubmittableRevision']>>;
  UndoWithdrawContractInput: ResolverTypeWrapper<Partial<UndoWithdrawContractInput>>;
  UndoWithdrawContractPayload: ResolverTypeWrapper<Partial<Omit<UndoWithdrawContractPayload, 'contract'> & { contract: ResolversTypes['Contract'] }>>;
  UndoWithdrawRateInput: ResolverTypeWrapper<Partial<UndoWithdrawRateInput>>;
  UndoWithdrawRatePayload: ResolverTypeWrapper<Partial<Omit<UndoWithdrawRatePayload, 'rate'> & { rate: ResolversTypes['Rate'] }>>;
  UnlockContractInput: ResolverTypeWrapper<Partial<UnlockContractInput>>;
  UnlockContractPayload: ResolverTypeWrapper<Partial<Omit<UnlockContractPayload, 'contract'> & { contract: ResolversTypes['UnlockedContract'] }>>;
  UnlockHealthPlanPackageInput: ResolverTypeWrapper<Partial<UnlockHealthPlanPackageInput>>;
  UnlockHealthPlanPackagePayload: ResolverTypeWrapper<Partial<Omit<UnlockHealthPlanPackagePayload, 'pkg'> & { pkg: ResolversTypes['HealthPlanPackage'] }>>;
  UnlockRateInput: ResolverTypeWrapper<Partial<UnlockRateInput>>;
  UnlockRatePayload: ResolverTypeWrapper<Partial<Omit<UnlockRatePayload, 'rate'> & { rate: ResolversTypes['Rate'] }>>;
  UnlockedContract: ResolverTypeWrapper<UnlockedContractDomainType>;
  UnlockedStatus: ResolverTypeWrapper<Partial<UnlockedStatus>>;
  UpdateCMSUserPayload: ResolverTypeWrapper<Partial<Omit<UpdateCmsUserPayload, 'user'> & { user: ResolversTypes['CMSUsersUnion'] }>>;
  UpdateContractDraftRevisionInput: ResolverTypeWrapper<Partial<UpdateContractDraftRevisionInput>>;
  UpdateContractDraftRevisionPayload: ResolverTypeWrapper<Partial<Omit<UpdateContractDraftRevisionPayload, 'contract'> & { contract: ResolversTypes['Contract'] }>>;
  UpdateContractInput: ResolverTypeWrapper<Partial<UpdateContractInput>>;
  UpdateContractPayload: ResolverTypeWrapper<Partial<Omit<UpdateContractPayload, 'pkg'> & { pkg: ResolversTypes['HealthPlanPackage'] }>>;
  UpdateContractRateInput: ResolverTypeWrapper<Partial<UpdateContractRateInput>>;
  UpdateContractRateType: ResolverTypeWrapper<Partial<UpdateContractRateType>>;
  UpdateDivisionAssignmentInput: ResolverTypeWrapper<Partial<UpdateDivisionAssignmentInput>>;
  UpdateDraftContractRatesInput: ResolverTypeWrapper<Partial<UpdateDraftContractRatesInput>>;
  UpdateDraftContractRatesPayload: ResolverTypeWrapper<Partial<Omit<UpdateDraftContractRatesPayload, 'contract'> & { contract: ResolversTypes['Contract'] }>>;
  UpdateEmailSettingsInput: ResolverTypeWrapper<Partial<UpdateEmailSettingsInput>>;
  UpdateEmailSettingsPayload: ResolverTypeWrapper<Partial<UpdateEmailSettingsPayload>>;
  UpdateHealthPlanFormDataInput: ResolverTypeWrapper<Partial<UpdateHealthPlanFormDataInput>>;
  UpdateHealthPlanFormDataPayload: ResolverTypeWrapper<Partial<Omit<UpdateHealthPlanFormDataPayload, 'pkg'> & { pkg: ResolversTypes['HealthPlanPackage'] }>>;
  UpdateInformation: ResolverTypeWrapper<Partial<UpdateInformation>>;
  UpdateOauthClientInput: ResolverTypeWrapper<Partial<UpdateOauthClientInput>>;
  UpdateOauthClientPayload: ResolverTypeWrapper<Partial<UpdateOauthClientPayload>>;
  UpdateStateAssignmentInput: ResolverTypeWrapper<Partial<UpdateStateAssignmentInput>>;
  UpdateStateAssignmentsByStateInput: ResolverTypeWrapper<Partial<UpdateStateAssignmentsByStateInput>>;
  UpdateStateAssignmentsByStatePayload: ResolverTypeWrapper<Partial<Omit<UpdateStateAssignmentsByStatePayload, 'assignedUsers'> & { assignedUsers: Array<ResolversTypes['CMSUsersUnion']> }>>;
  UpdatedBy: ResolverTypeWrapper<Partial<UpdatedBy>>;
  User: ResolverTypeWrapper<UserType>;
  UserEdge: ResolverTypeWrapper<Partial<Omit<UserEdge, 'node'> & { node: ResolversTypes['User'] }>>;
  WithdrawContractInput: ResolverTypeWrapper<Partial<WithdrawContractInput>>;
  WithdrawContractPayload: ResolverTypeWrapper<Partial<Omit<WithdrawContractPayload, 'contract'> & { contract: ResolversTypes['Contract'] }>>;
  WithdrawRateInput: ResolverTypeWrapper<Partial<WithdrawRateInput>>;
  WithdrawRatePayload: ResolverTypeWrapper<Partial<Omit<WithdrawRatePayload, 'rate'> & { rate: ResolversTypes['Rate'] }>>;
}>;

/** Mapping between all available schema types and the resolvers parents */
export type ResolversParentTypes = ResolversObject<{
  ActuaryContact: Partial<ActuaryContact>;
  ActuaryContactInput: Partial<ActuaryContactInput>;
  AdminUser: Partial<AdminUser>;
  ApproveContractInput: Partial<ApproveContractInput>;
  ApproveContractPayload: Partial<Omit<ApproveContractPayload, 'contract'> & { contract: ResolversParentTypes['Contract'] }>;
  Boolean: Partial<Scalars['Boolean']['output']>;
  BusinessOwnerUser: Partial<BusinessOwnerUser>;
  CMSApproverUser: CMSApproverUserType;
  CMSUser: CMSUserType;
  CMSUsersUnion: Partial<ResolversUnionTypes<ResolversParentTypes>['CMSUsersUnion']>;
  Contract: ContractDomainType;
  ContractDraftRevisionFormDataInput: Partial<ContractDraftRevisionFormDataInput>;
  ContractEdge: Partial<Omit<ContractEdge, 'node'> & { node: ResolversParentTypes['Contract'] }>;
  ContractFormData: Partial<ContractFormData>;
  ContractPackageSubmission: ContractPackageSubmissionWithCauseType;
  ContractQuestion: Partial<Omit<ContractQuestion, 'addedBy' | 'responses'> & { addedBy: ResolversParentTypes['CMSUsersUnion'], responses: Array<ResolversParentTypes['QuestionResponse']> }>;
  ContractQuestionEdge: Partial<Omit<ContractQuestionEdge, 'node'> & { node: ResolversParentTypes['ContractQuestion'] }>;
  ContractQuestionList: Partial<Omit<ContractQuestionList, 'edges'> & { edges: Array<ResolversParentTypes['ContractQuestionEdge']> }>;
  ContractReviewStatusActions: Partial<ContractReviewStatusActions>;
  ContractRevision: ContractRevisionType;
  CreateAPIKeyPayload: Partial<CreateApiKeyPayload>;
  CreateContractInput: Partial<CreateContractInput>;
  CreateContractPayload: Partial<Omit<CreateContractPayload, 'contract'> & { contract: ResolversParentTypes['Contract'] }>;
  CreateContractQuestionInput: Partial<CreateContractQuestionInput>;
  CreateContractQuestionPayload: Partial<Omit<CreateContractQuestionPayload, 'question'> & { question: ResolversParentTypes['ContractQuestion'] }>;
  CreateContractQuestionResponsePayload: Partial<Omit<CreateContractQuestionResponsePayload, 'question'> & { question: ResolversParentTypes['ContractQuestion'] }>;
  CreateHealthPlanPackageInput: Partial<CreateHealthPlanPackageInput>;
  CreateHealthPlanPackagePayload: Partial<Omit<CreateHealthPlanPackagePayload, 'pkg'> & { pkg: ResolversParentTypes['HealthPlanPackage'] }>;
  CreateOauthClientInput: Partial<CreateOauthClientInput>;
  CreateOauthClientPayload: Partial<CreateOauthClientPayload>;
  CreateQuestionResponseInput: Partial<CreateQuestionResponseInput>;
  CreateRateQuestionInput: Partial<CreateRateQuestionInput>;
  CreateRateQuestionPayload: Partial<Omit<CreateRateQuestionPayload, 'question'> & { question: ResolversParentTypes['RateQuestion'] }>;
  CreateRateQuestionResponsePayload: Partial<Omit<CreateRateQuestionResponsePayload, 'question'> & { question: ResolversParentTypes['RateQuestion'] }>;
  Date: Partial<Scalars['Date']['output']>;
  DateTime: Partial<Scalars['DateTime']['output']>;
  DeleteOauthClientInput: Partial<DeleteOauthClientInput>;
  DeleteOauthClientPayload: Partial<DeleteOauthClientPayload>;
  Document: Partial<Document>;
  DocumentInput: Partial<DocumentInput>;
  EmailConfiguration: Partial<EmailConfiguration>;
  EmailConfigurationInput: Partial<EmailConfigurationInput>;
  FetchContractInput: Partial<FetchContractInput>;
  FetchContractPayload: Partial<Omit<FetchContractPayload, 'contract'> & { contract: ResolversParentTypes['Contract'] }>;
  FetchHealthPlanPackageInput: Partial<FetchHealthPlanPackageInput>;
  FetchHealthPlanPackagePayload: Partial<Omit<FetchHealthPlanPackagePayload, 'pkg'> & { pkg: ResolversParentTypes['HealthPlanPackage'] }>;
  FetchMcReviewSettingsPayload: Partial<Omit<FetchMcReviewSettingsPayload, 'stateAssignments'> & { stateAssignments: Array<ResolversParentTypes['StateAssignment']> }>;
  FetchOauthClientsInput: Partial<FetchOauthClientsInput>;
  FetchOauthClientsPayload: Partial<FetchOauthClientsPayload>;
  FetchRateInput: Partial<FetchRateInput>;
  FetchRatePayload: Partial<Omit<FetchRatePayload, 'rate'> & { rate: ResolversParentTypes['Rate'] }>;
  GenericDocument: Partial<GenericDocument>;
  GenericDocumentInput: Partial<GenericDocumentInput>;
  HealthPlanPackage: HealthPlanPackageType;
  HealthPlanPackageEdge: Partial<Omit<HealthPlanPackageEdge, 'node'> & { node: ResolversParentTypes['HealthPlanPackage'] }>;
  HealthPlanRevision: Partial<HealthPlanRevision>;
  HealthPlanRevisionEdge: Partial<HealthPlanRevisionEdge>;
  HelpdeskUser: Partial<HelpdeskUser>;
  ID: Partial<Scalars['ID']['output']>;
  IndexContractQuestionsPayload: Partial<Omit<IndexContractQuestionsPayload, 'DMCOQuestions' | 'DMCPQuestions' | 'OACTQuestions'> & { DMCOQuestions: ResolversParentTypes['ContractQuestionList'], DMCPQuestions: ResolversParentTypes['ContractQuestionList'], OACTQuestions: ResolversParentTypes['ContractQuestionList'] }>;
  IndexContractsPayload: Partial<Omit<IndexContractsPayload, 'edges'> & { edges: Array<ResolversParentTypes['ContractEdge']> }>;
  IndexHealthPlanPackagesPayload: Partial<Omit<IndexHealthPlanPackagesPayload, 'edges'> & { edges: Array<ResolversParentTypes['HealthPlanPackageEdge']> }>;
  IndexRateQuestionsPayload: Partial<Omit<IndexRateQuestionsPayload, 'DMCOQuestions' | 'DMCPQuestions' | 'OACTQuestions'> & { DMCOQuestions: ResolversParentTypes['RateQuestionList'], DMCPQuestions: ResolversParentTypes['RateQuestionList'], OACTQuestions: ResolversParentTypes['RateQuestionList'] }>;
  IndexRatesInput: Partial<IndexRatesInput>;
  IndexRatesPayload: Partial<Omit<IndexRatesPayload, 'edges'> & { edges: Array<ResolversParentTypes['RateEdge']> }>;
  IndexRatesStrippedPayload: Partial<Omit<IndexRatesStrippedPayload, 'edges'> & { edges: Array<ResolversParentTypes['RateStrippedEdge']> }>;
  IndexUsersPayload: Partial<Omit<IndexUsersPayload, 'edges'> & { edges: Array<ResolversParentTypes['UserEdge']> }>;
  Int: Partial<Scalars['Int']['output']>;
  Mutation: {};
  OauthClient: Partial<OauthClient>;
  PackageWithSameRate: Partial<PackageWithSameRate>;
  Program: Partial<Program>;
  Query: {};
  QuestionResponse: Partial<Omit<QuestionResponse, 'addedBy'> & { addedBy: ResolversParentTypes['StateUser'] }>;
  Rate: RateType;
  RateEdge: Partial<Omit<RateEdge, 'node'> & { node: ResolversParentTypes['Rate'] }>;
  RateFormData: Partial<RateFormData>;
  RateFormDataInput: Partial<RateFormDataInput>;
  RateFormDataStripped: Partial<RateFormDataStripped>;
  RatePackageSubmission: RatePackageSubmissionWithCauseType;
  RateQuestion: Partial<Omit<RateQuestion, 'addedBy' | 'responses'> & { addedBy: ResolversParentTypes['CMSUsersUnion'], responses: Array<ResolversParentTypes['QuestionResponse']> }>;
  RateQuestionEdge: Partial<Omit<RateQuestionEdge, 'node'> & { node: ResolversParentTypes['RateQuestion'] }>;
  RateQuestionList: Partial<Omit<RateQuestionList, 'edges'> & { edges: Array<ResolversParentTypes['RateQuestionEdge']> }>;
  RateReviewStatusActions: Partial<RateReviewStatusActions>;
  RateRevision: RateRevisionWithContractsType;
  RateRevisionStripped: Partial<RateRevisionStripped>;
  RateStripped: StrippedRateType;
  RateStrippedEdge: Partial<Omit<RateStrippedEdge, 'node'> & { node: ResolversParentTypes['RateStripped'] }>;
  RelatedContractStripped: Partial<RelatedContractStripped>;
  State: Partial<State>;
  StateAssignment: Partial<Omit<StateAssignment, 'assignedCMSUsers'> & { assignedCMSUsers: Array<ResolversParentTypes['CMSUsersUnion']> }>;
  StateAssignmentUser: Partial<StateAssignmentUser>;
  StateContact: Partial<StateContact>;
  StateContactInput: Partial<StateContactInput>;
  StateUser: StateUserType;
  String: Partial<Scalars['String']['output']>;
  SubmitContractInput: Partial<SubmitContractInput>;
  SubmitContractPayload: Partial<Omit<SubmitContractPayload, 'contract'> & { contract: ResolversParentTypes['Contract'] }>;
  SubmitHealthPlanPackageInput: Partial<SubmitHealthPlanPackageInput>;
  SubmitHealthPlanPackagePayload: Partial<Omit<SubmitHealthPlanPackagePayload, 'pkg'> & { pkg: ResolversParentTypes['HealthPlanPackage'] }>;
  SubmitRateInput: Partial<SubmitRateInput>;
  SubmitRatePayload: Partial<Omit<SubmitRatePayload, 'rate'> & { rate: ResolversParentTypes['Rate'] }>;
  SubmittableRevision: Partial<ResolversUnionTypes<ResolversParentTypes>['SubmittableRevision']>;
  UndoWithdrawContractInput: Partial<UndoWithdrawContractInput>;
  UndoWithdrawContractPayload: Partial<Omit<UndoWithdrawContractPayload, 'contract'> & { contract: ResolversParentTypes['Contract'] }>;
  UndoWithdrawRateInput: Partial<UndoWithdrawRateInput>;
  UndoWithdrawRatePayload: Partial<Omit<UndoWithdrawRatePayload, 'rate'> & { rate: ResolversParentTypes['Rate'] }>;
  UnlockContractInput: Partial<UnlockContractInput>;
  UnlockContractPayload: Partial<Omit<UnlockContractPayload, 'contract'> & { contract: ResolversParentTypes['UnlockedContract'] }>;
  UnlockHealthPlanPackageInput: Partial<UnlockHealthPlanPackageInput>;
  UnlockHealthPlanPackagePayload: Partial<Omit<UnlockHealthPlanPackagePayload, 'pkg'> & { pkg: ResolversParentTypes['HealthPlanPackage'] }>;
  UnlockRateInput: Partial<UnlockRateInput>;
  UnlockRatePayload: Partial<Omit<UnlockRatePayload, 'rate'> & { rate: ResolversParentTypes['Rate'] }>;
  UnlockedContract: UnlockedContractDomainType;
  UpdateCMSUserPayload: Partial<Omit<UpdateCmsUserPayload, 'user'> & { user: ResolversParentTypes['CMSUsersUnion'] }>;
  UpdateContractDraftRevisionInput: Partial<UpdateContractDraftRevisionInput>;
  UpdateContractDraftRevisionPayload: Partial<Omit<UpdateContractDraftRevisionPayload, 'contract'> & { contract: ResolversParentTypes['Contract'] }>;
  UpdateContractInput: Partial<UpdateContractInput>;
  UpdateContractPayload: Partial<Omit<UpdateContractPayload, 'pkg'> & { pkg: ResolversParentTypes['HealthPlanPackage'] }>;
  UpdateContractRateInput: Partial<UpdateContractRateInput>;
  UpdateDivisionAssignmentInput: Partial<UpdateDivisionAssignmentInput>;
  UpdateDraftContractRatesInput: Partial<UpdateDraftContractRatesInput>;
  UpdateDraftContractRatesPayload: Partial<Omit<UpdateDraftContractRatesPayload, 'contract'> & { contract: ResolversParentTypes['Contract'] }>;
  UpdateEmailSettingsInput: Partial<UpdateEmailSettingsInput>;
  UpdateEmailSettingsPayload: Partial<UpdateEmailSettingsPayload>;
  UpdateHealthPlanFormDataInput: Partial<UpdateHealthPlanFormDataInput>;
  UpdateHealthPlanFormDataPayload: Partial<Omit<UpdateHealthPlanFormDataPayload, 'pkg'> & { pkg: ResolversParentTypes['HealthPlanPackage'] }>;
  UpdateInformation: Partial<UpdateInformation>;
  UpdateOauthClientInput: Partial<UpdateOauthClientInput>;
  UpdateOauthClientPayload: Partial<UpdateOauthClientPayload>;
  UpdateStateAssignmentInput: Partial<UpdateStateAssignmentInput>;
  UpdateStateAssignmentsByStateInput: Partial<UpdateStateAssignmentsByStateInput>;
  UpdateStateAssignmentsByStatePayload: Partial<Omit<UpdateStateAssignmentsByStatePayload, 'assignedUsers'> & { assignedUsers: Array<ResolversParentTypes['CMSUsersUnion']> }>;
  UpdatedBy: Partial<UpdatedBy>;
  User: UserType;
  UserEdge: Partial<Omit<UserEdge, 'node'> & { node: ResolversParentTypes['User'] }>;
  WithdrawContractInput: Partial<WithdrawContractInput>;
  WithdrawContractPayload: Partial<Omit<WithdrawContractPayload, 'contract'> & { contract: ResolversParentTypes['Contract'] }>;
  WithdrawRateInput: Partial<WithdrawRateInput>;
  WithdrawRatePayload: Partial<Omit<WithdrawRatePayload, 'rate'> & { rate: ResolversParentTypes['Rate'] }>;
}>;

export type ActuaryContactResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ActuaryContact'] = ResolversParentTypes['ActuaryContact']> = ResolversObject<{
  actuarialFirm?: Resolver<Maybe<ResolversTypes['ActuarialFirm']>, ParentType, ContextType>;
  actuarialFirmOther?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  email?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  titleRole?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type AdminUserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['AdminUser'] = ResolversParentTypes['AdminUser']> = ResolversObject<{
  email?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  familyName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  givenName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  role?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ApproveContractPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ApproveContractPayload'] = ResolversParentTypes['ApproveContractPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type BusinessOwnerUserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['BusinessOwnerUser'] = ResolversParentTypes['BusinessOwnerUser']> = ResolversObject<{
  email?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  familyName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  givenName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  role?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CmsApproverUserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CMSApproverUser'] = ResolversParentTypes['CMSApproverUser']> = ResolversObject<{
  divisionAssignment?: Resolver<Maybe<ResolversTypes['Division']>, ParentType, ContextType>;
  email?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  familyName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  givenName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  role?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  stateAssignments?: Resolver<Array<ResolversTypes['State']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CmsUserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CMSUser'] = ResolversParentTypes['CMSUser']> = ResolversObject<{
  divisionAssignment?: Resolver<Maybe<ResolversTypes['Division']>, ParentType, ContextType>;
  email?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  familyName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  givenName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  role?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  stateAssignments?: Resolver<Array<ResolversTypes['State']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CmsUsersUnionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CMSUsersUnion'] = ResolversParentTypes['CMSUsersUnion']> = ResolversObject<{
  __resolveType: TypeResolveFn<'CMSApproverUser' | 'CMSUser', ParentType, ContextType>;
}>;

export type ContractResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Contract'] = ResolversParentTypes['Contract']> = ResolversObject<{
  consolidatedStatus?: Resolver<ResolversTypes['ConsolidatedContractStatus'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  dateContractDocsExecuted?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  draftRates?: Resolver<Maybe<Array<ResolversTypes['Rate']>>, ParentType, ContextType>;
  draftRevision?: Resolver<Maybe<ResolversTypes['ContractRevision']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  initiallySubmittedAt?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  lastUpdatedForDisplay?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  mccrsID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  packageSubmissions?: Resolver<Array<ResolversTypes['ContractPackageSubmission']>, ParentType, ContextType>;
  questions?: Resolver<Maybe<ResolversTypes['IndexContractQuestionsPayload']>, ParentType, ContextType>;
  reviewStatus?: Resolver<ResolversTypes['ContractReviewStatus'], ParentType, ContextType>;
  reviewStatusActions?: Resolver<Maybe<Array<ResolversTypes['ContractReviewStatusActions']>>, ParentType, ContextType>;
  state?: Resolver<ResolversTypes['State'], ParentType, ContextType>;
  stateCode?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  stateNumber?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['HealthPlanPackageStatus'], ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  webURL?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  withdrawnRates?: Resolver<Maybe<Array<ResolversTypes['Rate']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContractEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ContractEdge'] = ResolversParentTypes['ContractEdge']> = ResolversObject<{
  node?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContractFormDataResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ContractFormData'] = ResolversParentTypes['ContractFormData']> = ResolversObject<{
  contractDateEnd?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  contractDateStart?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  contractDocuments?: Resolver<Array<ResolversTypes['GenericDocument']>, ParentType, ContextType>;
  contractExecutionStatus?: Resolver<Maybe<ResolversTypes['ContractExecutionStatus']>, ParentType, ContextType>;
  contractType?: Resolver<Maybe<ResolversTypes['ContractType']>, ParentType, ContextType>;
  federalAuthorities?: Resolver<Array<ResolversTypes['FederalAuthority']>, ParentType, ContextType>;
  inLieuServicesAndSettings?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  managedCareEntities?: Resolver<Array<ResolversTypes['ManagedCareEntity']>, ParentType, ContextType>;
  modifiedBenefitsProvided?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedEnrollmentProcess?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedGeoAreaServed?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedGrevienceAndAppeal?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedIncentiveArrangements?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedLengthOfContract?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedMedicaidBeneficiaries?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedMedicalLossRatioStandards?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedNetworkAdequacyStandards?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedNonRiskPaymentArrangements?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedOtherFinancialPaymentIncentive?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedPassThroughPayments?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedPaymentsForMentalDiseaseInstitutions?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedRiskSharingStrategy?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedStateDirectedPayments?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  modifiedWitholdAgreements?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  populationCovered?: Resolver<Maybe<ResolversTypes['PopulationCovered']>, ParentType, ContextType>;
  programIDs?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  riskBasedContract?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  stateContacts?: Resolver<Array<ResolversTypes['StateContact']>, ParentType, ContextType>;
  statutoryRegulatoryAttestation?: Resolver<Maybe<ResolversTypes['Boolean']>, ParentType, ContextType>;
  statutoryRegulatoryAttestationDescription?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  submissionDescription?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  submissionType?: Resolver<ResolversTypes['SubmissionType'], ParentType, ContextType>;
  supportingDocuments?: Resolver<Array<ResolversTypes['GenericDocument']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContractPackageSubmissionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ContractPackageSubmission'] = ResolversParentTypes['ContractPackageSubmission']> = ResolversObject<{
  cause?: Resolver<ResolversTypes['SubmissionReason'], ParentType, ContextType>;
  contractRevision?: Resolver<ResolversTypes['ContractRevision'], ParentType, ContextType>;
  rateRevisions?: Resolver<Array<ResolversTypes['RateRevision']>, ParentType, ContextType>;
  submitInfo?: Resolver<ResolversTypes['UpdateInformation'], ParentType, ContextType>;
  submittedRevisions?: Resolver<Array<ResolversTypes['SubmittableRevision']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContractQuestionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ContractQuestion'] = ResolversParentTypes['ContractQuestion']> = ResolversObject<{
  addedBy?: Resolver<ResolversTypes['CMSUsersUnion'], ParentType, ContextType>;
  contractID?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  division?: Resolver<ResolversTypes['Division'], ParentType, ContextType>;
  documents?: Resolver<Array<ResolversTypes['Document']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  responses?: Resolver<Array<ResolversTypes['QuestionResponse']>, ParentType, ContextType>;
  round?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContractQuestionEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ContractQuestionEdge'] = ResolversParentTypes['ContractQuestionEdge']> = ResolversObject<{
  node?: Resolver<ResolversTypes['ContractQuestion'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContractQuestionListResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ContractQuestionList'] = ResolversParentTypes['ContractQuestionList']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['ContractQuestionEdge']>, ParentType, ContextType>;
  totalCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContractReviewStatusActionsResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ContractReviewStatusActions'] = ResolversParentTypes['ContractReviewStatusActions']> = ResolversObject<{
  actionType?: Resolver<ResolversTypes['ContractActionType'], ParentType, ContextType>;
  contractID?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  dateApprovalReleasedToState?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  updatedBy?: Resolver<ResolversTypes['UpdatedBy'], ParentType, ContextType>;
  updatedReason?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ContractRevisionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['ContractRevision'] = ResolversParentTypes['ContractRevision']> = ResolversObject<{
  contractID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  contractName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  formData?: Resolver<ResolversTypes['ContractFormData'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  submitInfo?: Resolver<Maybe<ResolversTypes['UpdateInformation']>, ParentType, ContextType>;
  unlockInfo?: Resolver<Maybe<ResolversTypes['UpdateInformation']>, ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateApiKeyPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CreateAPIKeyPayload'] = ResolversParentTypes['CreateAPIKeyPayload']> = ResolversObject<{
  expiresAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  key?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateContractPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CreateContractPayload'] = ResolversParentTypes['CreateContractPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateContractQuestionPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CreateContractQuestionPayload'] = ResolversParentTypes['CreateContractQuestionPayload']> = ResolversObject<{
  question?: Resolver<ResolversTypes['ContractQuestion'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateContractQuestionResponsePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CreateContractQuestionResponsePayload'] = ResolversParentTypes['CreateContractQuestionResponsePayload']> = ResolversObject<{
  question?: Resolver<ResolversTypes['ContractQuestion'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateHealthPlanPackagePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CreateHealthPlanPackagePayload'] = ResolversParentTypes['CreateHealthPlanPackagePayload']> = ResolversObject<{
  pkg?: Resolver<ResolversTypes['HealthPlanPackage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateOauthClientPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CreateOauthClientPayload'] = ResolversParentTypes['CreateOauthClientPayload']> = ResolversObject<{
  oauthClient?: Resolver<ResolversTypes['OauthClient'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateRateQuestionPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CreateRateQuestionPayload'] = ResolversParentTypes['CreateRateQuestionPayload']> = ResolversObject<{
  question?: Resolver<ResolversTypes['RateQuestion'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type CreateRateQuestionResponsePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['CreateRateQuestionResponsePayload'] = ResolversParentTypes['CreateRateQuestionResponsePayload']> = ResolversObject<{
  question?: Resolver<ResolversTypes['RateQuestion'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export interface DateScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['Date'], any> {
  name: 'Date';
}

export interface DateTimeScalarConfig extends GraphQLScalarTypeConfig<ResolversTypes['DateTime'], any> {
  name: 'DateTime';
}

export type DeleteOauthClientPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['DeleteOauthClientPayload'] = ResolversParentTypes['DeleteOauthClientPayload']> = ResolversObject<{
  oauthClient?: Resolver<ResolversTypes['OauthClient'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type DocumentResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Document'] = ResolversParentTypes['Document']> = ResolversObject<{
  downloadURL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  s3URL?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type EmailConfigurationResolvers<ContextType = Context, ParentType extends ResolversParentTypes['EmailConfiguration'] = ResolversParentTypes['EmailConfiguration']> = ResolversObject<{
  cmsRateHelpEmailAddress?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  cmsReviewHelpEmailAddress?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  devReviewTeamEmails?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  dmcoEmails?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  dmcpReviewEmails?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  dmcpSubmissionEmails?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  emailSource?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  helpDeskEmail?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  oactEmails?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FetchContractPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['FetchContractPayload'] = ResolversParentTypes['FetchContractPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FetchHealthPlanPackagePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['FetchHealthPlanPackagePayload'] = ResolversParentTypes['FetchHealthPlanPackagePayload']> = ResolversObject<{
  pkg?: Resolver<ResolversTypes['HealthPlanPackage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FetchMcReviewSettingsPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['FetchMcReviewSettingsPayload'] = ResolversParentTypes['FetchMcReviewSettingsPayload']> = ResolversObject<{
  emailConfiguration?: Resolver<Maybe<ResolversTypes['EmailConfiguration']>, ParentType, ContextType>;
  stateAssignments?: Resolver<Array<ResolversTypes['StateAssignment']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FetchOauthClientsPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['FetchOauthClientsPayload'] = ResolversParentTypes['FetchOauthClientsPayload']> = ResolversObject<{
  oauthClients?: Resolver<Array<ResolversTypes['OauthClient']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type FetchRatePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['FetchRatePayload'] = ResolversParentTypes['FetchRatePayload']> = ResolversObject<{
  rate?: Resolver<ResolversTypes['Rate'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type GenericDocumentResolvers<ContextType = Context, ParentType extends ResolversParentTypes['GenericDocument'] = ResolversParentTypes['GenericDocument']> = ResolversObject<{
  dateAdded?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  downloadURL?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<Maybe<ResolversTypes['ID']>, ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  s3URL?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  sha256?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type HealthPlanPackageResolvers<ContextType = Context, ParentType extends ResolversParentTypes['HealthPlanPackage'] = ResolversParentTypes['HealthPlanPackage']> = ResolversObject<{
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  initiallySubmittedAt?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  mccrsID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  questions?: Resolver<Maybe<ResolversTypes['IndexContractQuestionsPayload']>, ParentType, ContextType>;
  revisions?: Resolver<Array<ResolversTypes['HealthPlanRevisionEdge']>, ParentType, ContextType>;
  state?: Resolver<ResolversTypes['State'], ParentType, ContextType>;
  stateCode?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['HealthPlanPackageStatus'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type HealthPlanPackageEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['HealthPlanPackageEdge'] = ResolversParentTypes['HealthPlanPackageEdge']> = ResolversObject<{
  node?: Resolver<ResolversTypes['HealthPlanPackage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type HealthPlanRevisionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['HealthPlanRevision'] = ResolversParentTypes['HealthPlanRevision']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  formDataProto?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  submitInfo?: Resolver<Maybe<ResolversTypes['UpdateInformation']>, ParentType, ContextType>;
  unlockInfo?: Resolver<Maybe<ResolversTypes['UpdateInformation']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type HealthPlanRevisionEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['HealthPlanRevisionEdge'] = ResolversParentTypes['HealthPlanRevisionEdge']> = ResolversObject<{
  node?: Resolver<ResolversTypes['HealthPlanRevision'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type HelpdeskUserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['HelpdeskUser'] = ResolversParentTypes['HelpdeskUser']> = ResolversObject<{
  email?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  familyName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  givenName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  role?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IndexContractQuestionsPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['IndexContractQuestionsPayload'] = ResolversParentTypes['IndexContractQuestionsPayload']> = ResolversObject<{
  DMCOQuestions?: Resolver<ResolversTypes['ContractQuestionList'], ParentType, ContextType>;
  DMCPQuestions?: Resolver<ResolversTypes['ContractQuestionList'], ParentType, ContextType>;
  OACTQuestions?: Resolver<ResolversTypes['ContractQuestionList'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IndexContractsPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['IndexContractsPayload'] = ResolversParentTypes['IndexContractsPayload']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['ContractEdge']>, ParentType, ContextType>;
  totalCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IndexHealthPlanPackagesPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['IndexHealthPlanPackagesPayload'] = ResolversParentTypes['IndexHealthPlanPackagesPayload']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['HealthPlanPackageEdge']>, ParentType, ContextType>;
  totalCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IndexRateQuestionsPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['IndexRateQuestionsPayload'] = ResolversParentTypes['IndexRateQuestionsPayload']> = ResolversObject<{
  DMCOQuestions?: Resolver<ResolversTypes['RateQuestionList'], ParentType, ContextType>;
  DMCPQuestions?: Resolver<ResolversTypes['RateQuestionList'], ParentType, ContextType>;
  OACTQuestions?: Resolver<ResolversTypes['RateQuestionList'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IndexRatesPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['IndexRatesPayload'] = ResolversParentTypes['IndexRatesPayload']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['RateEdge']>, ParentType, ContextType>;
  totalCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IndexRatesStrippedPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['IndexRatesStrippedPayload'] = ResolversParentTypes['IndexRatesStrippedPayload']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['RateStrippedEdge']>, ParentType, ContextType>;
  totalCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type IndexUsersPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['IndexUsersPayload'] = ResolversParentTypes['IndexUsersPayload']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['UserEdge']>, ParentType, ContextType>;
  totalCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type MutationResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Mutation'] = ResolversParentTypes['Mutation']> = ResolversObject<{
  approveContract?: Resolver<Maybe<ResolversTypes['ApproveContractPayload']>, ParentType, ContextType, RequireFields<MutationApproveContractArgs, 'input'>>;
  createAPIKey?: Resolver<ResolversTypes['CreateAPIKeyPayload'], ParentType, ContextType>;
  createContract?: Resolver<ResolversTypes['CreateContractPayload'], ParentType, ContextType, RequireFields<MutationCreateContractArgs, 'input'>>;
  createContractQuestion?: Resolver<ResolversTypes['CreateContractQuestionPayload'], ParentType, ContextType, RequireFields<MutationCreateContractQuestionArgs, 'input'>>;
  createContractQuestionResponse?: Resolver<ResolversTypes['CreateContractQuestionResponsePayload'], ParentType, ContextType, RequireFields<MutationCreateContractQuestionResponseArgs, 'input'>>;
  createHealthPlanPackage?: Resolver<ResolversTypes['CreateHealthPlanPackagePayload'], ParentType, ContextType, RequireFields<MutationCreateHealthPlanPackageArgs, 'input'>>;
  createOauthClient?: Resolver<ResolversTypes['CreateOauthClientPayload'], ParentType, ContextType, RequireFields<MutationCreateOauthClientArgs, 'input'>>;
  createRateQuestion?: Resolver<ResolversTypes['CreateRateQuestionPayload'], ParentType, ContextType, RequireFields<MutationCreateRateQuestionArgs, 'input'>>;
  createRateQuestionResponse?: Resolver<ResolversTypes['CreateRateQuestionResponsePayload'], ParentType, ContextType, RequireFields<MutationCreateRateQuestionResponseArgs, 'input'>>;
  deleteOauthClient?: Resolver<ResolversTypes['DeleteOauthClientPayload'], ParentType, ContextType, RequireFields<MutationDeleteOauthClientArgs, 'input'>>;
  submitContract?: Resolver<ResolversTypes['SubmitContractPayload'], ParentType, ContextType, RequireFields<MutationSubmitContractArgs, 'input'>>;
  submitHealthPlanPackage?: Resolver<ResolversTypes['SubmitHealthPlanPackagePayload'], ParentType, ContextType, RequireFields<MutationSubmitHealthPlanPackageArgs, 'input'>>;
  submitRate?: Resolver<ResolversTypes['SubmitRatePayload'], ParentType, ContextType, RequireFields<MutationSubmitRateArgs, 'input'>>;
  undoWithdrawContract?: Resolver<ResolversTypes['UndoWithdrawContractPayload'], ParentType, ContextType, RequireFields<MutationUndoWithdrawContractArgs, 'input'>>;
  undoWithdrawRate?: Resolver<Maybe<ResolversTypes['UndoWithdrawRatePayload']>, ParentType, ContextType, RequireFields<MutationUndoWithdrawRateArgs, 'input'>>;
  unlockContract?: Resolver<ResolversTypes['UnlockContractPayload'], ParentType, ContextType, RequireFields<MutationUnlockContractArgs, 'input'>>;
  unlockHealthPlanPackage?: Resolver<ResolversTypes['UnlockHealthPlanPackagePayload'], ParentType, ContextType, RequireFields<MutationUnlockHealthPlanPackageArgs, 'input'>>;
  unlockRate?: Resolver<ResolversTypes['UnlockRatePayload'], ParentType, ContextType, RequireFields<MutationUnlockRateArgs, 'input'>>;
  updateContract?: Resolver<ResolversTypes['UpdateContractPayload'], ParentType, ContextType, RequireFields<MutationUpdateContractArgs, 'input'>>;
  updateContractDraftRevision?: Resolver<ResolversTypes['UpdateContractDraftRevisionPayload'], ParentType, ContextType, RequireFields<MutationUpdateContractDraftRevisionArgs, 'input'>>;
  updateDivisionAssignment?: Resolver<ResolversTypes['UpdateCMSUserPayload'], ParentType, ContextType, RequireFields<MutationUpdateDivisionAssignmentArgs, 'input'>>;
  updateDraftContractRates?: Resolver<ResolversTypes['UpdateDraftContractRatesPayload'], ParentType, ContextType, RequireFields<MutationUpdateDraftContractRatesArgs, 'input'>>;
  updateEmailSettings?: Resolver<ResolversTypes['UpdateEmailSettingsPayload'], ParentType, ContextType, RequireFields<MutationUpdateEmailSettingsArgs, 'input'>>;
  updateHealthPlanFormData?: Resolver<ResolversTypes['UpdateHealthPlanFormDataPayload'], ParentType, ContextType, RequireFields<MutationUpdateHealthPlanFormDataArgs, 'input'>>;
  updateOauthClient?: Resolver<ResolversTypes['UpdateOauthClientPayload'], ParentType, ContextType, RequireFields<MutationUpdateOauthClientArgs, 'input'>>;
  updateStateAssignment?: Resolver<ResolversTypes['UpdateCMSUserPayload'], ParentType, ContextType, RequireFields<MutationUpdateStateAssignmentArgs, 'input'>>;
  updateStateAssignmentsByState?: Resolver<ResolversTypes['UpdateStateAssignmentsByStatePayload'], ParentType, ContextType, RequireFields<MutationUpdateStateAssignmentsByStateArgs, 'input'>>;
  withdrawContract?: Resolver<ResolversTypes['WithdrawContractPayload'], ParentType, ContextType, RequireFields<MutationWithdrawContractArgs, 'input'>>;
  withdrawRate?: Resolver<Maybe<ResolversTypes['WithdrawRatePayload']>, ParentType, ContextType, RequireFields<MutationWithdrawRateArgs, 'input'>>;
}>;

export type OauthClientResolvers<ContextType = Context, ParentType extends ResolversParentTypes['OauthClient'] = ResolversParentTypes['OauthClient']> = ResolversObject<{
  clientId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  clientSecret?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  contactEmail?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  description?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  grants?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type PackageWithSameRateResolvers<ContextType = Context, ParentType extends ResolversParentTypes['PackageWithSameRate'] = ResolversParentTypes['PackageWithSameRate']> = ResolversObject<{
  packageId?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  packageName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  packageStatus?: Resolver<Maybe<ResolversTypes['HealthPlanPackageStatus']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type ProgramResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Program'] = ResolversParentTypes['Program']> = ResolversObject<{
  fullName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  isRateProgram?: Resolver<ResolversTypes['Boolean'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type QueryResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Query'] = ResolversParentTypes['Query']> = ResolversObject<{
  fetchContract?: Resolver<ResolversTypes['FetchContractPayload'], ParentType, ContextType, RequireFields<QueryFetchContractArgs, 'input'>>;
  fetchCurrentUser?: Resolver<ResolversTypes['User'], ParentType, ContextType>;
  fetchHealthPlanPackage?: Resolver<ResolversTypes['FetchHealthPlanPackagePayload'], ParentType, ContextType, RequireFields<QueryFetchHealthPlanPackageArgs, 'input'>>;
  fetchMcReviewSettings?: Resolver<ResolversTypes['FetchMcReviewSettingsPayload'], ParentType, ContextType>;
  fetchOauthClients?: Resolver<ResolversTypes['FetchOauthClientsPayload'], ParentType, ContextType, Partial<QueryFetchOauthClientsArgs>>;
  fetchRate?: Resolver<ResolversTypes['FetchRatePayload'], ParentType, ContextType, RequireFields<QueryFetchRateArgs, 'input'>>;
  indexContracts?: Resolver<ResolversTypes['IndexContractsPayload'], ParentType, ContextType>;
  indexHealthPlanPackages?: Resolver<ResolversTypes['IndexHealthPlanPackagesPayload'], ParentType, ContextType>;
  indexRates?: Resolver<ResolversTypes['IndexRatesPayload'], ParentType, ContextType, Partial<QueryIndexRatesArgs>>;
  indexRatesStripped?: Resolver<ResolversTypes['IndexRatesStrippedPayload'], ParentType, ContextType, Partial<QueryIndexRatesStrippedArgs>>;
  indexUsers?: Resolver<ResolversTypes['IndexUsersPayload'], ParentType, ContextType>;
}>;

export type QuestionResponseResolvers<ContextType = Context, ParentType extends ResolversParentTypes['QuestionResponse'] = ResolversParentTypes['QuestionResponse']> = ResolversObject<{
  addedBy?: Resolver<ResolversTypes['StateUser'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  documents?: Resolver<Array<ResolversTypes['Document']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  questionID?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateResolvers<ContextType = Context, ParentType extends ResolversParentTypes['Rate'] = ResolversParentTypes['Rate']> = ResolversObject<{
  consolidatedStatus?: Resolver<ResolversTypes['ConsolidatedRateStatus'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  draftRevision?: Resolver<Maybe<ResolversTypes['RateRevision']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  initiallySubmittedAt?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  packageSubmissions?: Resolver<Maybe<Array<ResolversTypes['RatePackageSubmission']>>, ParentType, ContextType>;
  parentContractID?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  questions?: Resolver<Maybe<ResolversTypes['IndexRateQuestionsPayload']>, ParentType, ContextType>;
  reviewStatus?: Resolver<ResolversTypes['RateReviewStatus'], ParentType, ContextType>;
  reviewStatusActions?: Resolver<Maybe<Array<ResolversTypes['RateReviewStatusActions']>>, ParentType, ContextType>;
  revisions?: Resolver<Array<ResolversTypes['RateRevision']>, ParentType, ContextType>;
  state?: Resolver<ResolversTypes['State'], ParentType, ContextType>;
  stateCode?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  stateNumber?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['HealthPlanPackageStatus'], ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  webURL?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  withdrawnFromContracts?: Resolver<Maybe<Array<ResolversTypes['Contract']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateEdge'] = ResolversParentTypes['RateEdge']> = ResolversObject<{
  node?: Resolver<ResolversTypes['Rate'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateFormDataResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateFormData'] = ResolversParentTypes['RateFormData']> = ResolversObject<{
  actuaryCommunicationPreference?: Resolver<Maybe<ResolversTypes['ActuaryCommunication']>, ParentType, ContextType>;
  addtlActuaryContacts?: Resolver<Array<ResolversTypes['ActuaryContact']>, ParentType, ContextType>;
  amendmentEffectiveDateEnd?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  amendmentEffectiveDateStart?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  certifyingActuaryContacts?: Resolver<Array<ResolversTypes['ActuaryContact']>, ParentType, ContextType>;
  consolidatedRateProgramIDs?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  deprecatedRateProgramIDs?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  packagesWithSharedRateCerts?: Resolver<Array<ResolversTypes['PackageWithSameRate']>, ParentType, ContextType>;
  rateCapitationType?: Resolver<Maybe<ResolversTypes['RateCapitationType']>, ParentType, ContextType>;
  rateCertificationName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rateDateCertified?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  rateDateEnd?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  rateDateStart?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  rateDocuments?: Resolver<Array<ResolversTypes['GenericDocument']>, ParentType, ContextType>;
  rateProgramIDs?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  rateType?: Resolver<Maybe<ResolversTypes['RateAmendmentType']>, ParentType, ContextType>;
  supportingDocuments?: Resolver<Array<ResolversTypes['GenericDocument']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateFormDataStrippedResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateFormDataStripped'] = ResolversParentTypes['RateFormDataStripped']> = ResolversObject<{
  amendmentEffectiveDateEnd?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  amendmentEffectiveDateStart?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  deprecatedRateProgramIDs?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  rateCapitationType?: Resolver<Maybe<ResolversTypes['RateCapitationType']>, ParentType, ContextType>;
  rateCertificationName?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  rateDateCertified?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  rateDateEnd?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  rateDateStart?: Resolver<Maybe<ResolversTypes['Date']>, ParentType, ContextType>;
  rateProgramIDs?: Resolver<Array<ResolversTypes['String']>, ParentType, ContextType>;
  rateType?: Resolver<Maybe<ResolversTypes['RateAmendmentType']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RatePackageSubmissionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RatePackageSubmission'] = ResolversParentTypes['RatePackageSubmission']> = ResolversObject<{
  cause?: Resolver<ResolversTypes['SubmissionReason'], ParentType, ContextType>;
  contractRevisions?: Resolver<Array<ResolversTypes['ContractRevision']>, ParentType, ContextType>;
  rateRevision?: Resolver<ResolversTypes['RateRevision'], ParentType, ContextType>;
  submitInfo?: Resolver<ResolversTypes['UpdateInformation'], ParentType, ContextType>;
  submittedRevisions?: Resolver<Array<ResolversTypes['SubmittableRevision']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateQuestionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateQuestion'] = ResolversParentTypes['RateQuestion']> = ResolversObject<{
  addedBy?: Resolver<ResolversTypes['CMSUsersUnion'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  division?: Resolver<ResolversTypes['Division'], ParentType, ContextType>;
  documents?: Resolver<Array<ResolversTypes['Document']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  rateID?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  responses?: Resolver<Array<ResolversTypes['QuestionResponse']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateQuestionEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateQuestionEdge'] = ResolversParentTypes['RateQuestionEdge']> = ResolversObject<{
  node?: Resolver<ResolversTypes['RateQuestion'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateQuestionListResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateQuestionList'] = ResolversParentTypes['RateQuestionList']> = ResolversObject<{
  edges?: Resolver<Array<ResolversTypes['RateQuestionEdge']>, ParentType, ContextType>;
  totalCount?: Resolver<Maybe<ResolversTypes['Int']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateReviewStatusActionsResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateReviewStatusActions'] = ResolversParentTypes['RateReviewStatusActions']> = ResolversObject<{
  actionType?: Resolver<ResolversTypes['RateActionType'], ParentType, ContextType>;
  rateID?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  updatedBy?: Resolver<ResolversTypes['UpdatedBy'], ParentType, ContextType>;
  updatedReason?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateRevisionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateRevision'] = ResolversParentTypes['RateRevision']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  formData?: Resolver<ResolversTypes['RateFormData'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  rate?: Resolver<Maybe<ResolversTypes['Rate']>, ParentType, ContextType>;
  rateID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  submitInfo?: Resolver<Maybe<ResolversTypes['UpdateInformation']>, ParentType, ContextType>;
  unlockInfo?: Resolver<Maybe<ResolversTypes['UpdateInformation']>, ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateRevisionStrippedResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateRevisionStripped'] = ResolversParentTypes['RateRevisionStripped']> = ResolversObject<{
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  formData?: Resolver<ResolversTypes['RateFormDataStripped'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  rateID?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  submitInfo?: Resolver<Maybe<ResolversTypes['UpdateInformation']>, ParentType, ContextType>;
  unlockInfo?: Resolver<Maybe<ResolversTypes['UpdateInformation']>, ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateStrippedResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateStripped'] = ResolversParentTypes['RateStripped']> = ResolversObject<{
  consolidatedStatus?: Resolver<ResolversTypes['ConsolidatedRateStatus'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  draftRevision?: Resolver<Maybe<ResolversTypes['RateRevisionStripped']>, ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  initiallySubmittedAt?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  latestSubmittedRevision?: Resolver<ResolversTypes['RateRevisionStripped'], ParentType, ContextType>;
  parentContractID?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  relatedContracts?: Resolver<Maybe<Array<ResolversTypes['RelatedContractStripped']>>, ParentType, ContextType>;
  reviewStatus?: Resolver<ResolversTypes['RateReviewStatus'], ParentType, ContextType>;
  reviewStatusActions?: Resolver<Maybe<Array<ResolversTypes['RateReviewStatusActions']>>, ParentType, ContextType>;
  state?: Resolver<ResolversTypes['State'], ParentType, ContextType>;
  stateCode?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  stateNumber?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['HealthPlanPackageStatus'], ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  webURL?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RateStrippedEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RateStrippedEdge'] = ResolversParentTypes['RateStrippedEdge']> = ResolversObject<{
  node?: Resolver<ResolversTypes['RateStripped'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type RelatedContractStrippedResolvers<ContextType = Context, ParentType extends ResolversParentTypes['RelatedContractStripped'] = ResolversParentTypes['RelatedContractStripped']> = ResolversObject<{
  consolidatedStatus?: Resolver<ResolversTypes['ConsolidatedContractStatus'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StateResolvers<ContextType = Context, ParentType extends ResolversParentTypes['State'] = ResolversParentTypes['State']> = ResolversObject<{
  code?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  programs?: Resolver<Array<ResolversTypes['Program']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StateAssignmentResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StateAssignment'] = ResolversParentTypes['StateAssignment']> = ResolversObject<{
  assignedCMSUsers?: Resolver<Array<ResolversTypes['CMSUsersUnion']>, ParentType, ContextType>;
  name?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  stateCode?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StateAssignmentUserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StateAssignmentUser'] = ResolversParentTypes['StateAssignmentUser']> = ResolversObject<{
  divisionAssignment?: Resolver<Maybe<ResolversTypes['Division']>, ParentType, ContextType>;
  email?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  familyName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  givenName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  role?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StateContactResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StateContact'] = ResolversParentTypes['StateContact']> = ResolversObject<{
  email?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  name?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  titleRole?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type StateUserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['StateUser'] = ResolversParentTypes['StateUser']> = ResolversObject<{
  email?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  familyName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  givenName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  role?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  state?: Resolver<ResolversTypes['State'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SubmitContractPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['SubmitContractPayload'] = ResolversParentTypes['SubmitContractPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SubmitHealthPlanPackagePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['SubmitHealthPlanPackagePayload'] = ResolversParentTypes['SubmitHealthPlanPackagePayload']> = ResolversObject<{
  pkg?: Resolver<ResolversTypes['HealthPlanPackage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SubmitRatePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['SubmitRatePayload'] = ResolversParentTypes['SubmitRatePayload']> = ResolversObject<{
  rate?: Resolver<ResolversTypes['Rate'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type SubmittableRevisionResolvers<ContextType = Context, ParentType extends ResolversParentTypes['SubmittableRevision'] = ResolversParentTypes['SubmittableRevision']> = ResolversObject<{
  __resolveType: TypeResolveFn<'ContractRevision' | 'RateRevision', ParentType, ContextType>;
}>;

export type UndoWithdrawContractPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UndoWithdrawContractPayload'] = ResolversParentTypes['UndoWithdrawContractPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UndoWithdrawRatePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UndoWithdrawRatePayload'] = ResolversParentTypes['UndoWithdrawRatePayload']> = ResolversObject<{
  rate?: Resolver<ResolversTypes['Rate'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UnlockContractPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UnlockContractPayload'] = ResolversParentTypes['UnlockContractPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['UnlockedContract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UnlockHealthPlanPackagePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UnlockHealthPlanPackagePayload'] = ResolversParentTypes['UnlockHealthPlanPackagePayload']> = ResolversObject<{
  pkg?: Resolver<ResolversTypes['HealthPlanPackage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UnlockRatePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UnlockRatePayload'] = ResolversParentTypes['UnlockRatePayload']> = ResolversObject<{
  rate?: Resolver<ResolversTypes['Rate'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UnlockedContractResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UnlockedContract'] = ResolversParentTypes['UnlockedContract']> = ResolversObject<{
  consolidatedStatus?: Resolver<ResolversTypes['ConsolidatedContractStatus'], ParentType, ContextType>;
  createdAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  dateContractDocsExecuted?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  draftRates?: Resolver<Array<ResolversTypes['Rate']>, ParentType, ContextType>;
  draftRevision?: Resolver<ResolversTypes['ContractRevision'], ParentType, ContextType>;
  id?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  initiallySubmittedAt?: Resolver<Maybe<ResolversTypes['DateTime']>, ParentType, ContextType>;
  lastUpdatedForDisplay?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  mccrsID?: Resolver<Maybe<ResolversTypes['String']>, ParentType, ContextType>;
  packageSubmissions?: Resolver<Array<ResolversTypes['ContractPackageSubmission']>, ParentType, ContextType>;
  questions?: Resolver<Maybe<ResolversTypes['IndexContractQuestionsPayload']>, ParentType, ContextType>;
  reviewStatus?: Resolver<ResolversTypes['ContractReviewStatus'], ParentType, ContextType>;
  reviewStatusActions?: Resolver<Maybe<Array<ResolversTypes['ContractReviewStatusActions']>>, ParentType, ContextType>;
  state?: Resolver<ResolversTypes['State'], ParentType, ContextType>;
  stateCode?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  stateNumber?: Resolver<ResolversTypes['Int'], ParentType, ContextType>;
  status?: Resolver<ResolversTypes['UnlockedStatus'], ParentType, ContextType>;
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  webURL?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  withdrawnRates?: Resolver<Maybe<Array<ResolversTypes['Rate']>>, ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateCmsUserPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateCMSUserPayload'] = ResolversParentTypes['UpdateCMSUserPayload']> = ResolversObject<{
  user?: Resolver<ResolversTypes['CMSUsersUnion'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateContractDraftRevisionPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateContractDraftRevisionPayload'] = ResolversParentTypes['UpdateContractDraftRevisionPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateContractPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateContractPayload'] = ResolversParentTypes['UpdateContractPayload']> = ResolversObject<{
  pkg?: Resolver<ResolversTypes['HealthPlanPackage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateDraftContractRatesPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateDraftContractRatesPayload'] = ResolversParentTypes['UpdateDraftContractRatesPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateEmailSettingsPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateEmailSettingsPayload'] = ResolversParentTypes['UpdateEmailSettingsPayload']> = ResolversObject<{
  emailConfiguration?: Resolver<ResolversTypes['EmailConfiguration'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateHealthPlanFormDataPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateHealthPlanFormDataPayload'] = ResolversParentTypes['UpdateHealthPlanFormDataPayload']> = ResolversObject<{
  pkg?: Resolver<ResolversTypes['HealthPlanPackage'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateInformationResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateInformation'] = ResolversParentTypes['UpdateInformation']> = ResolversObject<{
  updatedAt?: Resolver<ResolversTypes['DateTime'], ParentType, ContextType>;
  updatedBy?: Resolver<ResolversTypes['UpdatedBy'], ParentType, ContextType>;
  updatedReason?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateOauthClientPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateOauthClientPayload'] = ResolversParentTypes['UpdateOauthClientPayload']> = ResolversObject<{
  oauthClient?: Resolver<ResolversTypes['OauthClient'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdateStateAssignmentsByStatePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdateStateAssignmentsByStatePayload'] = ResolversParentTypes['UpdateStateAssignmentsByStatePayload']> = ResolversObject<{
  assignedUsers?: Resolver<Array<ResolversTypes['CMSUsersUnion']>, ParentType, ContextType>;
  stateCode?: Resolver<ResolversTypes['ID'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UpdatedByResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UpdatedBy'] = ResolversParentTypes['UpdatedBy']> = ResolversObject<{
  email?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  familyName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  givenName?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  role?: Resolver<ResolversTypes['String'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type UserResolvers<ContextType = Context, ParentType extends ResolversParentTypes['User'] = ResolversParentTypes['User']> = ResolversObject<{
  __resolveType: TypeResolveFn<'AdminUser' | 'BusinessOwnerUser' | 'CMSApproverUser' | 'CMSUser' | 'HelpdeskUser' | 'StateUser', ParentType, ContextType>;
}>;

export type UserEdgeResolvers<ContextType = Context, ParentType extends ResolversParentTypes['UserEdge'] = ResolversParentTypes['UserEdge']> = ResolversObject<{
  node?: Resolver<ResolversTypes['User'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type WithdrawContractPayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['WithdrawContractPayload'] = ResolversParentTypes['WithdrawContractPayload']> = ResolversObject<{
  contract?: Resolver<ResolversTypes['Contract'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type WithdrawRatePayloadResolvers<ContextType = Context, ParentType extends ResolversParentTypes['WithdrawRatePayload'] = ResolversParentTypes['WithdrawRatePayload']> = ResolversObject<{
  rate?: Resolver<ResolversTypes['Rate'], ParentType, ContextType>;
  __isTypeOf?: IsTypeOfResolverFn<ParentType, ContextType>;
}>;

export type Resolvers<ContextType = Context> = ResolversObject<{
  ActuaryContact?: ActuaryContactResolvers<ContextType>;
  AdminUser?: AdminUserResolvers<ContextType>;
  ApproveContractPayload?: ApproveContractPayloadResolvers<ContextType>;
  BusinessOwnerUser?: BusinessOwnerUserResolvers<ContextType>;
  CMSApproverUser?: CmsApproverUserResolvers<ContextType>;
  CMSUser?: CmsUserResolvers<ContextType>;
  CMSUsersUnion?: CmsUsersUnionResolvers<ContextType>;
  Contract?: ContractResolvers<ContextType>;
  ContractEdge?: ContractEdgeResolvers<ContextType>;
  ContractFormData?: ContractFormDataResolvers<ContextType>;
  ContractPackageSubmission?: ContractPackageSubmissionResolvers<ContextType>;
  ContractQuestion?: ContractQuestionResolvers<ContextType>;
  ContractQuestionEdge?: ContractQuestionEdgeResolvers<ContextType>;
  ContractQuestionList?: ContractQuestionListResolvers<ContextType>;
  ContractReviewStatusActions?: ContractReviewStatusActionsResolvers<ContextType>;
  ContractRevision?: ContractRevisionResolvers<ContextType>;
  CreateAPIKeyPayload?: CreateApiKeyPayloadResolvers<ContextType>;
  CreateContractPayload?: CreateContractPayloadResolvers<ContextType>;
  CreateContractQuestionPayload?: CreateContractQuestionPayloadResolvers<ContextType>;
  CreateContractQuestionResponsePayload?: CreateContractQuestionResponsePayloadResolvers<ContextType>;
  CreateHealthPlanPackagePayload?: CreateHealthPlanPackagePayloadResolvers<ContextType>;
  CreateOauthClientPayload?: CreateOauthClientPayloadResolvers<ContextType>;
  CreateRateQuestionPayload?: CreateRateQuestionPayloadResolvers<ContextType>;
  CreateRateQuestionResponsePayload?: CreateRateQuestionResponsePayloadResolvers<ContextType>;
  Date?: GraphQLScalarType;
  DateTime?: GraphQLScalarType;
  DeleteOauthClientPayload?: DeleteOauthClientPayloadResolvers<ContextType>;
  Document?: DocumentResolvers<ContextType>;
  EmailConfiguration?: EmailConfigurationResolvers<ContextType>;
  FetchContractPayload?: FetchContractPayloadResolvers<ContextType>;
  FetchHealthPlanPackagePayload?: FetchHealthPlanPackagePayloadResolvers<ContextType>;
  FetchMcReviewSettingsPayload?: FetchMcReviewSettingsPayloadResolvers<ContextType>;
  FetchOauthClientsPayload?: FetchOauthClientsPayloadResolvers<ContextType>;
  FetchRatePayload?: FetchRatePayloadResolvers<ContextType>;
  GenericDocument?: GenericDocumentResolvers<ContextType>;
  HealthPlanPackage?: HealthPlanPackageResolvers<ContextType>;
  HealthPlanPackageEdge?: HealthPlanPackageEdgeResolvers<ContextType>;
  HealthPlanRevision?: HealthPlanRevisionResolvers<ContextType>;
  HealthPlanRevisionEdge?: HealthPlanRevisionEdgeResolvers<ContextType>;
  HelpdeskUser?: HelpdeskUserResolvers<ContextType>;
  IndexContractQuestionsPayload?: IndexContractQuestionsPayloadResolvers<ContextType>;
  IndexContractsPayload?: IndexContractsPayloadResolvers<ContextType>;
  IndexHealthPlanPackagesPayload?: IndexHealthPlanPackagesPayloadResolvers<ContextType>;
  IndexRateQuestionsPayload?: IndexRateQuestionsPayloadResolvers<ContextType>;
  IndexRatesPayload?: IndexRatesPayloadResolvers<ContextType>;
  IndexRatesStrippedPayload?: IndexRatesStrippedPayloadResolvers<ContextType>;
  IndexUsersPayload?: IndexUsersPayloadResolvers<ContextType>;
  Mutation?: MutationResolvers<ContextType>;
  OauthClient?: OauthClientResolvers<ContextType>;
  PackageWithSameRate?: PackageWithSameRateResolvers<ContextType>;
  Program?: ProgramResolvers<ContextType>;
  Query?: QueryResolvers<ContextType>;
  QuestionResponse?: QuestionResponseResolvers<ContextType>;
  Rate?: RateResolvers<ContextType>;
  RateEdge?: RateEdgeResolvers<ContextType>;
  RateFormData?: RateFormDataResolvers<ContextType>;
  RateFormDataStripped?: RateFormDataStrippedResolvers<ContextType>;
  RatePackageSubmission?: RatePackageSubmissionResolvers<ContextType>;
  RateQuestion?: RateQuestionResolvers<ContextType>;
  RateQuestionEdge?: RateQuestionEdgeResolvers<ContextType>;
  RateQuestionList?: RateQuestionListResolvers<ContextType>;
  RateReviewStatusActions?: RateReviewStatusActionsResolvers<ContextType>;
  RateRevision?: RateRevisionResolvers<ContextType>;
  RateRevisionStripped?: RateRevisionStrippedResolvers<ContextType>;
  RateStripped?: RateStrippedResolvers<ContextType>;
  RateStrippedEdge?: RateStrippedEdgeResolvers<ContextType>;
  RelatedContractStripped?: RelatedContractStrippedResolvers<ContextType>;
  State?: StateResolvers<ContextType>;
  StateAssignment?: StateAssignmentResolvers<ContextType>;
  StateAssignmentUser?: StateAssignmentUserResolvers<ContextType>;
  StateContact?: StateContactResolvers<ContextType>;
  StateUser?: StateUserResolvers<ContextType>;
  SubmitContractPayload?: SubmitContractPayloadResolvers<ContextType>;
  SubmitHealthPlanPackagePayload?: SubmitHealthPlanPackagePayloadResolvers<ContextType>;
  SubmitRatePayload?: SubmitRatePayloadResolvers<ContextType>;
  SubmittableRevision?: SubmittableRevisionResolvers<ContextType>;
  UndoWithdrawContractPayload?: UndoWithdrawContractPayloadResolvers<ContextType>;
  UndoWithdrawRatePayload?: UndoWithdrawRatePayloadResolvers<ContextType>;
  UnlockContractPayload?: UnlockContractPayloadResolvers<ContextType>;
  UnlockHealthPlanPackagePayload?: UnlockHealthPlanPackagePayloadResolvers<ContextType>;
  UnlockRatePayload?: UnlockRatePayloadResolvers<ContextType>;
  UnlockedContract?: UnlockedContractResolvers<ContextType>;
  UpdateCMSUserPayload?: UpdateCmsUserPayloadResolvers<ContextType>;
  UpdateContractDraftRevisionPayload?: UpdateContractDraftRevisionPayloadResolvers<ContextType>;
  UpdateContractPayload?: UpdateContractPayloadResolvers<ContextType>;
  UpdateDraftContractRatesPayload?: UpdateDraftContractRatesPayloadResolvers<ContextType>;
  UpdateEmailSettingsPayload?: UpdateEmailSettingsPayloadResolvers<ContextType>;
  UpdateHealthPlanFormDataPayload?: UpdateHealthPlanFormDataPayloadResolvers<ContextType>;
  UpdateInformation?: UpdateInformationResolvers<ContextType>;
  UpdateOauthClientPayload?: UpdateOauthClientPayloadResolvers<ContextType>;
  UpdateStateAssignmentsByStatePayload?: UpdateStateAssignmentsByStatePayloadResolvers<ContextType>;
  UpdatedBy?: UpdatedByResolvers<ContextType>;
  User?: UserResolvers<ContextType>;
  UserEdge?: UserEdgeResolvers<ContextType>;
  WithdrawContractPayload?: WithdrawContractPayloadResolvers<ContextType>;
  WithdrawRatePayload?: WithdrawRatePayloadResolvers<ContextType>;
}>;

