export {
    hasAlias,
    includesEmailAddress,
    formatEmailAddresses,
    pruneDuplicateEmails,
} from './formatEmailAddresses'
