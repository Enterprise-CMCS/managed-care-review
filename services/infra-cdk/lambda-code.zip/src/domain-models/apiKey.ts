interface APIKeyType {
    key: string
    expiresAt: Date
}

export type { APIKeyType }
